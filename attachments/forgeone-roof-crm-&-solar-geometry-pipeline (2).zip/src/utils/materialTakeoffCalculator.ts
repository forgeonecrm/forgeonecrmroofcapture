export type RoofingMaterialType = 'shingle' | 'metal' | 'tile' | 'tpo';

export interface MaterialItem {
  id: string;
  category: 'primary' | 'ridge_hip' | 'starter_edge' | 'underlayment' | 'fasteners' | 'accessories';
  name: string;
  specification: string;
  coverageFormula: string;
  quantity: number;
  unit: string;
  unitCost: number;
  totalCost: number;
}

export interface MaterialTakeoffResult {
  materialType: RoofingMaterialType;
  materialName: string;
  netAreaSqFt: number;
  netSquares: number;
  wastePercent: number;
  grossAreaSqFt: number;
  grossSquares: number;
  linearEdges: {
    eaves: number;
    ridges: number;
    hips: number;
    valleys: number;
    rakes: number;
    totalLinearFeet: number;
  };
  items: MaterialItem[];
  totalMaterialCost: number;
  costPerSquare: number;
}

export const MATERIAL_PROFILES: Record<
  RoofingMaterialType,
  {
    name: string;
    description: string;
    warranty: string;
    idealSlope: string;
    defaultWaste: number;
  }
> = {
  shingle: {
    name: 'Architectural Asphalt Shingles',
    description: 'Class A fire-rated 30-year dimensional laminated shingles',
    warranty: '30-Year Lifetime Limited',
    idealSlope: '3:12 and higher',
    defaultWaste: 10,
  },
  metal: {
    name: 'Standing Seam Metal (24ga)',
    description: 'Concealed fastener 16" standing seam steel panels',
    warranty: '50-Year Non-Prorated',
    idealSlope: '2:12 and higher',
    defaultWaste: 10,
  },
  tile: {
    name: 'Concrete / Spanish "S" Tile',
    description: 'High-thermal mass interlocking curved barrel tile',
    warranty: '50-Year Lifetime',
    idealSlope: '4:12 and higher',
    defaultWaste: 12,
  },
  tpo: {
    name: 'Commercial 60-mil TPO Membrane',
    description: 'Heat-welded single-ply white reflective membrane with polyiso insulation',
    warranty: '25-Year Commercial',
    idealSlope: '0.25:12 to 3:12 (Low-slope)',
    defaultWaste: 8,
  },
};

/**
 * Calculates itemized roofing material takeoff based on surface area and linear edges.
 */
export function calculateMaterialTakeoff(params: {
  materialType: RoofingMaterialType;
  netAreaSqFt: number;
  wastePercent: number;
  eavesFeet: number;
  ridgesFeet: number;
  hipsFeet: number;
  valleysFeet: number;
  rakesFeet: number;
}): MaterialTakeoffResult {
  const {
    materialType,
    netAreaSqFt,
    wastePercent,
    eavesFeet,
    ridgesFeet,
    hipsFeet,
    valleysFeet,
    rakesFeet,
  } = params;

  const netSquares = Math.round((netAreaSqFt / 100) * 10) / 10;
  const grossAreaSqFt = Math.round(netAreaSqFt * (1 + wastePercent / 100));
  const grossSquares = Math.round((grossAreaSqFt / 100) * 10) / 10;

  const totalLinearFeet = eavesFeet + ridgesFeet + hipsFeet + valleysFeet + rakesFeet;
  const items: MaterialItem[] = [];

  if (materialType === 'shingle') {
    // 1. Field Architectural Shingles (3 bundles per square)
    const fieldBundles = Math.ceil(grossSquares * 3);
    items.push({
      id: 'shingle-field',
      category: 'primary',
      name: 'Architectural Field Shingles',
      specification: 'Class A Laminated Dimensional (3 bdls/sq)',
      coverageFormula: `${grossSquares} gross sq × 3 bundles/sq`,
      quantity: fieldBundles,
      unit: 'Bundles',
      unitCost: 39.5,
      totalCost: fieldBundles * 39.5,
    });

    // 2. Hip & Ridge Cap Shingles (31 linear feet per bundle)
    const hipRidgeLength = ridgesFeet + hipsFeet;
    const hipRidgeBundles = Math.max(1, Math.ceil(hipRidgeLength / 31));
    items.push({
      id: 'shingle-ridge',
      category: 'ridge_hip',
      name: 'High-Profile Hip & Ridge Cap',
      specification: 'Pre-cut shadow cap (31 lin ft/bdl)',
      coverageFormula: `${hipRidgeLength} lin ft ÷ 31 ft/bdl`,
      quantity: hipRidgeBundles,
      unit: 'Bundles',
      unitCost: 58.0,
      totalCost: hipRidgeBundles * 58.0,
    });

    // 3. Universal Starter Strip Shingles (105 linear feet per roll)
    const perimeterLength = eavesFeet + rakesFeet;
    const starterRolls = Math.max(1, Math.ceil(perimeterLength / 105));
    items.push({
      id: 'shingle-starter',
      category: 'starter_edge',
      name: 'Eave & Rake Starter Strip',
      specification: 'Self-adhering wind-rated starter (105 lin ft/roll)',
      coverageFormula: `${perimeterLength} lin ft perimeter ÷ 105 ft/roll`,
      quantity: starterRolls,
      unit: 'Rolls',
      unitCost: 64.0,
      totalCost: starterRolls * 64.0,
    });

    // 4. Synthetic Roof Underlayment (10 squares = 1,000 sq ft per roll)
    const underlaymentRolls = Math.max(1, Math.ceil(grossSquares / 10));
    items.push({
      id: 'shingle-underlayment',
      category: 'underlayment',
      name: 'High-Performance Synthetic Underlayment',
      specification: 'Tear-resistant non-woven polymer (10 sq/roll)',
      coverageFormula: `${grossSquares} gross sq ÷ 10 sq/roll`,
      quantity: underlaymentRolls,
      unit: 'Rolls',
      unitCost: 96.0,
      totalCost: underlaymentRolls * 96.0,
    });

    // 5. Self-Adhered Ice & Water Shield (Valleys + 2 courses on eaves)
    const leakBarrierLength = eavesFeet * 2 + valleysFeet;
    const iceWaterRolls = Math.max(1, Math.ceil(leakBarrierLength / 66));
    items.push({
      id: 'shingle-leak-barrier',
      category: 'underlayment',
      name: 'Ice & Water Leak Barrier',
      specification: 'Granular self-adhering SBS membrane (2 sq, 66 lin ft/roll)',
      coverageFormula: `${leakBarrierLength} lin ft barrier ÷ 66 ft/roll`,
      quantity: iceWaterRolls,
      unit: 'Rolls',
      unitCost: 118.0,
      totalCost: iceWaterRolls * 118.0,
    });

    // 6. Aluminum Drip Edge Flashing (10 ft lengths with 10% overlap)
    const dripEdgeSticks = Math.max(1, Math.ceil((perimeterLength * 1.1) / 10));
    items.push({
      id: 'shingle-drip-edge',
      category: 'starter_edge',
      name: 'Aluminum Drip Edge / T-Style Metal',
      specification: 'Pre-finished 2"x2" drip edge (10 ft sticks)',
      coverageFormula: `(${perimeterLength} ft + 10% lap) ÷ 10 ft/stick`,
      quantity: dripEdgeSticks,
      unit: 'Sticks (10ft)',
      unitCost: 14.5,
      totalCost: dripEdgeSticks * 14.5,
    });

    // 7. Electro-Galvanized Coil Roofing Nails (1-1/4" ring shank)
    const nailBoxes = Math.max(1, Math.ceil(grossSquares / 16));
    items.push({
      id: 'shingle-nails',
      category: 'fasteners',
      name: '1-1/4" Coil Roofing Nails',
      specification: 'Electro-galvanized ring shank (7,200 nails/box)',
      coverageFormula: `${grossSquares} gross sq ÷ 16 sq/box`,
      quantity: nailBoxes,
      unit: 'Boxes',
      unitCost: 46.0,
      totalCost: nailBoxes * 46.0,
    });

    // 8. Plastic Cap Underlayment Nails
    const capNailBoxes = Math.max(1, Math.ceil(grossSquares / 25));
    items.push({
      id: 'shingle-cap-nails',
      category: 'fasteners',
      name: '1" Plastic Round Top Cap Nails',
      specification: 'Underlayment button cap nails (2,000/box)',
      coverageFormula: `${grossSquares} gross sq ÷ 25 sq/box`,
      quantity: capNailBoxes,
      unit: 'Boxes',
      unitCost: 32.0,
      totalCost: capNailBoxes * 32.0,
    });

    // 9. Polyurethane Flashing Mastic / Roof Sealant
    const sealantTubes = Math.max(2, Math.ceil(grossSquares / 8));
    items.push({
      id: 'shingle-sealant',
      category: 'accessories',
      name: 'Elastomeric Roof Flashing Sealant',
      specification: '10.3 oz cartridges for penetrations and flashing joints',
      coverageFormula: `${grossSquares} gross sq ÷ 8 sq/tube`,
      quantity: sealantTubes,
      unit: 'Tubes',
      unitCost: 11.5,
      totalCost: sealantTubes * 11.5,
    });
  } else if (materialType === 'metal') {
    // 1. Standing Seam Metal Panels (16" wide 24ga)
    items.push({
      id: 'metal-panels',
      category: 'primary',
      name: '24ga Standing Seam Panels (16" width)',
      specification: 'Kynar 500 pre-formed snap-lock standing seam',
      coverageFormula: `${grossSquares} gross squares + 5% custom trim allowance`,
      quantity: Math.ceil(grossSquares * 1.05),
      unit: 'Squares (100 sf)',
      unitCost: 295.0,
      totalCost: Math.ceil(grossSquares * 1.05) * 295.0,
    });

    // 2. Ridge Cap Trim (10 ft lengths)
    const ridgeSticks = Math.max(1, Math.ceil((ridgesFeet * 1.1) / 10));
    items.push({
      id: 'metal-ridge',
      category: 'ridge_hip',
      name: 'Vented Standing Seam Ridge Cap (10ft)',
      specification: 'Matching 24ga brake-formed profile with perforated vents',
      coverageFormula: `(${ridgesFeet} lin ft + 10%) ÷ 10 ft/stick`,
      quantity: ridgeSticks,
      unit: 'Sticks (10ft)',
      unitCost: 52.0,
      totalCost: ridgeSticks * 52.0,
    });

    // 3. Eave Trim & Starter Cleat
    const eaveSticks = Math.max(1, Math.ceil((eavesFeet * 1.1) / 10));
    items.push({
      id: 'metal-eave',
      category: 'starter_edge',
      name: 'Eave Cleat & Drip Edge Trim (10ft)',
      specification: 'Continuous hold-down starter cleat (10 ft lengths)',
      coverageFormula: `(${eavesFeet} lin ft + 10%) ÷ 10 ft/stick`,
      quantity: eaveSticks,
      unit: 'Sticks (10ft)',
      unitCost: 38.0,
      totalCost: eaveSticks * 38.0,
    });

    // 4. Gable Rake Trim
    const rakeSticks = Math.max(1, Math.ceil((rakesFeet * 1.1) / 10));
    items.push({
      id: 'metal-rake',
      category: 'starter_edge',
      name: 'Gable Rake / Barge Trim (10ft)',
      specification: '24ga concealed edge rake flashing (10 ft lengths)',
      coverageFormula: `(${rakesFeet} lin ft + 10%) ÷ 10 ft/stick`,
      quantity: rakeSticks,
      unit: 'Sticks (10ft)',
      unitCost: 44.0,
      totalCost: rakeSticks * 44.0,
    });

    // 5. Open W-Valley Metal Flashing
    const valleySticks = Math.max(1, Math.ceil((valleysFeet * 1.1) / 10));
    items.push({
      id: 'metal-valley',
      category: 'starter_edge',
      name: 'Double Folded W-Valley Metal (10ft)',
      specification: '24" wide brake-formed center-rib valley pan',
      coverageFormula: `(${valleysFeet} lin ft + 10%) ÷ 10 ft/stick`,
      quantity: valleySticks,
      unit: 'Sticks (10ft)',
      unitCost: 58.0,
      totalCost: valleySticks * 58.0,
    });

    // 6. High-Temperature Metal Underlayment (250°F rated)
    const htRolls = Math.max(1, Math.ceil(grossSquares / 10));
    items.push({
      id: 'metal-ht-underlayment',
      category: 'underlayment',
      name: 'HT Self-Adhering Underlayment (250°F)',
      specification: 'High-temp SBS membrane formulated for metal thermal expansion',
      coverageFormula: `${grossSquares} gross sq ÷ 10 sq/roll`,
      quantity: htRolls,
      unit: 'Rolls (10 sq)',
      unitCost: 165.0,
      totalCost: htRolls * 165.0,
    });

    // 7. Concealed Stainless Steel Clips & Fasteners
    const clipBoxes = Math.max(1, Math.ceil((grossSquares * 75) / 500));
    items.push({
      id: 'metal-clips',
      category: 'fasteners',
      name: 'Expansion Panel Clips & Pancake Head Screws',
      specification: 'Stainless steel expansion clips + #10 screws (500/box)',
      coverageFormula: `(${grossSquares} gross sq × 75 clips/sq) ÷ 500/box`,
      quantity: clipBoxes,
      unit: 'Boxes',
      unitCost: 88.0,
      totalCost: clipBoxes * 88.0,
    });

    // 8. Expanding Foam Closures & Butyl Sealant Tape
    const butylRolls = Math.max(2, Math.ceil((ridgesFeet + eavesFeet + valleysFeet) / 40));
    items.push({
      id: 'metal-butyl',
      category: 'accessories',
      name: 'Double-Bead Butyl Sealant Tape (40ft)',
      specification: 'Non-curing water barrier for metal lap joints and closures',
      coverageFormula: `Perimeter joint footage ÷ 40 ft/roll`,
      quantity: butylRolls,
      unit: 'Rolls',
      unitCost: 19.5,
      totalCost: butylRolls * 19.5,
    });
  } else if (materialType === 'tile') {
    // 1. Concrete / Spanish Clay Field Tiles
    const tilePieces = Math.ceil(grossSquares * 95);
    items.push({
      id: 'tile-field',
      category: 'primary',
      name: 'Interlocking Spanish "S" Field Tile',
      specification: 'Class A concrete/clay curved profile (95 pieces/sq)',
      coverageFormula: `${grossSquares} gross sq × 95 pieces/sq`,
      quantity: tilePieces,
      unit: 'Pieces',
      unitCost: 3.85,
      totalCost: tilePieces * 3.85,
    });

    // 2. Ridge & Hip Barrel Trim Tiles
    const ridgeHipPieces = Math.ceil((ridgesFeet + hipsFeet) * 1.4);
    items.push({
      id: 'tile-ridge-hip',
      category: 'ridge_hip',
      name: 'Barrel Hip & Ridge Trim Tiles',
      specification: 'Interlocking cap tiles (1.4 pieces per lin ft)',
      coverageFormula: `(${ridgesFeet + hipsFeet} lin ft) × 1.4 pieces/ft`,
      quantity: ridgeHipPieces,
      unit: 'Pieces',
      unitCost: 7.2,
      totalCost: ridgeHipPieces * 7.2,
    });

    // 3. Double 40# Heavy Duty Underlayment
    const tileUnderlaymentRolls = Math.max(1, Math.ceil(grossSquares / 2));
    items.push({
      id: 'tile-underlayment',
      category: 'underlayment',
      name: '40# Self-Adhered Tile Underlayment',
      specification: 'Dual-layer reinforced modified bitumen (2 sq/roll)',
      coverageFormula: `${grossSquares} gross sq ÷ 2 sq/roll`,
      quantity: tileUnderlaymentRolls,
      unit: 'Rolls (2 sq)',
      unitCost: 112.0,
      totalCost: tileUnderlaymentRolls * 112.0,
    });

    // 4. Pressure-Treated Wood Battens (1x2, 10ft)
    const battenSticks = Math.ceil((grossSquares * 110) / 10);
    items.push({
      id: 'tile-battens',
      category: 'starter_edge',
      name: '1" × 2" Treated Wood Roof Battens (10ft)',
      specification: 'Elevated air-flow preservative treated battens',
      coverageFormula: `(${grossSquares} gross sq × 110 lin ft/sq) ÷ 10 ft/pc`,
      quantity: battenSticks,
      unit: 'Pieces (10ft)',
      unitCost: 6.8,
      totalCost: battenSticks * 6.8,
    });

    // 5. Corrosion Resistant Tile Screws / Wind Clips
    const screwBoxes = Math.max(1, Math.ceil((grossSquares * 95) / 1000));
    items.push({
      id: 'tile-screws',
      category: 'fasteners',
      name: '#10 Stainless Steel Tile Fasteners',
      specification: 'Ceramic-coated exterior tile screws (1,000/box)',
      coverageFormula: `(${grossSquares} gross sq × 95) ÷ 1,000/box`,
      quantity: screwBoxes,
      unit: 'Boxes',
      unitCost: 75.0,
      totalCost: screwBoxes * 75.0,
    });

    // 6. Eave Bird Stop Metal
    const birdStopSticks = Math.max(1, Math.ceil(eavesFeet / 10));
    items.push({
      id: 'tile-bird-stop',
      category: 'starter_edge',
      name: 'Aluminum Eave Bird Stop (10ft)',
      specification: 'Contoured pest barrier closure for tile eaves',
      coverageFormula: `${eavesFeet} lin ft eaves ÷ 10 ft/stick`,
      quantity: birdStopSticks,
      unit: 'Sticks (10ft)',
      unitCost: 22.0,
      totalCost: birdStopSticks * 22.0,
    });
  } else {
    // TPO Commercial Single-Ply Membrane
    // 1. 60-mil TPO Membrane (10' x 100' = 10 squares)
    const tpoRolls = Math.max(1, Math.ceil(grossSquares / 10));
    items.push({
      id: 'tpo-membrane',
      category: 'primary',
      name: '60-mil White Reflective TPO Membrane',
      specification: 'EnergyStar cool roof heat-weldable single-ply (10 sq/roll)',
      coverageFormula: `${grossSquares} gross sq ÷ 10 sq/roll`,
      quantity: tpoRolls,
      unit: 'Rolls (10 sq)',
      unitCost: 495.0,
      totalCost: tpoRolls * 495.0,
    });

    // 2. 2.0" Polyisocyanurate Rigid Insulation Boards (4'x8' = 32 sq ft)
    const isoBoards = Math.ceil((grossAreaSqFt / 32) * 1.05);
    items.push({
      id: 'tpo-iso',
      category: 'underlayment',
      name: '2.0" Polyiso Roof Insulation (R-11.4)',
      specification: '4ft × 8ft rigid closed-cell polyiso foam core boards',
      coverageFormula: `(${grossAreaSqFt} gross sq ft ÷ 32 sf/board) + 5% waste`,
      quantity: isoBoards,
      unit: 'Boards (4x8)',
      unitCost: 39.0,
      totalCost: isoBoards * 39.0,
    });

    // 3. Heavy-Duty Insulation Screws & 3" Stress Plates
    const platePails = Math.max(1, Math.ceil((isoBoards * 5) / 500));
    items.push({
      id: 'tpo-plates',
      category: 'fasteners',
      name: 'Heavy-Duty Screws & 3" Galvalume Plates',
      specification: '#14 drill-point fasteners with 3" barbed stress plates (500/pail)',
      coverageFormula: `(${isoBoards} boards × 5 plates/board) ÷ 500/pail`,
      quantity: platePails,
      unit: 'Pails (500)',
      unitCost: 135.0,
      totalCost: platePails * 135.0,
    });

    // 4. Solvent-Based Bonding Adhesive
    const adhesivePails = Math.max(1, Math.ceil(grossSquares / 3.5));
    items.push({
      id: 'tpo-adhesive',
      category: 'accessories',
      name: 'TPO Substrate Bonding Adhesive',
      specification: '5-Gallon pails for single-ply adherence (60 sq ft/gal)',
      coverageFormula: `${grossSquares} gross sq ÷ 3.5 sq/pail`,
      quantity: adhesivePails,
      unit: 'Pails (5-gal)',
      unitCost: 210.0,
      totalCost: adhesivePails * 210.0,
    });

    // 5. TPO-Coated Metal Edge Flashing
    const edgeSticks = Math.max(1, Math.ceil(eavesFeet / 10));
    items.push({
      id: 'tpo-edge-metal',
      category: 'starter_edge',
      name: 'TPO-Clad Drip Edge Fascia Metal (10ft)',
      specification: '24ga galvanized steel with 25-mil laminated TPO film',
      coverageFormula: `${eavesFeet} lin ft eaves ÷ 10 ft/stick`,
      quantity: edgeSticks,
      unit: 'Sticks (10ft)',
      unitCost: 48.0,
      totalCost: edgeSticks * 48.0,
    });

    // 6. Prefabricated Pipe Boots & Flashing Corners
    const bootSets = Math.max(2, Math.ceil(grossSquares / 12));
    items.push({
      id: 'tpo-boots',
      category: 'accessories',
      name: 'Molded TPO Pipe Boots & Universal Corners',
      specification: 'Pre-molded heat-weldable flashing accessories',
      coverageFormula: `Standard commercial roof penetration allowance`,
      quantity: bootSets,
      unit: 'Sets',
      unitCost: 36.0,
      totalCost: bootSets * 36.0,
    });
  }

  const totalMaterialCost = Math.round(items.reduce((sum, item) => sum + item.totalCost, 0));
  const costPerSquare = grossSquares > 0 ? Math.round(totalMaterialCost / grossSquares) : 0;

  return {
    materialType,
    materialName: MATERIAL_PROFILES[materialType].name,
    netAreaSqFt,
    netSquares,
    wastePercent,
    grossAreaSqFt,
    grossSquares,
    linearEdges: {
      eaves: eavesFeet,
      ridges: ridgesFeet,
      hips: hipsFeet,
      valleys: valleysFeet,
      rakes: rakesFeet,
      totalLinearFeet,
    },
    items,
    totalMaterialCost,
    costPerSquare,
  };
}
