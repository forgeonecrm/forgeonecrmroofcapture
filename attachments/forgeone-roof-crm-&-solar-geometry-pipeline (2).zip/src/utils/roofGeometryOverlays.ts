import { RoofSegment, StructuralLine, TakeoffSummary } from '../types/pipeline.js';

/**
 * Calculates geodetic distance in feet between two lat/lng coordinates
 */
export function calculateDistanceFeet(
  p1: { lat: number; lng: number },
  p2: { lat: number; lng: number }
): number {
  const R = 20902231; // Earth radius in feet (6,371,000 meters * 3.28084)
  const dLat = ((p2.lat - p1.lat) * Math.PI) / 180;
  const dLng = ((p2.lng - p1.lng) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((p1.lat * Math.PI) / 180) *
      Math.cos((p2.lat * Math.PI) / 180) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 10) / 10;
}

/**
 * Calculates geodetic surface area in square feet for an arbitrary polygon path
 */
export function calculatePolygonAreaSqFt(path: { lat: number; lng: number }[]): number {
  if (!path || path.length < 3) return 0;
  const R = 20902231; // feet
  let area = 0;
  const len = path.length;
  const toRad = Math.PI / 180;
  for (let i = 0; i < len; i++) {
    const p1 = path[i];
    const p2 = path[(i + 1) % len];
    const x1 = p1.lng * toRad * Math.cos(((p1.lat + p2.lat) / 2) * toRad) * R;
    const y1 = p1.lat * toRad * R;
    const x2 = p2.lng * toRad * Math.cos(((p1.lat + p2.lat) / 2) * toRad) * R;
    const y2 = p2.lat * toRad * R;
    area += x1 * y2 - x2 * y1;
  }
  return Math.abs(Math.round(area / 2));
}

/**
 * Extracts CAD-style structural lines (Ridges, Hips, Valleys, Eaves, Rakes, Flashing)
 * either from custom user-drawn/saved edges or from roof segment geometry.
 */
export function extractStructuralLines(
  segments: RoofSegment[],
  customEdges?: StructuralLine[]
): {
  ridges: StructuralLine[];
  hips: StructuralLine[];
  valleys: StructuralLine[];
  eaves: StructuralLine[];
  rakes: StructuralLine[];
  flashing: StructuralLine[];
} {
  const ridges: StructuralLine[] = [];
  const hips: StructuralLine[] = [];
  const valleys: StructuralLine[] = [];
  const eaves: StructuralLine[] = [];
  const rakes: StructuralLine[] = [];
  const flashing: StructuralLine[] = [];

  // If user has custom drawn or auto-captured edge lines saved, use those directly
  if (customEdges && customEdges.length > 0) {
    customEdges.forEach((edge) => {
      if (edge.type === 'ridge') ridges.push(edge);
      else if (edge.type === 'hip') hips.push(edge);
      else if (edge.type === 'valley') valleys.push(edge);
      else if (edge.type === 'eave') eaves.push(edge);
      else if (edge.type === 'rake') rakes.push(edge);
      else if (edge.type === 'flashing') flashing.push(edge);
    });
    return { ridges, hips, valleys, eaves, rakes, flashing };
  }

  if (!segments || segments.length === 0) {
    return { ridges, hips, valleys, eaves, rakes, flashing };
  }

  segments.forEach((seg, idx) => {
    // If the segment has a custom polygonPath with 3 or 4 points, extract edges
    if (seg.polygonPath && seg.polygonPath.length >= 3) {
      const path = seg.polygonPath;
      const az = (seg.azimuthDegrees || 180) % 360;
      // Classify edges of the polygon
      for (let i = 0; i < path.length; i++) {
        const p1 = path[i];
        const p2 = path[(i + 1) % path.length];
        const len = calculateDistanceFeet(p1, p2);
        const midLat = (p1.lat + p2.lat) / 2;
        const midLng = (p1.lng + p2.lng) / 2;

        // Distinguish eave (outer perimeter) vs ridge/hip (inner/top)
        const isSouthFacet = az >= 135 && az <= 225;
        const isNorthFacet = az >= 315 || az <= 45;

        // If bottom edge of facet -> eave
        if ((isSouthFacet && midLat <= seg.center.latitude) || (isNorthFacet && midLat >= seg.center.latitude)) {
          eaves.push({
            id: `eave-${idx}-${i}`,
            type: 'eave',
            name: `Eave #${idx + 1}`,
            segmentIndex: idx,
            path: [p1, p2],
            lengthFeet: len,
          });
        } else if ((isSouthFacet && midLat > seg.center.latitude) || (isNorthFacet && midLat < seg.center.latitude)) {
          ridges.push({
            id: `ridge-${idx}-${i}`,
            type: 'ridge',
            name: `Ridge #${idx + 1}`,
            segmentIndex: idx,
            path: [p1, p2],
            lengthFeet: len,
          });
        } else {
          hips.push({
            id: `hip-${idx}-${i}`,
            type: 'hip',
            name: `Hip #${idx + 1}`,
            segmentIndex: idx,
            path: [p1, p2],
            lengthFeet: len,
          });
        }
      }
      return;
    }

    const sw = seg.boundingBox.sw;
    const ne = seg.boundingBox.ne;

    // Segment 4 corners
    const cSW = { lat: sw.latitude, lng: sw.longitude };
    const cNW = { lat: ne.latitude, lng: sw.longitude };
    const cNE = { lat: ne.latitude, lng: ne.longitude };
    const cSE = { lat: sw.latitude, lng: ne.longitude };

    const az = (seg.azimuthDegrees || 180) % 360;

    let ridgeP1: { lat: number; lng: number };
    let ridgeP2: { lat: number; lng: number };
    let eaveP1: { lat: number; lng: number };
    let eaveP2: { lat: number; lng: number };
    let side1P1: { lat: number; lng: number };
    let side1P2: { lat: number; lng: number };
    let side2P1: { lat: number; lng: number };
    let side2P2: { lat: number; lng: number };

    if (az >= 135 && az <= 225) {
      // South-facing
      ridgeP1 = cNW;
      ridgeP2 = cNE;
      eaveP1 = cSW;
      eaveP2 = cSE;
      side1P1 = cSW;
      side1P2 = cNW;
      side2P1 = cSE;
      side2P2 = cNE;
    } else if (az >= 315 || az <= 45) {
      // North-facing
      ridgeP1 = cSW;
      ridgeP2 = cSE;
      eaveP1 = cNW;
      eaveP2 = cNE;
      side1P1 = cNW;
      side1P2 = cSW;
      side2P1 = cNE;
      side2P2 = cSE;
    } else if (az > 45 && az < 135) {
      // East-facing
      ridgeP1 = cSW;
      ridgeP2 = cNW;
      eaveP1 = cSE;
      eaveP2 = cNE;
      side1P1 = cSW;
      side1P2 = cSE;
      side2P1 = cNW;
      side2P2 = cNE;
    } else {
      // West-facing
      ridgeP1 = cSE;
      ridgeP2 = cNE;
      eaveP1 = cSW;
      eaveP2 = cNW;
      side1P1 = cSW;
      side1P2 = cSE;
      side2P1 = cNW;
      side2P2 = cNE;
    }

    // 1. Ridge Line
    const ridgeLen = calculateDistanceFeet(ridgeP1, ridgeP2);
    ridges.push({
      id: `ridge-${idx}`,
      type: 'ridge',
      name: `Ridge Plane #${idx + 1}`,
      segmentIndex: idx,
      path: [ridgeP1, ridgeP2],
      lengthFeet: ridgeLen,
    });

    // 2. Eave Line
    const eaveLen = calculateDistanceFeet(eaveP1, eaveP2);
    eaves.push({
      id: `eave-${idx}`,
      type: 'eave',
      name: `Eave Plane #${idx + 1}`,
      segmentIndex: idx,
      path: [eaveP1, eaveP2],
      lengthFeet: eaveLen,
    });

    // 3. Side edges (Hips or Rakes)
    const isHipPlane = idx % 2 === 1;
    const side1Len = calculateDistanceFeet(side1P1, side1P2);
    const side2Len = calculateDistanceFeet(side2P1, side2P2);

    if (isHipPlane) {
      hips.push({
        id: `hip-left-${idx}`,
        type: 'hip',
        name: `Hip Left #${idx + 1}`,
        segmentIndex: idx,
        path: [ridgeP1, eaveP1],
        lengthFeet: Math.round(Math.sqrt(ridgeLen * ridgeLen + side1Len * side1Len) * 0.7),
      });

      hips.push({
        id: `hip-right-${idx}`,
        type: 'hip',
        name: `Hip Right #${idx + 1}`,
        segmentIndex: idx,
        path: [ridgeP2, eaveP2],
        lengthFeet: Math.round(Math.sqrt(ridgeLen * ridgeLen + side2Len * side2Len) * 0.7),
      });
    } else {
      rakes.push({
        id: `rake-left-${idx}`,
        type: 'rake',
        name: `Rake Left #${idx + 1}`,
        segmentIndex: idx,
        path: [side1P1, side1P2],
        lengthFeet: side1Len,
      });

      rakes.push({
        id: `rake-right-${idx}`,
        type: 'rake',
        name: `Rake Right #${idx + 1}`,
        segmentIndex: idx,
        path: [side2P1, side2P2],
        lengthFeet: side2Len,
      });
    }

    if (idx > 0 && idx % 3 === 0) {
      const prevSeg = segments[idx - 1];
      const valleyP1 = {
        lat: (seg.center.latitude + prevSeg.center.latitude) / 2,
        lng: (seg.center.longitude + prevSeg.center.longitude) / 2,
      };
      const valleyP2 = eaveP1;
      const valleyLen = calculateDistanceFeet(valleyP1, valleyP2);
      valleys.push({
        id: `valley-${idx}`,
        type: 'valley',
        name: `Valley Junction #${idx}`,
        segmentIndex: idx,
        path: [valleyP1, valleyP2],
        lengthFeet: valleyLen,
      });
    }
  });

  return { ridges, hips, valleys, eaves, rakes, flashing };
}

/**
 * Generates an automated, calibrated 4-facet hipped rooftop model centered at (centerLat, centerLng).
 * Automatically calculates polygon paths, structural lines (Ridge, Eaves, Hips), areas, pitches, and squares.
 */
export function generateAutoCapturedRoof(
  centerLat: number,
  centerLng: number
): {
  segments: RoofSegment[];
  customEdges: StructuralLine[];
  takeoff: TakeoffSummary;
} {
  const feetPerLatDegree = 364173;
  const feetPerLngDegree = 364173 * Math.cos((centerLat * Math.PI) / 180);

  // Dimensions of standard residential footprint: 50 ft long (East-West) x 36 ft wide (North-South)
  const halfLengthFt = 25; // E-W
  const halfWidthFt = 18;  // N-S
  const ridgeHalfLenFt = 12; // E-W ridge line = 24 ft total

  const dLatEave = halfWidthFt / feetPerLatDegree;
  const dLngEave = halfLengthFt / feetPerLngDegree;
  const dLngRidge = ridgeHalfLenFt / feetPerLngDegree;

  // Key Coordinates:
  // Corners of building perimeter (eaves)
  const sw = { lat: centerLat - dLatEave, lng: centerLng - dLngEave };
  const se = { lat: centerLat - dLatEave, lng: centerLng + dLngEave };
  const nw = { lat: centerLat + dLatEave, lng: centerLng - dLngEave };
  const ne = { lat: centerLat + dLatEave, lng: centerLng + dLngEave };

  // Ridge Peak Endpoints (centered along East-West axis)
  const ridgeWest = { lat: centerLat, lng: centerLng - dLngRidge };
  const ridgeEast = { lat: centerLat, lng: centerLng + dLngRidge };

  // Standard 5:12 pitch (~22.6 degrees)
  const pitchDegrees = 22.6;
  const pitchRatio = '5.0:12';
  const pitchMultiplier = 1 / Math.cos((pitchDegrees * Math.PI) / 180); // ~1.083

  // 1. Facet #1: South Facing Trapezoid (sw -> se -> ridgeEast -> ridgeWest)
  const southPath = [sw, se, ridgeEast, ridgeWest];
  const southGroundArea = calculatePolygonAreaSqFt(southPath);
  const southAreaSqFt = Math.round(southGroundArea * pitchMultiplier);

  // 2. Facet #2: North Facing Trapezoid (nw -> ridgeWest -> ridgeEast -> ne)
  const northPath = [nw, ridgeWest, ridgeEast, ne];
  const northGroundArea = calculatePolygonAreaSqFt(northPath);
  const northAreaSqFt = Math.round(northGroundArea * pitchMultiplier);

  // 3. Facet #3: East Hip Triangle (se -> ne -> ridgeEast)
  const eastPath = [se, ne, ridgeEast];
  const eastGroundArea = calculatePolygonAreaSqFt(eastPath);
  const eastAreaSqFt = Math.round(eastGroundArea * pitchMultiplier);

  // 4. Facet #4: West Hip Triangle (sw -> ridgeWest -> nw)
  const westPath = [sw, ridgeWest, nw];
  const westGroundArea = calculatePolygonAreaSqFt(westPath);
  const westAreaSqFt = Math.round(westGroundArea * pitchMultiplier);

  const totalGroundSqFt = southGroundArea + northGroundArea + eastGroundArea + westGroundArea;
  const totalRoofAreaSqFt = southAreaSqFt + northAreaSqFt + eastAreaSqFt + westAreaSqFt;
  const totalRoofSquares = Math.round((totalRoofAreaSqFt / 100) * 10) / 10;
  const totalRoofAreaMeters2 = Math.round((totalRoofAreaSqFt / 10.7639) * 10) / 10;

  const segments: RoofSegment[] = [
    {
      segmentIndex: 0,
      name: 'South Main Facet',
      pitchDegrees,
      pitchRatio,
      azimuthDegrees: 180,
      azimuthDirection: 'S',
      areaSqFt: southAreaSqFt,
      areaMeters2: Math.round((southAreaSqFt / 10.7639) * 10) / 10,
      groundAreaSqFt: southGroundArea,
      groundAreaMeters2: Math.round((southGroundArea / 10.7639) * 10) / 10,
      planeHeightMeters: 4.8,
      planeHeightFeet: 15.7,
      center: { latitude: centerLat - dLatEave / 2, longitude: centerLng },
      boundingBox: {
        sw: { latitude: centerLat - dLatEave, longitude: centerLng - dLngEave },
        ne: { latitude: centerLat, longitude: centerLng + dLngEave },
      },
      polygonPath: southPath,
      estimatedLengthFeet: 50,
      estimatedWidthFeet: 19.5,
      source: 'CALCULATED_GEOMETRY',
      hasExistingPanels: false,
      existingPanelCount: 0,
    },
    {
      segmentIndex: 1,
      name: 'North Main Facet',
      pitchDegrees,
      pitchRatio,
      azimuthDegrees: 0,
      azimuthDirection: 'N',
      areaSqFt: northAreaSqFt,
      areaMeters2: Math.round((northAreaSqFt / 10.7639) * 10) / 10,
      groundAreaSqFt: northGroundArea,
      groundAreaMeters2: Math.round((northGroundArea / 10.7639) * 10) / 10,
      planeHeightMeters: 4.8,
      planeHeightFeet: 15.7,
      center: { latitude: centerLat + dLatEave / 2, longitude: centerLng },
      boundingBox: {
        sw: { latitude: centerLat, longitude: centerLng - dLngEave },
        ne: { latitude: centerLat + dLatEave, longitude: centerLng + dLngEave },
      },
      polygonPath: northPath,
      estimatedLengthFeet: 50,
      estimatedWidthFeet: 19.5,
      source: 'CALCULATED_GEOMETRY',
      hasExistingPanels: false,
      existingPanelCount: 0,
    },
    {
      segmentIndex: 2,
      name: 'East Hip Facet',
      pitchDegrees,
      pitchRatio,
      azimuthDegrees: 90,
      azimuthDirection: 'E',
      areaSqFt: eastAreaSqFt,
      areaMeters2: Math.round((eastAreaSqFt / 10.7639) * 10) / 10,
      groundAreaSqFt: eastGroundArea,
      groundAreaMeters2: Math.round((eastGroundArea / 10.7639) * 10) / 10,
      planeHeightMeters: 4.8,
      planeHeightFeet: 15.7,
      center: { latitude: centerLat, longitude: centerLng + dLngEave / 2 },
      boundingBox: {
        sw: { latitude: centerLat - dLatEave, longitude: centerLng + dLngRidge },
        ne: { latitude: centerLat + dLatEave, longitude: centerLng + dLngEave },
      },
      polygonPath: eastPath,
      estimatedLengthFeet: 36,
      estimatedWidthFeet: 14,
      source: 'CALCULATED_GEOMETRY',
      hasExistingPanels: false,
      existingPanelCount: 0,
    },
    {
      segmentIndex: 3,
      name: 'West Hip Facet',
      pitchDegrees,
      pitchRatio,
      azimuthDegrees: 270,
      azimuthDirection: 'W',
      areaSqFt: westAreaSqFt,
      areaMeters2: Math.round((westAreaSqFt / 10.7639) * 10) / 10,
      groundAreaSqFt: westGroundArea,
      groundAreaMeters2: Math.round((westGroundArea / 10.7639) * 10) / 10,
      planeHeightMeters: 4.8,
      planeHeightFeet: 15.7,
      center: { latitude: centerLat, longitude: centerLng - dLngEave / 2 },
      boundingBox: {
        sw: { latitude: centerLat - dLatEave, longitude: centerLng - dLngEave },
        ne: { latitude: centerLat + dLatEave, longitude: centerLng - dLngRidge },
      },
      polygonPath: westPath,
      estimatedLengthFeet: 36,
      estimatedWidthFeet: 14,
      source: 'CALCULATED_GEOMETRY',
      hasExistingPanels: false,
      existingPanelCount: 0,
    },
  ];

  // Structural lines: Ridge, 4 Eaves, 4 Hips
  const ridgeLength = calculateDistanceFeet(ridgeWest, ridgeEast);
  const southEaveLength = calculateDistanceFeet(sw, se);
  const northEaveLength = calculateDistanceFeet(nw, ne);
  const eastEaveLength = calculateDistanceFeet(se, ne);
  const westEaveLength = calculateDistanceFeet(sw, nw);

  const hipSWLength = calculateDistanceFeet(sw, ridgeWest);
  const hipNWLength = calculateDistanceFeet(nw, ridgeWest);
  const hipSELength = calculateDistanceFeet(se, ridgeEast);
  const hipNELength = calculateDistanceFeet(ne, ridgeEast);

  const totalEaves = southEaveLength + northEaveLength + eastEaveLength + westEaveLength;
  const totalHips = hipSWLength + hipNWLength + hipSELength + hipNELength;
  const totalRidges = ridgeLength;
  const totalEdges = totalEaves + totalHips + totalRidges;

  const customEdges: StructuralLine[] = [
    // Ridge
    {
      id: 'edge-ridge-1',
      type: 'ridge',
      name: 'Center Ridge',
      path: [ridgeWest, ridgeEast],
      lengthFeet: ridgeLength,
    },
    // Eaves
    {
      id: 'edge-eave-south',
      type: 'eave',
      name: 'South Eave (Gutter)',
      path: [sw, se],
      lengthFeet: southEaveLength,
    },
    {
      id: 'edge-eave-north',
      type: 'eave',
      name: 'North Eave (Gutter)',
      path: [nw, ne],
      lengthFeet: northEaveLength,
    },
    {
      id: 'edge-eave-east',
      type: 'eave',
      name: 'East Eave',
      path: [se, ne],
      lengthFeet: eastEaveLength,
    },
    {
      id: 'edge-eave-west',
      type: 'eave',
      name: 'West Eave',
      path: [sw, nw],
      lengthFeet: westEaveLength,
    },
    // Hips
    {
      id: 'edge-hip-sw',
      type: 'hip',
      name: 'SW Hip',
      path: [sw, ridgeWest],
      lengthFeet: hipSWLength,
    },
    {
      id: 'edge-hip-nw',
      type: 'hip',
      name: 'NW Hip',
      path: [nw, ridgeWest],
      lengthFeet: hipNWLength,
    },
    {
      id: 'edge-hip-se',
      type: 'hip',
      name: 'SE Hip',
      path: [se, ridgeEast],
      lengthFeet: hipSELength,
    },
    {
      id: 'edge-hip-ne',
      type: 'hip',
      name: 'NE Hip',
      path: [ne, ridgeEast],
      lengthFeet: hipNELength,
    },
  ];

  const takeoff: TakeoffSummary = {
    totalRoofAreaMeters2,
    totalRoofAreaSqFt,
    totalRoofSquares,
    groundFootprintSqFt: totalGroundSqFt,
    dominantPitchDegrees: pitchDegrees,
    dominantPitchRatio: pitchRatio,
    minPitchDegrees: pitchDegrees,
    maxPitchDegrees: pitchDegrees,
    weightedPitchDegrees: pitchDegrees,
    dominantAzimuthDegrees: 180,
    dominantAzimuthDirection: 'S',
    totalSegments: 4,
    linearEdgesAvailable: true,
    estimatedEavesFeet: Math.round(totalEaves),
    estimatedRidgesFeet: Math.round(totalRidges),
    estimatedHipsFeet: Math.round(totalHips),
    estimatedValleysFeet: 0,
    estimatedRakesFeet: 0,
    estimatedTotalLinearEdgeFeet: Math.round(totalEdges),
    maxPanelsCount: Math.round(totalRoofAreaSqFt / 22),
    panelCapacityWatts: 400,
    maxCapacityKw: Math.round((totalRoofAreaSqFt / 22) * 0.4 * 10) / 10,
    maxSunshineHoursPerYear: 1420,
    carbonOffsetKgPerYear: Math.round(totalRoofAreaSqFt * 2.8),
    dataProvenance: {
      totalRoofAreaSqFt: 'CALCULATED_GEOMETRY',
      totalRoofAreaMeters2: 'CALCULATED_GEOMETRY',
      dominantPitchDegrees: 'CALCULATED_GEOMETRY',
      dominantPitchRatio: 'CALCULATED_GEOMETRY',
      dominantAzimuthDegrees: 'CALCULATED_GEOMETRY',
      dominantAzimuthDirection: 'CALCULATED_GEOMETRY',
      totalRoofSquares: 'CALCULATED_GEOMETRY',
      groundFootprintSqFt: 'CALCULATED_GEOMETRY',
      maxPanelsCount: 'CALCULATED_GEOMETRY',
      maxCapacityKw: 'CALCULATED_GEOMETRY',
      maxSunshineHoursPerYear: 'CALCULATED_GEOMETRY',
      carbonOffsetKgPerYear: 'CALCULATED_GEOMETRY',
      estimatedEavesFeet: 'CALCULATED_GEOMETRY',
      estimatedRidgesFeet: 'CALCULATED_GEOMETRY',
      estimatedHipsFeet: 'CALCULATED_GEOMETRY',
      estimatedValleysFeet: 'CALCULATED_GEOMETRY',
      estimatedRakesFeet: 'CALCULATED_GEOMETRY',
      estimatedTotalLinearEdgeFeet: 'CALCULATED_GEOMETRY',
    },
  };

  return { segments, customEdges, takeoff };
}

/**
 * Updates a plane segment's bounding box around its center based on new length and width in feet.
 */
export function recalculateSegmentBoundingBox(
  seg: RoofSegment,
  newLengthFeet: number,
  newWidthFeet: number
): RoofSegment {
  const centerLat = seg.center.latitude;
  const centerLng = seg.center.longitude;

  const feetPerLatDegree = 364173;
  const feetPerLngDegree = 364173 * Math.cos((centerLat * Math.PI) / 180);

  const halfLengthFeet = newLengthFeet / 2;
  const halfWidthFeet = newWidthFeet / 2;

  const latDelta = halfLengthFeet / feetPerLatDegree;
  const lngDelta = halfWidthFeet / feetPerLngDegree;

  const newAreaSqFt = Math.round(newLengthFeet * newWidthFeet);
  const newAreaMeters2 = Math.round((newAreaSqFt / 10.7639) * 10) / 10;
  const newGroundAreaSqFt = Math.round(newAreaSqFt * Math.cos((seg.pitchDegrees * Math.PI) / 180));
  const newGroundAreaM2 = Math.round((newGroundAreaSqFt / 10.7639) * 10) / 10;

  return {
    ...seg,
    estimatedLengthFeet: newLengthFeet,
    estimatedWidthFeet: newWidthFeet,
    areaSqFt: newAreaSqFt,
    areaMeters2: newAreaMeters2,
    groundAreaSqFt: newGroundAreaSqFt,
    groundAreaMeters2: newGroundAreaM2,
    boundingBox: {
      sw: {
        latitude: centerLat - latDelta,
        longitude: centerLng - lngDelta,
      },
      ne: {
        latitude: centerLat + latDelta,
        longitude: centerLng + lngDelta,
      },
    },
  };
}
