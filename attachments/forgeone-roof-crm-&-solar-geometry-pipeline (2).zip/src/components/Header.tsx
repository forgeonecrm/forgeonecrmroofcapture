import React from 'react';
import { Building2, Plus, ShieldCheck, MapPin } from 'lucide-react';
import { TenantInfo } from '../types/pipeline.js';

interface HeaderProps {
  tenants: TenantInfo[];
  selectedTenantId: string;
  onSelectTenant: (tenantId: string) => void;
  onOpenIntakeModal: () => void;
  onOpenDiagnostics: () => void;
  activeTab: 'pipeline' | 'map' | 'compliance';
  setActiveTab: (tab: 'pipeline' | 'map' | 'compliance') => void;
}

export const Header: React.FC<HeaderProps> = ({
  tenants,
  selectedTenantId,
  onSelectTenant,
  onOpenIntakeModal,
  onOpenDiagnostics,
  activeTab,
  setActiveTab,
}) => {
  const currentTenant = tenants.find((t) => t.id === selectedTenantId) || tenants[0];

  return (
    <header className="flex items-center justify-between gap-8 px-6 py-3.5 bg-slate-900 border-b border-slate-800 shrink-0 z-30">
      {/* Zone 1: Single text element Brand Wordmark */}
      <div className="flex items-center gap-3">
        <a
          href="#"
          onClick={(e) => {
            e.preventDefault();
            setActiveTab('pipeline');
          }}
          className="text-lg font-bold tracking-tight text-white whitespace-nowrap shrink-0 hover:text-cyan-400 transition-colors"
        >
          ForgeOne CRM
        </a>
        <span className="hidden sm:inline-block text-xs font-mono text-slate-500 uppercase tracking-wider pl-2 border-l border-slate-800">
          Phase 1 Pipeline
        </span>
      </div>

      {/* Zone 2: Navigation Links (single line whitespace-nowrap) */}
      <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-400">
        <button
          onClick={() => setActiveTab('pipeline')}
          className={`hover:text-white transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'pipeline' ? 'text-cyan-400 font-semibold' : ''
          }`}
        >
          Properties Pipeline
        </button>
        <button
          onClick={() => setActiveTab('map')}
          className={`hover:text-white transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'map' ? 'text-cyan-400 font-semibold' : ''
          }`}
        >
          Roof Takeoff Canvas
        </button>
        <button
          onClick={() => setActiveTab('compliance')}
          className={`hover:text-white transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
            activeTab === 'compliance' ? 'text-cyan-400 font-semibold' : ''
          }`}
        >
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          Anti-Caching &amp; ToS
        </button>
        <button
          onClick={onOpenDiagnostics}
          className="hover:text-white transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 text-slate-300 hover:text-cyan-300"
        >
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
          <span>API Diagnostics</span>
        </button>
      </nav>

      {/* Zone 3: Primary Action & Tenant Switcher */}
      <div className="flex items-center gap-3 shrink-0">
        <div className="relative flex items-center bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-300">
          <Building2 className="w-3.5 h-3.5 mr-2 text-cyan-400 shrink-0" />
          <select
            value={selectedTenantId}
            onChange={(e) => onSelectTenant(e.target.value)}
            className="bg-transparent text-slate-200 outline-none cursor-pointer pr-1 text-xs font-medium"
            aria-label="Select CRM Tenant"
          >
            {tenants.map((tenant) => (
              <option key={tenant.id} value={tenant.id} className="bg-slate-900 text-slate-200">
                {tenant.name}
              </option>
            ))}
          </select>
        </div>

        <button
          onClick={onOpenIntakeModal}
          className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-cyan-600 hover:bg-cyan-500 rounded-lg shadow-sm transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Intake Address</span>
        </button>
      </div>
    </header>
  );
};
