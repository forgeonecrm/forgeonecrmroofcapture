import React, { useEffect, useState, useMemo, useRef, useCallback } from 'react';
import {
  Map,
  AdvancedMarker,
  InfoWindow,
  useMap,
  useMapsLibrary,
} from '@vis.gl/react-google-maps';
import {
  PropertyRecord,
  RoofSegment,
  StructuralVisibility,
  StructuralLine,
  TakeoffSummary,
} from '../types/pipeline.js';
import {
  extractStructuralLines,
  calculateDistanceFeet,
  calculatePolygonAreaSqFt,
  generateAutoCapturedRoof,
} from '../utils/roofGeometryOverlays.js';
import {
  Compass,
  Layers,
  Sparkles,
  Eye,
  EyeOff,
  Activity,
  Check,
  Globe2,
  Home,
  MapPin,
  Building,
  MousePointer,
  Move,
  PenTool,
  Shapes,
  Trash2,
  Save,
  RotateCcw,
  Wand2,
  Plus,
  X,
  AlertCircle,
  HelpCircle,
} from 'lucide-react';

interface RoofGeometryMapProps {
  property: PropertyRecord | null;
  allProperties?: PropertyRecord[];
  selectedSegmentIndex: number | null;
  onSelectSegment: (index: number | null) => void;
  onSelectProperty?: (property: PropertyRecord) => void;
  structuralVisibility: StructuralVisibility;
  onToggleStructuralVisibility: (key: keyof StructuralVisibility) => void;
  onPropertyUpdated?: (updatedProperty: PropertyRecord) => void;
}

// Center of Continental United States
const USA_CENTER = { lat: 39.8283, lng: -98.5795 };
const USA_ZOOM = 4;

type CadToolMode = 'select' | 'edit_handles' | 'draw_edge' | 'draw_facet' | 'delete';
type EdgeType = 'ridge' | 'hip' | 'valley' | 'eave' | 'rake' | 'flashing';

const EDGE_CONFIG: Record<
  EdgeType,
  { label: string; color: string; hex: string; weight: number; zIndex: number }
> = {
  ridge: { label: 'Ridge', color: 'text-red-400', hex: '#ef4444', weight: 4.5, zIndex: 120 },
  eave: { label: 'Eave', color: 'text-emerald-400', hex: '#10b981', weight: 4, zIndex: 105 },
  hip: { label: 'Hip', color: 'text-orange-400', hex: '#f97316', weight: 4, zIndex: 115 },
  valley: { label: 'Valley', color: 'text-cyan-400', hex: '#06b6d4', weight: 4, zIndex: 110 },
  rake: { label: 'Rake', color: 'text-purple-400', hex: '#a855f7', weight: 3.5, zIndex: 100 },
  flashing: { label: 'Flashing', color: 'text-yellow-400', hex: '#eab308', weight: 3.5, zIndex: 95 },
};

export const RoofGeometryMap: React.FC<RoofGeometryMapProps> = ({
  property,
  allProperties = [],
  selectedSegmentIndex,
  onSelectSegment,
  onSelectProperty,
  structuralVisibility,
  onToggleStructuralVisibility,
  onPropertyUpdated,
}) => {
  const map = useMap();
  const mapsLibrary = useMapsLibrary('maps');
  const [mapTypeId, setMapTypeId] = useState<google.maps.MapTypeId | string>('hybrid');
  const [activeInfoWindow, setActiveInfoWindow] = useState<RoofSegment | null>(null);
  const [isUsaOverview, setIsUsaOverview] = useState<boolean>(false);

  // CAD Drawing & Editing State
  const [cadTool, setCadTool] = useState<CadToolMode>('select');
  const [activeEdgeType, setActiveEdgeType] = useState<EdgeType>('ridge');
  const [drawingLineStart, setDrawingLineStart] = useState<{ lat: number; lng: number } | null>(null);
  const [currentMousePoint, setCurrentMousePoint] = useState<{ lat: number; lng: number } | null>(null);
  const [drawingPolygonPoints, setDrawingPolygonPoints] = useState<{ lat: number; lng: number }[]>([]);
  const [selectedPitchRatio, setSelectedPitchRatio] = useState<string>('5.0:12');
  const [cadMessage, setCadMessage] = useState<string | null>(null);
  const [isSavingTakeoff, setIsSavingTakeoff] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // References to active Google Maps overlays
  const polygonsRef = useRef<google.maps.Polygon[]>([]);
  const polylinesRef = useRef<google.maps.Polyline[]>([]);
  const previewPolylineRef = useRef<google.maps.Polyline | null>(null);
  const previewPolygonRef = useRef<google.maps.Polygon | null>(null);
  const previewMarkersRef = useRef<google.maps.Marker[]>([]);

  // Cache working data and keys to prevent polygon destruction during drag gestures
  const workingSegmentsRef = useRef<RoofSegment[]>(property?.segments || []);
  const workingEdgesRef = useRef<StructuralLine[]>(property?.customEdges || []);
  const debounceTimerRef = useRef<NodeJS.Timeout | null>(null);
  const lastPolyKeyRef = useRef<string>('');
  const lastLineKeyRef = useRef<string>('');

  // Keep working references in sync with latest property updates
  useEffect(() => {
    if (property) {
      workingSegmentsRef.current = property.segments || [];
      workingEdgesRef.current = property.customEdges || [];
      setIsUsaOverview(false);
    }
  }, [property?.id, property?.updatedAt]);

  const center = useMemo(() => {
    if (isUsaOverview) {
      return USA_CENTER;
    }
    if (property?.coordinates) {
      return {
        lat: property.coordinates.latitude,
        lng: property.coordinates.longitude,
      };
    }
    return USA_CENTER;
  }, [property, isUsaOverview]);

  // Adjust camera when switching between USA overview and focused rooftop
  useEffect(() => {
    if (!map) return;

    if (isUsaOverview) {
      map.setCenter(USA_CENTER);
      map.setZoom(USA_ZOOM);
      map.setTilt(0);
      return;
    }

    if (!property?.coordinates) return;

    if (property.bounds) {
      const bounds = new google.maps.LatLngBounds(
        { lat: property.bounds.sw.latitude, lng: property.bounds.sw.longitude },
        { lat: property.bounds.ne.latitude, lng: property.bounds.ne.longitude }
      );
      map.fitBounds(bounds, { top: 60, bottom: 60, left: 60, right: 60 });
      map.setTilt(45);
    } else {
      map.panTo({
        lat: property.coordinates.latitude,
        lng: property.coordinates.longitude,
      });
      map.setZoom(19);
      map.setTilt(45);
    }
  }, [map, property?.id, property?.coordinates?.latitude, property?.coordinates?.longitude, isUsaOverview]);

  // Temporary CAD toast message timer
  useEffect(() => {
    if (cadMessage) {
      const timer = setTimeout(() => setCadMessage(null), 5000);
      return () => clearTimeout(timer);
    }
  }, [cadMessage]);

  // Helper to update property takeoff metrics when geometry changes
  const notifyPropertyUpdated = useCallback(
    (updatedSegments: RoofSegment[], updatedEdges: StructuralLine[]) => {
      if (!property || !onPropertyUpdated) return;

      workingSegmentsRef.current = updatedSegments;
      workingEdgesRef.current = updatedEdges;

      // Calculate total roof area from segments
      const totalRoofAreaSqFt = updatedSegments.reduce((sum, s) => sum + (s.areaSqFt || 0), 0);
      const totalRoofSquares = Math.round((totalRoofAreaSqFt / 100) * 10) / 10;
      const totalRoofAreaMeters2 = Math.round((totalRoofAreaSqFt / 10.7639) * 10) / 10;
      const groundFootprintSqFt = updatedSegments.reduce((sum, s) => sum + (s.groundAreaSqFt || 0), 0);

      // Calculate total linear footages from edges
      let estimatedEavesFeet = 0;
      let estimatedRidgesFeet = 0;
      let estimatedHipsFeet = 0;
      let estimatedValleysFeet = 0;
      let estimatedRakesFeet = 0;

      updatedEdges.forEach((edge) => {
        if (edge.type === 'eave') estimatedEavesFeet += edge.lengthFeet;
        else if (edge.type === 'ridge') estimatedRidgesFeet += edge.lengthFeet;
        else if (edge.type === 'hip') estimatedHipsFeet += edge.lengthFeet;
        else if (edge.type === 'valley') estimatedValleysFeet += edge.lengthFeet;
        else if (edge.type === 'rake') estimatedRakesFeet += edge.lengthFeet;
      });

      const estimatedTotalLinearEdgeFeet =
        estimatedEavesFeet + estimatedRidgesFeet + estimatedHipsFeet + estimatedValleysFeet + estimatedRakesFeet;

      const updatedTakeoff: TakeoffSummary = {
        ...property.takeoff,
        totalRoofAreaSqFt,
        totalRoofSquares,
        totalRoofAreaMeters2,
        groundFootprintSqFt,
        totalSegments: updatedSegments.length,
        linearEdgesAvailable: true,
        estimatedEavesFeet: Math.round(estimatedEavesFeet),
        estimatedRidgesFeet: Math.round(estimatedRidgesFeet),
        estimatedHipsFeet: Math.round(estimatedHipsFeet),
        estimatedValleysFeet: Math.round(estimatedValleysFeet),
        estimatedRakesFeet: Math.round(estimatedRakesFeet),
        estimatedTotalLinearEdgeFeet: Math.round(estimatedTotalLinearEdgeFeet),
        dataProvenance: {
          ...(property.takeoff.dataProvenance || {}),
          totalRoofAreaSqFt: 'MANUAL_EDIT',
          totalRoofSquares: 'MANUAL_EDIT',
          estimatedEavesFeet: 'MANUAL_EDIT',
          estimatedRidgesFeet: 'MANUAL_EDIT',
          estimatedHipsFeet: 'MANUAL_EDIT',
          estimatedValleysFeet: 'MANUAL_EDIT',
          estimatedRakesFeet: 'MANUAL_EDIT',
          estimatedTotalLinearEdgeFeet: 'MANUAL_EDIT',
        },
      };

      const updatedProperty: PropertyRecord = {
        ...property,
        takeoff: updatedTakeoff,
        segments: updatedSegments,
        customEdges: updatedEdges,
        status: property.status === 'DEMO_SAMPLE' ? 'DEMO_SAMPLE' : 'ROOF_GEOMETRY_EXTRACTED',
        updatedAt: new Date().toISOString(),
      };

      onPropertyUpdated(updatedProperty);
    },
    [property, onPropertyUpdated]
  );

  // Central CAD drawing click handler (invoked by Map, Polygons, and Polylines seamlessly)
  const handleCadClick = useCallback(
    (clickPoint: { lat: number; lng: number }) => {
      if (!property) return;

      if (cadTool === 'draw_edge') {
        if (!drawingLineStart) {
          // Set point 1
          setDrawingLineStart(clickPoint);
          setCadMessage(`Point 1 set for ${EDGE_CONFIG[activeEdgeType].label}. Click Point 2 to place line.`);
        } else {
          // Set point 2 and create edge
          const lenFeet = calculateDistanceFeet(drawingLineStart, clickPoint);
          const newEdge: StructuralLine = {
            id: `edge-${activeEdgeType}-${Date.now()}`,
            type: activeEdgeType,
            name: `${EDGE_CONFIG[activeEdgeType].label} (${lenFeet} ft)`,
            path: [drawingLineStart, clickPoint],
            lengthFeet: lenFeet,
          };

          const currentEdges = workingEdgesRef.current || [];
          const updatedEdges = [...currentEdges, newEdge];
          notifyPropertyUpdated(workingSegmentsRef.current, updatedEdges);

          setDrawingLineStart(null);
          setCurrentMousePoint(null);
          setCadMessage(`Added ${EDGE_CONFIG[activeEdgeType].label}: ${lenFeet} ft`);
        }
      } else if (cadTool === 'draw_facet') {
        if (drawingPolygonPoints.length >= 3) {
          const firstPoint = drawingPolygonPoints[0];
          const distToFirst = calculateDistanceFeet(clickPoint, firstPoint);
          if (distToFirst < 8) {
            finishPolygonFacet();
            return;
          }
        }

        const newPoints = [...drawingPolygonPoints, clickPoint];
        setDrawingPolygonPoints(newPoints);
        setCadMessage(`Point #${newPoints.length} placed. Click more vertices or [Finish Facet].`);
      }
    },
    [property, cadTool, activeEdgeType, drawingLineStart, drawingPolygonPoints, notifyPropertyUpdated]
  );

  // Render vector roof segments as Google Maps Polygon overlays
  useEffect(() => {
    if (!map || !mapsLibrary) return;

    if (
      isUsaOverview ||
      !property ||
      !structuralVisibility.facets ||
      !property.segments ||
      property.segments.length === 0
    ) {
      polygonsRef.current.forEach((poly) => poly.setMap(null));
      polygonsRef.current = [];
      return;
    }

    const isEditMode = cadTool === 'edit_handles';
    const isDeleteMode = cadTool === 'delete';
    const isDrawingMode = cadTool === 'draw_edge' || cadTool === 'draw_facet';

    // Prevent destroying active polygons during vertex drag gestures
    const currentPolyKey = `${property.id}-${property.segments.length}-${cadTool}-${structuralVisibility.facets}-${selectedSegmentIndex}`;
    const shouldSkipRebuild =
      isEditMode &&
      lastPolyKeyRef.current.startsWith(`${property.id}-${property.segments.length}-${cadTool}-`) &&
      polygonsRef.current.length === property.segments.length;

    if (shouldSkipRebuild) {
      return;
    }

    lastPolyKeyRef.current = currentPolyKey;

    // Clear previous polygons
    polygonsRef.current.forEach((poly) => poly.setMap(null));
    polygonsRef.current = [];

    const getSegmentColors = (azimuth: number, isSelected: boolean) => {
      if (isSelected) {
        return {
          fill: '#06b6d4',
          stroke: '#ffffff',
          strokeWeight: 3.5,
          fillOpacity: 0.65,
        };
      }
      if (azimuth >= 135 && azimuth <= 225) {
        return { fill: '#f59e0b', stroke: '#fbbf24', strokeWeight: 1.5, fillOpacity: 0.45 };
      }
      if (azimuth <= 45 || azimuth >= 315) {
        return { fill: '#3b82f6', stroke: '#60a5fa', strokeWeight: 1.5, fillOpacity: 0.35 };
      }
      if (azimuth > 45 && azimuth < 135) {
        return { fill: '#10b981', stroke: '#34d399', strokeWeight: 1.5, fillOpacity: 0.4 };
      }
      return { fill: '#8b5cf6', stroke: '#a78bfa', strokeWeight: 1.5, fillOpacity: 0.4 };
    };

    const newPolygons: google.maps.Polygon[] = [];

    property.segments.forEach((seg, idx) => {
      const isSelected = selectedSegmentIndex === seg.segmentIndex;
      const colors = getSegmentColors(seg.azimuthDegrees, isSelected);

      const sw = seg.boundingBox.sw;
      const ne = seg.boundingBox.ne;

      const path =
        seg.polygonPath && seg.polygonPath.length >= 3
          ? seg.polygonPath
          : [
              { lat: sw.latitude, lng: sw.longitude },
              { lat: ne.latitude, lng: sw.longitude },
              { lat: ne.latitude, lng: ne.longitude },
              { lat: sw.latitude, lng: ne.longitude },
            ];

      const polygon = new google.maps.Polygon({
        paths: path,
        strokeColor: isDeleteMode ? '#ef4444' : colors.stroke,
        strokeOpacity: 0.9,
        strokeWeight: colors.strokeWeight,
        fillColor: isDeleteMode ? '#ef4444' : colors.fill,
        fillOpacity: isDeleteMode ? 0.3 : colors.fillOpacity,
        editable: isEditMode, // Drag corner handles when in edit mode
        draggable: false,
        clickable: !isDrawingMode, // In drawing mode, clicks pass through to map
        zIndex: isSelected ? 80 : 10,
        map: map,
      });

      // Handle polygon vertex edits (dragging corner handles)
      if (isEditMode) {
        const polyPath = polygon.getPath();
        const handlePathChanged = () => {
          const updatedCoords = polyPath.getArray().map((ll) => ({
            lat: ll.lat(),
            lng: ll.lng(),
          }));
          const groundArea = calculatePolygonAreaSqFt(updatedCoords);
          const pitchMultiplier = 1 / Math.cos(((seg.pitchDegrees || 22.6) * Math.PI) / 180);
          const pitchedArea = Math.round(groundArea * pitchMultiplier);

          const updatedSegments = [...workingSegmentsRef.current];
          updatedSegments[idx] = {
            ...seg,
            polygonPath: updatedCoords,
            groundAreaSqFt: groundArea,
            groundAreaMeters2: Math.round((groundArea / 10.7639) * 10) / 10,
            areaSqFt: pitchedArea,
            areaMeters2: Math.round((pitchedArea / 10.7639) * 10) / 10,
            source: 'MANUAL_EDIT',
          };
          workingSegmentsRef.current = updatedSegments;

          setCadMessage(`Facet #${idx + 1}: ${pitchedArea.toLocaleString()} sq ft`);

          // Debounce commit to parent by 350ms to keep polygon handle drag continuous
          if (debounceTimerRef.current) clearTimeout(debounceTimerRef.current);
          debounceTimerRef.current = setTimeout(() => {
            notifyPropertyUpdated(workingSegmentsRef.current, workingEdgesRef.current);
          }, 350);
        };

        polyPath.addListener('set_at', handlePathChanged);
        polyPath.addListener('insert_at', handlePathChanged);
        polyPath.addListener('remove_at', handlePathChanged);
      }

      // Handle polygon click (drawing, delete, or inspect)
      polygon.addListener('click', (e: google.maps.MapMouseEvent) => {
        if (isDrawingMode && e.latLng) {
          handleCadClick({ lat: e.latLng.lat(), lng: e.latLng.lng() });
          return;
        }

        if (cadTool === 'delete') {
          const updatedSegments = workingSegmentsRef.current.filter((_, sIdx) => sIdx !== idx);
          workingSegmentsRef.current = updatedSegments;
          notifyPropertyUpdated(updatedSegments, workingEdgesRef.current);
          setCadMessage(`Deleted roof facet #${idx + 1}`);
        } else if (cadTool === 'select') {
          onSelectSegment(seg.segmentIndex);
          setActiveInfoWindow(seg);
        }
      });

      newPolygons.push(polygon);
    });

    polygonsRef.current = newPolygons;

    return () => {
      if (!isEditMode) {
        newPolygons.forEach((p) => p.setMap(null));
      }
    };
  }, [
    map,
    mapsLibrary,
    property?.id,
    property?.segments?.length,
    selectedSegmentIndex,
    structuralVisibility.facets,
    isUsaOverview,
    onSelectSegment,
    cadTool,
    handleCadClick,
    notifyPropertyUpdated,
  ]);

  // Render CAD-style structural polylines (Ridges, Hips, Valleys, Eaves, Rakes, Flashing)
  useEffect(() => {
    if (!map || !mapsLibrary) return;

    if (
      isUsaOverview ||
      !property?.segments ||
      property.segments.length === 0 ||
      !property.takeoff?.linearEdgesAvailable
    ) {
      polylinesRef.current.forEach((line) => line.setMap(null));
      polylinesRef.current = [];
      return;
    }

    const isEditMode = cadTool === 'edit_handles';
    const isDeleteMode = cadTool === 'delete';
    const isDrawingMode = cadTool === 'draw_edge' || cadTool === 'draw_facet';

    const currentLineKey = `${property.id}-${property.segments.length}-${(property.customEdges || []).length}-${cadTool}-${selectedSegmentIndex}-${JSON.stringify(structuralVisibility)}`;
    const shouldSkipLineRebuild =
      isEditMode &&
      lastLineKeyRef.current.startsWith(`${property.id}-${property.segments.length}-${(property.customEdges || []).length}-${cadTool}-`) &&
      polylinesRef.current.length > 0;

    if (shouldSkipLineRebuild) {
      return;
    }

    lastLineKeyRef.current = currentLineKey;

    polylinesRef.current.forEach((line) => line.setMap(null));
    polylinesRef.current = [];

    const { ridges, hips, valleys, eaves, rakes, flashing } = extractStructuralLines(
      property.segments,
      property.customEdges
    );
    const newPolylines: google.maps.Polyline[] = [];

    const addLineGroup = (
      lines: StructuralLine[],
      isVisible: boolean,
      strokeColor: string,
      strokeWeight: number,
      zIndex: number
    ) => {
      if (!isVisible) return;

      lines.forEach((l) => {
        const isSegmentActive = selectedSegmentIndex === l.segmentIndex;
        const line = new google.maps.Polyline({
          path: l.path,
          geodesic: true,
          strokeColor: isDeleteMode ? '#ef4444' : isSegmentActive ? '#ffffff' : strokeColor,
          strokeOpacity: isSegmentActive ? 1.0 : 0.95,
          strokeWeight: isSegmentActive ? strokeWeight + 2 : strokeWeight,
          editable: isEditMode, // Drag endpoints in edit mode
          clickable: !isDrawingMode,
          zIndex: isSegmentActive ? zIndex + 50 : zIndex,
          map: map,
        });

        // Listen for endpoint dragging
        if (isEditMode) {
          const linePath = line.getPath();
          const handleLineChanged = () => {
            const coords = linePath.getArray().map((ll) => ({
              lat: ll.lat(),
              lng: ll.lng(),
            }));
            if (coords.length >= 2) {
              const newLen = calculateDistanceFeet(coords[0], coords[1]);
              const existingEdges = workingEdgesRef.current || [];
              const updatedEdges = existingEdges.map((e) =>
                e.id === l.id ? { ...e, path: coords, lengthFeet: newLen } : e
              );
              workingEdgesRef.current = updatedEdges;
              setCadMessage(`Adjusted ${l.type} line: ${newLen} ft`);

              if (debounceTimerRef.current) clearTimeout(debounceTimerRef.current);
              debounceTimerRef.current = setTimeout(() => {
                notifyPropertyUpdated(workingSegmentsRef.current, workingEdgesRef.current);
              }, 350);
            }
          };

          linePath.addListener('set_at', handleLineChanged);
          linePath.addListener('insert_at', handleLineChanged);
        }

        line.addListener('click', (e: google.maps.MapMouseEvent) => {
          if (isDrawingMode && e.latLng) {
            handleCadClick({ lat: e.latLng.lat(), lng: e.latLng.lng() });
            return;
          }

          if (cadTool === 'delete') {
            const updatedEdges = (workingEdgesRef.current || []).filter((ed) => ed.id !== l.id);
            workingEdgesRef.current = updatedEdges;
            notifyPropertyUpdated(workingSegmentsRef.current, updatedEdges);
            setCadMessage(`Deleted ${l.type} line`);
          } else if (cadTool === 'select' && l.segmentIndex !== undefined) {
            onSelectSegment(l.segmentIndex);
            const targetSeg = property.segments[l.segmentIndex];
            if (targetSeg) setActiveInfoWindow(targetSeg);
          }
        });

        newPolylines.push(line);
      });
    };

    addLineGroup(ridges, structuralVisibility.ridges, EDGE_CONFIG.ridge.hex, EDGE_CONFIG.ridge.weight, EDGE_CONFIG.ridge.zIndex);
    addLineGroup(hips, structuralVisibility.hips, EDGE_CONFIG.hip.hex, EDGE_CONFIG.hip.weight, EDGE_CONFIG.hip.zIndex);
    addLineGroup(valleys, structuralVisibility.valleys, EDGE_CONFIG.valley.hex, EDGE_CONFIG.valley.weight, EDGE_CONFIG.valley.zIndex);
    addLineGroup(eaves, structuralVisibility.eaves, EDGE_CONFIG.eave.hex, EDGE_CONFIG.eave.weight, EDGE_CONFIG.eave.zIndex);
    addLineGroup(rakes, structuralVisibility.rakes, EDGE_CONFIG.rake.hex, EDGE_CONFIG.rake.weight, EDGE_CONFIG.rake.zIndex);
    addLineGroup(flashing, true, EDGE_CONFIG.flashing.hex, EDGE_CONFIG.flashing.weight, EDGE_CONFIG.flashing.zIndex);

    polylinesRef.current = newPolylines;

    return () => {
      if (!isEditMode) {
        newPolylines.forEach((l) => l.setMap(null));
      }
    };
  }, [
    map,
    mapsLibrary,
    property?.id,
    property?.segments?.length,
    property?.customEdges?.length,
    selectedSegmentIndex,
    structuralVisibility.ridges,
    structuralVisibility.hips,
    structuralVisibility.valleys,
    structuralVisibility.eaves,
    structuralVisibility.rakes,
    isUsaOverview,
    onSelectSegment,
    cadTool,
    handleCadClick,
    notifyPropertyUpdated,
  ]);

  // Handle Map Clicks & Mouse Movements for CAD Drawing (Draw Edge & Draw Facet)
  useEffect(() => {
    if (!map) return;

    const clickListener = map.addListener('click', (e: google.maps.MapMouseEvent) => {
      if (!e.latLng) return;
      handleCadClick({ lat: e.latLng.lat(), lng: e.latLng.lng() });
    });

    const moveListener = map.addListener('mousemove', (e: google.maps.MapMouseEvent) => {
      if (!e.latLng) return;
      if (cadTool === 'draw_edge' && drawingLineStart) {
        setCurrentMousePoint({ lat: e.latLng.lat(), lng: e.latLng.lng() });
      } else if (cadTool === 'draw_facet' && drawingPolygonPoints.length > 0) {
        setCurrentMousePoint({ lat: e.latLng.lat(), lng: e.latLng.lng() });
      }
    });

    return () => {
      google.maps.event.removeListener(clickListener);
      google.maps.event.removeListener(moveListener);
    };
  }, [
    map,
    cadTool,
    drawingLineStart,
    drawingPolygonPoints,
    handleCadClick,
  ]);

  // Live Rubber-Band Guide Line Preview for Draw Edge
  useEffect(() => {
    if (!map) return;

    if (previewPolylineRef.current) {
      previewPolylineRef.current.setMap(null);
      previewPolylineRef.current = null;
    }

    if (cadTool === 'draw_edge' && drawingLineStart && currentMousePoint) {
      const line = new google.maps.Polyline({
        path: [drawingLineStart, currentMousePoint],
        strokeColor: EDGE_CONFIG[activeEdgeType].hex,
        strokeOpacity: 0.85,
        strokeWeight: EDGE_CONFIG[activeEdgeType].weight,
        map: map,
        zIndex: 200,
      });
      previewPolylineRef.current = line;
    }

    return () => {
      if (previewPolylineRef.current) {
        previewPolylineRef.current.setMap(null);
        previewPolylineRef.current = null;
      }
    };
  }, [map, cadTool, drawingLineStart, currentMousePoint, activeEdgeType]);

  // Live Preview Polygon for Draw Facet
  useEffect(() => {
    if (!map) return;

    if (previewPolygonRef.current) {
      previewPolygonRef.current.setMap(null);
      previewPolygonRef.current = null;
    }

    if (cadTool === 'draw_facet' && drawingPolygonPoints.length > 0) {
      const path = [...drawingPolygonPoints];
      if (currentMousePoint) path.push(currentMousePoint);

      const poly = new google.maps.Polygon({
        paths: path,
        strokeColor: '#38bdf8',
        strokeOpacity: 0.9,
        strokeWeight: 2,
        fillColor: '#38bdf8',
        fillOpacity: 0.35,
        map: map,
        zIndex: 180,
      });
      previewPolygonRef.current = poly;
    }

    return () => {
      if (previewPolygonRef.current) {
        previewPolygonRef.current.setMap(null);
        previewPolygonRef.current = null;
      }
    };
  }, [map, cadTool, drawingPolygonPoints, currentMousePoint]);

  // Finish polygon facet creation
  const finishPolygonFacet = () => {
    if (drawingPolygonPoints.length < 3 || !property) {
      setCadMessage('A roof plane requires at least 3 points to calculate area.');
      return;
    }

    const groundArea = calculatePolygonAreaSqFt(drawingPolygonPoints);
    const pitchMap: Record<string, number> = {
      '3.0:12': 14.0,
      '4.0:12': 18.4,
      '5.0:12': 22.6,
      '6.0:12': 26.6,
      '7.0:12': 30.3,
      '8.0:12': 33.7,
      '9.0:12': 36.9,
      '10.0:12': 39.8,
      '12.0:12': 45.0,
    };
    const pitchDeg = pitchMap[selectedPitchRatio] || 22.6;
    const pitchMultiplier = 1 / Math.cos((pitchDeg * Math.PI) / 180);
    const pitchedArea = Math.round(groundArea * pitchMultiplier);

    const lats = drawingPolygonPoints.map((p) => p.lat);
    const lngs = drawingPolygonPoints.map((p) => p.lng);

    const newSeg: RoofSegment = {
      segmentIndex: property.segments.length,
      name: `Custom Facet #${property.segments.length + 1}`,
      pitchDegrees: pitchDeg,
      pitchRatio: selectedPitchRatio,
      azimuthDegrees: 180,
      azimuthDirection: 'S',
      areaSqFt: pitchedArea,
      areaMeters2: Math.round((pitchedArea / 10.7639) * 10) / 10,
      groundAreaSqFt: groundArea,
      groundAreaMeters2: Math.round((groundArea / 10.7639) * 10) / 10,
      planeHeightMeters: 4.8,
      planeHeightFeet: 15.7,
      center: {
        latitude: lats.reduce((a, b) => a + b, 0) / lats.length,
        longitude: lngs.reduce((a, b) => a + b, 0) / lngs.length,
      },
      boundingBox: {
        sw: { latitude: Math.min(...lats), longitude: Math.min(...lngs) },
        ne: { latitude: Math.max(...lats), longitude: Math.max(...lngs) },
      },
      polygonPath: drawingPolygonPoints,
      estimatedLengthFeet: 40,
      estimatedWidthFeet: 25,
      source: 'MANUAL_EDIT',
      hasExistingPanels: false,
      existingPanelCount: 0,
    };

    const updatedSegments = [...workingSegmentsRef.current, newSeg];
    notifyPropertyUpdated(updatedSegments, workingEdgesRef.current || []);

    setDrawingPolygonPoints([]);
    setCurrentMousePoint(null);
    setCadMessage(`Created custom roof plane: ${pitchedArea.toLocaleString()} sq ft (${selectedPitchRatio} pitch)`);
  };

  // Instant 1-Click Auto-Capture from Parcel Footprint
  const handleAutoCapture = () => {
    if (!property?.coordinates) return;
    const autoRoof = generateAutoCapturedRoof(
      property.coordinates.latitude,
      property.coordinates.longitude
    );

    notifyPropertyUpdated(autoRoof.segments, autoRoof.customEdges);
    setCadMessage(
      `Auto-captured 4 roof planes and 9 structural edges (${autoRoof.takeoff.totalRoofSquares} squares) from satellite parcel footprint.`
    );
  };

  // 1-Click Save Takeoff Directly to CRM Pipeline Backend
  const handleSaveTakeoffToCrm = async () => {
    if (!property) return;
    setIsSavingTakeoff(true);
    setSaveSuccess(false);

    try {
      const res = await fetch(`/api/pipeline/properties/${property.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          takeoff: property.takeoff,
          segments: property.segments,
          customEdges: property.customEdges,
          status: 'TAKEOFF_VERIFIED',
          notes: 'Takeoff verified and CAD geometry saved to CRM pipeline.',
        }),
      });

      if (res.ok) {
        const data = await res.json();
        if (onPropertyUpdated && data.property) {
          onPropertyUpdated(data.property);
        }
        setSaveSuccess(true);
        setCadMessage('Takeoff verified and saved successfully to ForgeOne CRM pipeline!');
        setTimeout(() => setSaveSuccess(false), 4000);
      } else {
        setCadMessage('Error saving takeoff to server.');
      }
    } catch (err) {
      setCadMessage('Network error saving takeoff.');
    } finally {
      setIsSavingTakeoff(false);
    }
  };

  // Short city/state for nationwide display markers
  const getCityState = (address: string) => {
    const parts = address.split(',');
    if (parts.length >= 3) {
      const city = parts[parts.length - 3].trim();
      const stateZip = parts[parts.length - 2].trim();
      const state = stateZip.split(' ')[0];
      return `${city}, ${state}`;
    }
    return address;
  };

  return (
    <div className="relative w-full h-full flex flex-col min-h-0 bg-slate-950 overflow-hidden">
      {/* Map Floating Toolbar Controls */}
      <div className="absolute top-4 left-4 z-20 flex flex-wrap items-center gap-1.5 bg-slate-900/95 backdrop-blur-md border border-slate-700/80 rounded-lg p-1.5 shadow-lg max-w-[calc(100%-2rem)]">
        {/* National / Rooftop View Switcher */}
        <div className="flex items-center gap-1 bg-slate-950/70 p-0.5 rounded-md border border-slate-800">
          <button
            type="button"
            onClick={() => setIsUsaOverview(true)}
            className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded transition-colors whitespace-nowrap cursor-pointer ${
              isUsaOverview
                ? 'bg-cyan-600 text-white shadow-xs'
                : 'text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
            title="Zoom out to Continental USA to view all nationwide property records"
          >
            <Globe2 className="w-3.5 h-3.5" />
            <span>USA Overview</span>
          </button>

          <button
            type="button"
            onClick={() => setIsUsaOverview(false)}
            disabled={!property}
            className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded transition-colors whitespace-nowrap cursor-pointer ${
              !isUsaOverview
                ? 'bg-cyan-600 text-white shadow-xs'
                : 'text-slate-300 hover:text-white hover:bg-slate-800'
            } ${!property ? 'opacity-50 cursor-not-allowed' : ''}`}
            title="Focus in on rooftop vector geometry"
          >
            <Home className="w-3.5 h-3.5" />
            <span>Rooftop View</span>
          </button>
        </div>

        <div className="w-[1px] h-4 bg-slate-700 mx-1 hidden sm:block"></div>

        {/* Map Type Switcher */}
        <div className="flex items-center gap-1">
          <button
            onClick={() => setMapTypeId('hybrid')}
            className={`px-2 py-1 text-xs font-semibold rounded-md transition-colors whitespace-nowrap cursor-pointer ${
              mapTypeId === 'hybrid'
                ? 'bg-slate-750 text-cyan-300 border border-cyan-800/60 shadow-xs'
                : 'text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
          >
            Hybrid
          </button>
          <button
            onClick={() => setMapTypeId('satellite')}
            className={`px-2 py-1 text-xs font-semibold rounded-md transition-colors whitespace-nowrap cursor-pointer ${
              mapTypeId === 'satellite'
                ? 'bg-slate-750 text-cyan-300 border border-cyan-800/60 shadow-xs'
                : 'text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
          >
            Satellite
          </button>
          <button
            onClick={() => setMapTypeId('roadmap')}
            className={`px-2 py-1 text-xs font-semibold rounded-md transition-colors whitespace-nowrap cursor-pointer ${
              mapTypeId === 'roadmap'
                ? 'bg-slate-750 text-cyan-300 border border-cyan-800/60 shadow-xs'
                : 'text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
          >
            Vector
          </button>
        </div>

        {!isUsaOverview && (
          <>
            <div className="w-[1px] h-4 bg-slate-700 mx-1 hidden sm:block"></div>

            {/* Structural Visibility Toggles */}
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => onToggleStructuralVisibility('facets')}
                className={`flex items-center gap-1 px-1.5 py-1 text-[11px] font-mono rounded transition-colors whitespace-nowrap cursor-pointer ${
                  structuralVisibility.facets
                    ? 'bg-cyan-950/80 text-cyan-300 border border-cyan-700/60'
                    : 'text-slate-400 hover:text-slate-200 bg-slate-800/40'
                }`}
                title="Toggle Roof Plane Polygons"
              >
                <Layers className="w-3 h-3" />
                <span>Planes</span>
              </button>

              <button
                type="button"
                onClick={() => onToggleStructuralVisibility('ridges')}
                className={`flex items-center gap-1 px-1.5 py-1 text-[11px] font-mono rounded transition-colors whitespace-nowrap cursor-pointer ${
                  structuralVisibility.ridges
                    ? 'bg-red-950/80 text-red-300 border border-red-700/60'
                    : 'text-slate-400 hover:text-slate-200 bg-slate-800/40'
                }`}
                title="Toggle Ridges"
              >
                <span className="w-2 h-0.5 bg-red-400 rounded-full"></span>
                <span>Ridges</span>
              </button>

              <button
                type="button"
                onClick={() => onToggleStructuralVisibility('eaves')}
                className={`flex items-center gap-1 px-1.5 py-1 text-[11px] font-mono rounded transition-colors whitespace-nowrap cursor-pointer ${
                  structuralVisibility.eaves
                    ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-700/60'
                    : 'text-slate-400 hover:text-slate-200 bg-slate-800/40'
                }`}
                title="Toggle Eaves"
              >
                <span className="w-2 h-0.5 bg-emerald-400 rounded-full"></span>
                <span>Eaves</span>
              </button>

              <button
                type="button"
                onClick={() => onToggleStructuralVisibility('hips')}
                className={`flex items-center gap-1 px-1.5 py-1 text-[11px] font-mono rounded transition-colors whitespace-nowrap cursor-pointer ${
                  structuralVisibility.hips
                    ? 'bg-orange-950/80 text-orange-300 border border-orange-700/60'
                    : 'text-slate-400 hover:text-slate-200 bg-slate-800/40'
                }`}
                title="Toggle Hips"
              >
                <span className="w-2 h-0.5 bg-orange-400 rounded-full"></span>
                <span>Hips</span>
              </button>
            </div>
          </>
        )}
      </div>

      {/* DEDICATED ROOFTOP CAD TOOLBAR (Contractor Drawing & Editing Mode) */}
      {!isUsaOverview && property && (
        <div className="absolute top-16 left-4 z-20 flex flex-wrap items-center gap-1 bg-slate-900/95 backdrop-blur-md border border-cyan-800/80 rounded-lg p-1.5 shadow-xl max-w-[calc(100%-2rem)]">
          <div className="flex items-center gap-1 text-xs font-mono font-bold text-cyan-400 px-2 py-0.5 border-r border-slate-700 mr-0.5">
            <Activity className="w-3.5 h-3.5" />
            <span>CAD TOOLS</span>
          </div>

          {/* Mode 1: Select / Inspect */}
          <button
            type="button"
            onClick={() => {
              setCadTool('select');
              setDrawingLineStart(null);
              setDrawingPolygonPoints([]);
            }}
            className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded transition-colors cursor-pointer ${
              cadTool === 'select'
                ? 'bg-cyan-600 text-white font-bold shadow-xs'
                : 'text-slate-300 hover:bg-slate-800 hover:text-white'
            }`}
            title="Inspect planes and view slope azimuth measurements"
          >
            <MousePointer className="w-3.5 h-3.5" />
            <span>Inspect</span>
          </button>

          {/* Mode 2: Edit Handles (Drag Corners) */}
          <button
            type="button"
            onClick={() => {
              setCadTool('edit_handles');
              setDrawingLineStart(null);
              setDrawingPolygonPoints([]);
              setCadMessage('Edit Mode: Click and drag any white vertex handle on the roof to adjust facet boundaries or edge lengths.');
            }}
            className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded transition-colors cursor-pointer ${
              cadTool === 'edit_handles'
                ? 'bg-amber-600 text-white font-bold shadow-xs'
                : 'text-slate-300 hover:bg-slate-800 hover:text-white'
            }`}
            title="Drag corner vertices on satellite imagery to adjust plane dimensions"
          >
            <Move className="w-3.5 h-3.5" />
            <span>Drag Vertices</span>
          </button>

          {/* Mode 3: Draw Edge (Lines) */}
          <button
            type="button"
            onClick={() => {
              setCadTool('draw_edge');
              setDrawingLineStart(null);
              setDrawingPolygonPoints([]);
              setCadMessage(`Draw Edge Mode: Click start point on map, then click end point to place a ${activeEdgeType}.`);
            }}
            className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded transition-colors cursor-pointer ${
              cadTool === 'draw_edge'
                ? 'bg-indigo-600 text-white font-bold shadow-xs'
                : 'text-slate-300 hover:bg-slate-800 hover:text-white'
            }`}
            title="Draw roof lines (Ridges, Eaves, Hips, Valleys, Rakes)"
          >
            <PenTool className="w-3.5 h-3.5" />
            <span>Draw Edge</span>
          </button>

          {/* Mode 4: Draw Facet (Polygons) */}
          <button
            type="button"
            onClick={() => {
              setCadTool('draw_facet');
              setDrawingLineStart(null);
              setDrawingPolygonPoints([]);
              setCadMessage('Draw Facet Mode: Click corners around roof plane perimeter, then click [Finish Facet].');
            }}
            className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded transition-colors cursor-pointer ${
              cadTool === 'draw_facet'
                ? 'bg-teal-600 text-white font-bold shadow-xs'
                : 'text-slate-300 hover:bg-slate-800 hover:text-white'
            }`}
            title="Draw a custom roof plane polygon and calculate surface area"
          >
            <Shapes className="w-3.5 h-3.5" />
            <span>Draw Facet</span>
          </button>

          {/* Mode 5: Delete Item */}
          <button
            type="button"
            onClick={() => {
              setCadTool('delete');
              setDrawingLineStart(null);
              setDrawingPolygonPoints([]);
              setCadMessage('Delete Mode: Click any roof plane polygon or edge line to remove it.');
            }}
            className={`flex items-center gap-1.5 px-2 py-1 text-xs font-medium rounded transition-colors cursor-pointer ${
              cadTool === 'delete'
                ? 'bg-rose-600 text-white font-bold shadow-xs'
                : 'text-slate-400 hover:bg-slate-800 hover:text-rose-300'
            }`}
            title="Click an edge or plane to delete"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>

          <div className="w-[1px] h-4 bg-slate-700 mx-1"></div>

          {/* 1-Click Auto-Capture Footprint Button */}
          <button
            type="button"
            onClick={handleAutoCapture}
            className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded bg-cyan-950/80 text-cyan-300 border border-cyan-600/80 hover:bg-cyan-900 transition-colors shadow-xs cursor-pointer"
            title="Automatically detect footprint and seed roof planes from high-res parcel bounds"
          >
            <Wand2 className="w-3.5 h-3.5 text-cyan-400" />
            <span>Auto-Capture Roof</span>
          </button>

          {/* 1-Click Save Takeoff to CRM */}
          <button
            type="button"
            onClick={handleSaveTakeoffToCrm}
            disabled={isSavingTakeoff}
            className={`flex items-center gap-1.5 px-3 py-1 text-xs font-bold rounded shadow-md transition-colors cursor-pointer ${
              saveSuccess
                ? 'bg-emerald-600 text-white'
                : 'bg-emerald-600 hover:bg-emerald-500 text-white'
            }`}
            title="Save all edited roof planes, edges, and squares to ForgeOne CRM Pipeline"
          >
            {isSavingTakeoff ? (
              <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
            ) : saveSuccess ? (
              <Check className="w-3.5 h-3.5" />
            ) : (
              <Save className="w-3.5 h-3.5" />
            )}
            <span>{saveSuccess ? 'Saved to CRM' : 'Save Takeoff'}</span>
          </button>
        </div>
      )}

      {/* Sub-ribbon for Edge Type Selector when in 'draw_edge' mode */}
      {!isUsaOverview && cadTool === 'draw_edge' && (
        <div className="absolute top-28 left-4 z-20 flex flex-wrap items-center gap-1 bg-slate-900/95 backdrop-blur-md border border-indigo-700/80 rounded-lg p-1.5 shadow-xl text-xs">
          <span className="text-[11px] font-mono text-slate-400 font-semibold px-1.5">Edge Type:</span>
          {(['ridge', 'eave', 'hip', 'valley', 'rake', 'flashing'] as EdgeType[]).map((type) => (
            <button
              key={type}
              type="button"
              onClick={() => setActiveEdgeType(type)}
              className={`flex items-center gap-1.5 px-2 py-0.5 rounded text-[11px] font-semibold transition-all cursor-pointer ${
                activeEdgeType === type
                  ? 'bg-slate-800 border shadow-xs'
                  : 'text-slate-400 hover:text-white bg-slate-950/40 border border-transparent'
              }`}
              style={{
                borderColor: activeEdgeType === type ? EDGE_CONFIG[type].hex : 'transparent',
                color: activeEdgeType === type ? EDGE_CONFIG[type].hex : undefined,
              }}
            >
              <span
                className="w-2.5 h-1 rounded-full shrink-0"
                style={{ backgroundColor: EDGE_CONFIG[type].hex }}
              ></span>
              <span className="capitalize">{type}</span>
            </button>
          ))}

          {drawingLineStart && (
            <button
              type="button"
              onClick={() => {
                setDrawingLineStart(null);
                setCurrentMousePoint(null);
              }}
              className="ml-2 flex items-center gap-1 px-1.5 py-0.5 text-[10px] text-rose-300 bg-rose-950/80 border border-rose-700 rounded hover:bg-rose-900"
            >
              <X className="w-3 h-3" />
              <span>Cancel Line</span>
            </button>
          )}
        </div>
      )}

      {/* Live Measurement Badge for Draw Edge */}
      {!isUsaOverview && cadTool === 'draw_edge' && drawingLineStart && currentMousePoint && (
        <div className="absolute top-40 left-4 z-30 bg-slate-900/95 backdrop-blur-md border border-indigo-500/90 text-white rounded-lg px-3 py-1.5 shadow-xl text-xs flex items-center gap-2 font-mono animate-in fade-in duration-150">
          <span
            className="w-2.5 h-2.5 rounded-full shrink-0"
            style={{ backgroundColor: EDGE_CONFIG[activeEdgeType].hex }}
          ></span>
          <span className="font-bold text-cyan-300">
            {EDGE_CONFIG[activeEdgeType].label}: {calculateDistanceFeet(drawingLineStart, currentMousePoint)} ft
          </span>
          <span className="text-[11px] text-slate-400 font-sans">
            &middot; Click Point 2 on satellite image to finish
          </span>
        </div>
      )}

      {/* Sub-ribbon for Facet Pitch & Actions when in 'draw_facet' mode */}
      {!isUsaOverview && cadTool === 'draw_facet' && (
        <div className="absolute top-28 left-4 z-20 flex flex-wrap items-center gap-2 bg-slate-900/95 backdrop-blur-md border border-teal-700/80 rounded-lg p-1.5 shadow-xl text-xs">
          <span className="text-[11px] font-mono text-teal-300 font-semibold px-1.5">
            Points Placed: {drawingPolygonPoints.length}
          </span>

          <div className="flex items-center gap-1 text-[11px]">
            <span className="text-slate-400">Slope:</span>
            <select
              value={selectedPitchRatio}
              onChange={(e) => setSelectedPitchRatio(e.target.value)}
              className="bg-slate-950 border border-slate-700 text-slate-200 rounded px-1.5 py-0.5 font-mono text-xs focus:outline-hidden"
            >
              <option value="3.0:12">3:12 (14°)</option>
              <option value="4.0:12">4:12 (18°)</option>
              <option value="5.0:12">5:12 (23°)</option>
              <option value="6.0:12">6:12 (27°)</option>
              <option value="7.0:12">7:12 (30°)</option>
              <option value="8.0:12">8:12 (34°)</option>
              <option value="10.0:12">10:12 (40°)</option>
              <option value="12.0:12">12:12 (45°)</option>
            </select>
          </div>

          <button
            type="button"
            onClick={finishPolygonFacet}
            disabled={drawingPolygonPoints.length < 3}
            className={`flex items-center gap-1 px-2.5 py-0.5 rounded text-xs font-bold transition-all cursor-pointer ${
              drawingPolygonPoints.length >= 3
                ? 'bg-teal-600 hover:bg-teal-500 text-white shadow-xs'
                : 'bg-slate-800 text-slate-500 cursor-not-allowed'
            }`}
          >
            <Check className="w-3.5 h-3.5" />
            <span>Finish Facet</span>
          </button>

          {drawingPolygonPoints.length > 0 && (
            <button
              type="button"
              onClick={() => {
                setDrawingPolygonPoints([]);
                setCurrentMousePoint(null);
              }}
              className="flex items-center gap-1 px-1.5 py-0.5 text-[10px] text-rose-300 bg-rose-950/80 border border-rose-700 rounded hover:bg-rose-900"
            >
              <X className="w-3 h-3" />
              <span>Cancel</span>
            </button>
          )}
        </div>
      )}

      {/* Floating CAD Action Toast / Status Banner */}
      {cadMessage && (
        <div className="absolute top-40 left-4 z-30 bg-slate-900/95 backdrop-blur-md border border-cyan-500/80 text-cyan-200 rounded-lg px-3 py-1.5 shadow-xl text-xs flex items-center gap-2 max-w-md animate-in fade-in duration-200">
          <Activity className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
          <span>{cadMessage}</span>
          <button
            onClick={() => setCadMessage(null)}
            className="text-slate-400 hover:text-white ml-auto"
          >
            <X className="w-3 h-3" />
          </button>
        </div>
      )}

      {/* USA Overview Callout Banner */}
      {isUsaOverview && (
        <div className="absolute top-16 left-4 z-20 bg-slate-900/90 backdrop-blur-md border border-cyan-800/80 rounded-lg p-2.5 shadow-lg max-w-sm text-xs text-slate-300 space-y-1">
          <div className="flex items-center gap-2 text-cyan-300 font-bold">
            <Globe2 className="w-4 h-4 text-cyan-400" />
            <span>Nationwide US Pipeline ({allProperties.length} Properties)</span>
          </div>
          <p className="text-[11px] text-slate-400">
            Click any regional marker across the United States to zoom into rooftop resolution and inspect roof plane geometry.
          </p>
        </div>
      )}

      {/* Live Takeoff Metrics HUD (Pinned to bottom-right of map) */}
      {!isUsaOverview && property && (
        <div className="absolute bottom-6 right-4 z-20 bg-slate-900/90 backdrop-blur-md border border-slate-700/80 rounded-lg p-2.5 shadow-xl text-xs text-slate-200 flex items-center gap-4 font-mono">
          <div>
            <span className="text-[10px] text-slate-400 block uppercase">Squares</span>
            <span className="text-base font-bold text-cyan-300">
              {property.takeoff.totalRoofSquares} SQ
            </span>
          </div>
          <div className="w-[1px] h-6 bg-slate-800"></div>
          <div>
            <span className="text-[10px] text-slate-400 block uppercase">Pitched Area</span>
            <span className="font-semibold text-slate-200">
              {property.takeoff.totalRoofAreaSqFt?.toLocaleString()} sq ft
            </span>
          </div>
          <div className="w-[1px] h-6 bg-slate-800"></div>
          <div>
            <span className="text-[10px] text-slate-400 block uppercase">Planes</span>
            <span className="font-semibold text-slate-200">
              {property.segments?.length || 0} Facets
            </span>
          </div>
          <div className="w-[1px] h-6 bg-slate-800"></div>
          <div>
            <span className="text-[10px] text-slate-400 block uppercase">Total Edges</span>
            <span className="font-semibold text-amber-300">
              {property.takeoff.estimatedTotalLinearEdgeFeet || 0} ft
            </span>
          </div>
        </div>
      )}

      {/* Map Legend Overlay & Structural Elements Guide */}
      {!isUsaOverview && (
        <div className="absolute bottom-6 left-4 z-20 bg-slate-900/90 backdrop-blur-md border border-slate-700/80 rounded-lg p-2.5 shadow-lg text-[11px] text-slate-300 space-y-2 max-w-sm">
          <div className="font-semibold text-slate-100 flex items-center justify-between border-b border-slate-800 pb-1.5">
            <div className="flex items-center gap-1.5">
              <Activity className="w-3.5 h-3.5 text-cyan-400" />
              <span>Roof Structure Overlay</span>
            </div>
            <span className="text-[10px] text-slate-500 font-mono">CAD Vector</span>
          </div>

          <div className="grid grid-cols-2 gap-x-3 gap-y-1.5 text-[10px] font-mono">
            <div
              onClick={() => onToggleStructuralVisibility('ridges')}
              className={`flex items-center gap-1.5 cursor-pointer hover:text-white transition-opacity ${
                structuralVisibility.ridges ? 'opacity-100' : 'opacity-40'
              }`}
            >
              <span className="w-3 h-1 rounded-full bg-red-500 shrink-0"></span>
              <span>Ridges ({property?.takeoff?.estimatedRidgesFeet || 0} ft)</span>
            </div>

            <div
              onClick={() => onToggleStructuralVisibility('hips')}
              className={`flex items-center gap-1.5 cursor-pointer hover:text-white transition-opacity ${
                structuralVisibility.hips ? 'opacity-100' : 'opacity-40'
              }`}
            >
              <span className="w-3 h-1 rounded-full bg-orange-500 shrink-0"></span>
              <span>Hips ({property?.takeoff?.estimatedHipsFeet || 0} ft)</span>
            </div>

            <div
              onClick={() => onToggleStructuralVisibility('valleys')}
              className={`flex items-center gap-1.5 cursor-pointer hover:text-white transition-opacity ${
                structuralVisibility.valleys ? 'opacity-100' : 'opacity-40'
              }`}
            >
              <span className="w-3 h-1 rounded-full bg-cyan-400 shrink-0"></span>
              <span>Valleys ({property?.takeoff?.estimatedValleysFeet || 0} ft)</span>
            </div>

            <div
              onClick={() => onToggleStructuralVisibility('eaves')}
              className={`flex items-center gap-1.5 cursor-pointer hover:text-white transition-opacity ${
                structuralVisibility.eaves ? 'opacity-100' : 'opacity-40'
              }`}
            >
              <span className="w-3 h-1 rounded-full bg-emerald-500 shrink-0"></span>
              <span>Eaves ({property?.takeoff?.estimatedEavesFeet || 0} ft)</span>
            </div>

            <div
              onClick={() => onToggleStructuralVisibility('rakes')}
              className={`flex items-center gap-1.5 cursor-pointer hover:text-white transition-opacity ${
                structuralVisibility.rakes ? 'opacity-100' : 'opacity-40'
              }`}
            >
              <span className="w-3 h-1 rounded-full bg-purple-500 shrink-0"></span>
              <span>Rakes ({property?.takeoff?.estimatedRakesFeet || 0} ft)</span>
            </div>

            <div
              onClick={() => onToggleStructuralVisibility('facets')}
              className={`flex items-center gap-1.5 cursor-pointer hover:text-white transition-opacity ${
                structuralVisibility.facets ? 'opacity-100' : 'opacity-40'
              }`}
            >
              <span className="w-3 h-3 rounded-xs bg-amber-500/60 border border-amber-400 shrink-0"></span>
              <span>Planes / Solar Aspect</span>
            </div>
          </div>
        </div>
      )}

      {/* Primary Google Vector Map Container */}
      <div
        className="w-full h-full relative"
        style={{
          height: '100%',
          width: '100%',
          cursor: cadTool === 'draw_edge' || cadTool === 'draw_facet' ? 'crosshair' : undefined,
        }}
      >
        <Map
          defaultCenter={USA_CENTER}
          defaultZoom={USA_ZOOM}
          mapId="DEMO_MAP_ID"
          mapTypeId={mapTypeId}
          tilt={isUsaOverview ? 0 : 45}
          heading={0}
          gestureHandling="greedy"
          disableDefaultUI={false}
          internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
          style={{ height: '100%', width: '100%' }}
        >
          {/* NATIONWIDE USA MARKERS */}
          {isUsaOverview &&
            allProperties.map((p) => {
              const isSelected = property?.id === p.id;
              return (
                <AdvancedMarker
                  key={`nationwide-marker-${p.id}`}
                  position={{
                    lat: p.coordinates.latitude,
                    lng: p.coordinates.longitude,
                  }}
                  title={`${p.standardizedAddress} - ${p.takeoff.totalRoofSquares} squares`}
                  onClick={() => {
                    if (onSelectProperty) onSelectProperty(p);
                    setIsUsaOverview(false);
                  }}
                  zIndex={isSelected ? 100 : 50}
                >
                  <div className="flex flex-col items-center group cursor-pointer">
                    <div
                      className={`px-2 py-1 rounded-md border text-xs font-mono font-semibold shadow-lg flex items-center gap-1.5 transition-all ${
                        isSelected
                          ? 'bg-cyan-500 text-slate-950 border-white scale-110 font-bold'
                          : 'bg-slate-900/95 text-slate-100 border-cyan-400/80 hover:scale-105 hover:border-cyan-300'
                      }`}
                    >
                      <MapPin className="w-3 h-3 text-cyan-400" />
                      <span>{getCityState(p.inputAddress)}</span>
                      <span className="text-[10px] opacity-80">
                        ({p.takeoff.totalRoofSquares} sq)
                      </span>
                    </div>
                  </div>
                </AdvancedMarker>
              );
            })}

          {/* ACTIVE ROOF PARCEL PIN (When not in USA Overview mode) */}
          {!isUsaOverview && property && (
            <AdvancedMarker
              position={{
                lat: property.coordinates.latitude,
                lng: property.coordinates.longitude,
              }}
              title={property.standardizedAddress}
              zIndex={5}
            >
              <div className="flex flex-col items-center pointer-events-none">
                <div className="w-4 h-4 rounded-full border-2 border-white bg-cyan-500 shadow-md flex items-center justify-center">
                  <div className="w-1.5 h-1.5 rounded-full bg-white"></div>
                </div>
              </div>
            </AdvancedMarker>
          )}

          {/* ACTIVE DRAWING LINE START POINT ANCHOR */}
          {cadTool === 'draw_edge' && drawingLineStart && (
            <AdvancedMarker position={drawingLineStart} zIndex={250}>
              <div className="flex flex-col items-center pointer-events-none">
                <div
                  className="w-5 h-5 rounded-full border-2 border-white shadow-xl flex items-center justify-center animate-pulse"
                  style={{ backgroundColor: EDGE_CONFIG[activeEdgeType].hex }}
                >
                  <div className="w-1.5 h-1.5 rounded-full bg-white"></div>
                </div>
                <div className="bg-slate-900/90 text-white border border-slate-700 text-[10px] font-mono font-bold px-1.5 py-0.5 rounded shadow-md mt-0.5 whitespace-nowrap">
                  Point 1 (Start)
                </div>
              </div>
            </AdvancedMarker>
          )}

          {/* ACTIVE DRAWING FACET VERTEX MARKERS */}
          {cadTool === 'draw_facet' &&
            drawingPolygonPoints.map((pt, pIdx) => (
              <AdvancedMarker key={`facet-pt-${pIdx}`} position={pt} zIndex={250}>
                <div className="flex flex-col items-center pointer-events-none">
                  <div className="w-4 h-4 rounded-full border border-white bg-teal-500 shadow-lg flex items-center justify-center text-[9px] font-bold text-white">
                    {pIdx + 1}
                  </div>
                </div>
              </AdvancedMarker>
            ))}

          {/* ACTIVE INFO WINDOW FOR ROOF SEGMENT INSPECTION */}
          {!isUsaOverview && activeInfoWindow && (
            <InfoWindow
              position={{
                lat: activeInfoWindow.center.latitude,
                lng: activeInfoWindow.center.longitude,
              }}
              onCloseClick={() => setActiveInfoWindow(null)}
            >
              <div className="p-2 text-slate-900 max-w-xs font-sans text-xs space-y-1.5">
                <div className="font-bold flex items-center justify-between border-b border-slate-200 pb-1">
                  <span>{activeInfoWindow.name || `Roof Facet #${activeInfoWindow.segmentIndex + 1}`}</span>
                  <span className="font-mono text-cyan-700 font-semibold">
                    {activeInfoWindow.pitchRatio}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-x-2 gap-y-1 text-[11px]">
                  <div>
                    <span className="text-slate-500">Surface Area:</span>
                    <span className="font-bold ml-1">{activeInfoWindow.areaSqFt} sq ft</span>
                  </div>
                  <div>
                    <span className="text-slate-500">Pitch Angle:</span>
                    <span className="font-bold ml-1">{activeInfoWindow.pitchDegrees.toFixed(1)}°</span>
                  </div>
                  <div>
                    <span className="text-slate-500">Azimuth:</span>
                    <span className="font-bold ml-1">
                      {activeInfoWindow.azimuthDegrees.toFixed(0)}° ({activeInfoWindow.azimuthDirection})
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500">Ground Area:</span>
                    <span className="font-bold ml-1">{activeInfoWindow.groundAreaSqFt} sq ft</span>
                  </div>
                </div>
              </div>
            </InfoWindow>
          )}
        </Map>
      </div>
    </div>
  );
};
