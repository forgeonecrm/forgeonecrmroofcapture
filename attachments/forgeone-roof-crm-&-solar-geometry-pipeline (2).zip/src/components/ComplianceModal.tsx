import React from 'react';
import { X, ShieldCheck, Database, KeyRound, ExternalLink, Scale, CheckCircle2 } from 'lucide-react';

interface ComplianceModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ComplianceModal: React.FC<ComplianceModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-xl max-w-2xl w-full shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <div>
              <h2 className="text-base font-semibold text-white">Google Maps Platform Compliance &amp; Anti-Caching</h2>
              <p className="text-xs text-slate-400 mt-0.5">3-Tier Storage Boundaries, Terms of Service, and Security Architecture</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-md transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5 overflow-y-auto text-xs leading-relaxed text-slate-300">
          {/* 3-Tier Anti-Caching */}
          <div className="p-4 bg-slate-800/60 border border-slate-700/60 rounded-lg space-y-3">
            <h3 className="text-sm font-semibold text-white flex items-center gap-2">
              <Database className="w-4 h-4 text-cyan-400" />
              3-Tier Anti-Caching Architecture
            </h3>
            
            <div className="space-y-2.5">
              <div className="p-2.5 bg-slate-900/80 rounded border border-slate-800">
                <div className="flex items-center justify-between font-semibold text-slate-200">
                  <span>Tier 1: Google Place IDs</span>
                  <span className="text-[10px] font-mono text-emerald-400">Indefinite Retention Permitted</span>
                </div>
                <p className="text-slate-400 mt-1">
                  Place IDs are stored indefinitely in tenant property records for linkage across Google Maps Platform services.
                </p>
              </div>

              <div className="p-2.5 bg-slate-900/80 rounded border border-slate-800">
                <div className="flex items-center justify-between font-semibold text-slate-200">
                  <span>Tier 2: Geocoded Coordinates (Lat / Lng)</span>
                  <span className="text-[10px] font-mono text-amber-400">Strict 30-Day TTL Maximum</span>
                </div>
                <p className="text-slate-400 mt-1">
                  Geographic coordinates are stored with an active expiration timestamp (<code className="text-amber-300">expiresAt</code>). In-memory and database records auto-evict or re-verify coordinates after 30 consecutive calendar days per Maps Service Specific Terms. Perpetual coordinate storage is strictly prohibited.
                </p>
              </div>

              <div className="p-2.5 bg-slate-900/80 rounded border border-slate-800">
                <div className="flex items-center justify-between font-semibold text-slate-200">
                  <span>Tier 3: Raster Imagery &amp; GeoTIFF Layers</span>
                  <span className="text-[10px] font-mono text-cyan-400">0-Day Ephemeral Retention</span>
                </div>
                <p className="text-slate-400 mt-1">
                  High-resolution raster map tiles, DSMs, and solar flux GeoTIFF URLs are processed ephemerally in-memory for immediate takeoff computations and never persisted to permanent hard disk storage.
                </p>
              </div>
            </div>
          </div>

          {/* Client-Side REST Prohibition & CORS Trap Defense */}
          <div className="p-4 bg-slate-800/60 border border-slate-700/60 rounded-lg space-y-2">
            <h3 className="text-sm font-semibold text-white flex items-center gap-2">
              <KeyRound className="w-4 h-4 text-cyan-400" />
              Secure Backend Proxy Isolation
            </h3>
            <p className="text-slate-400">
              Browser JavaScript is strictly barred from calling <code className="text-cyan-300">addressvalidation.googleapis.com</code> or <code className="text-cyan-300">solar.googleapis.com</code> directly due to browser CORS policies. All requests are securely routed through the Node.js / Express proxy endpoint <code className="text-cyan-300">/api/property/measure</code> using server-side credentials and solution tracking header <code className="text-cyan-300">X-Goog-Maps-Solution-ID: gmp_mcp_codeassist_v1_aistudio</code>.
            </p>
          </div>

          {/* Legal Notice & Disclaimers */}
          <div className="p-4 bg-slate-800/40 border border-slate-700/50 rounded-lg space-y-2 text-[11px] text-slate-400">
            <div className="font-semibold text-slate-300 flex items-center gap-1.5">
              <Scale className="w-3.5 h-3.5 text-slate-400" />
              <span>Terms of Service &amp; Licensing</span>
            </div>
            <p>
              Usage of Google Maps Platform products and services may incur costs against your Google Cloud project billing account.
            </p>
            <p>
              Google-sourced code snippets are provided &ldquo;as-is&rdquo; under the Apache 2.0 License (<a href="https://www.apache.org/licenses/LICENSE-2.0" target="_blank" rel="noopener noreferrer" className="text-cyan-400 underline">https://www.apache.org/licenses/LICENSE-2.0</a>). The user is responsible for review and testing to ensure security and compliance with relevant Terms of Service: <a href="https://cloud.google.com/maps-platform/terms" target="_blank" rel="noopener noreferrer" className="text-cyan-400 underline">https://cloud.google.com/maps-platform/terms</a>.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end px-6 py-3 border-t border-slate-800 bg-slate-900">
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors"
          >
            Close Audit View
          </button>
        </div>
      </div>
    </div>
  );
};
