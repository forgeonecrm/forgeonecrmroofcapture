import React, { useState, useEffect, useRef } from 'react';
import { X, Search, Building, MapPin, Sparkles, CheckCircle2, AlertCircle, Loader2, Globe2 } from 'lucide-react';
import { PropertyRecord, TenantInfo } from '../types/pipeline.js';
import { useMapsLibrary } from '@vis.gl/react-google-maps';

interface AddressIntakeModalProps {
  isOpen: boolean;
  onClose: () => void;
  tenantId: string;
  tenants: TenantInfo[];
  onPropertyMeasured: (property: PropertyRecord) => void;
}

const NATIONWIDE_SAMPLE_ADDRESSES = [
  {
    label: 'Austin Convention & Commercial (TX)',
    address: '500 E 4th St, Austin, TX 78701',
    type: 'Central / Sunbelt Standing Seam & Flat TPO',
  },
  {
    label: 'Miami Biscayne Waterfront (FL)',
    address: '100 Biscayne Blvd, Miami, FL 33132',
    type: 'Southeast / High Wind Tile & Commercial',
  },
  {
    label: 'Chicago Loop Commercial (IL)',
    address: '233 S Wacker Dr, Chicago, IL 60606',
    type: 'Midwest / Cold Climate Parapet TPO',
  },
  {
    label: 'Seattle Center Pavilion (WA)',
    address: '400 Broad St, Seattle, WA 98109',
    type: 'Pacific Northwest / Steep Slope Gable',
  },
  {
    label: 'Denver Union Station (CO)',
    address: '1701 Wynkoop St, Denver, CO 80202',
    type: 'Mountain West / High-Snow Metal & Shingle',
  },
  {
    label: 'Manhattan Commercial (NY)',
    address: '350 5th Ave, New York, NY 10118',
    type: 'Northeast / Multi-tier Commercial Membrane',
  },
  {
    label: 'Silicon Valley Residential (CA)',
    address: '1500 Hamilton Ave, San Jose, CA 95125',
    type: 'West Coast / Hip & Valley Residential Solar',
  },
  {
    label: 'Cupertino Tech Campus (CA)',
    address: '1 Apple Park Way, Cupertino, CA 95014',
    type: 'West Coast / Commercial Solar Canopy Ring',
  },
];

export const AddressIntakeModal: React.FC<AddressIntakeModalProps> = ({
  isOpen,
  onClose,
  tenantId,
  tenants,
  onPropertyMeasured,
}) => {
  const [addressInput, setAddressInput] = useState('');
  const [selectedTenantId, setSelectedTenantId] = useState(tenantId);
  const [notes, setNotes] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [currentStep, setCurrentStep] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const inputRef = useRef<HTMLInputElement>(null);
  const placesLibrary = useMapsLibrary('places');

  useEffect(() => {
    setSelectedTenantId(tenantId);
  }, [tenantId]);

  // Initialize Google Places Autocomplete on the address input when places library is ready
  useEffect(() => {
    if (!placesLibrary || !inputRef.current) return;

    try {
      const autocomplete = new google.maps.places.Autocomplete(inputRef.current, {
        componentRestrictions: { country: 'us' },
        fields: ['formatted_address', 'geometry', 'name'],
      });

      autocomplete.addListener('place_changed', () => {
        const place = autocomplete.getPlace();
        if (place?.formatted_address) {
          setAddressInput(place.formatted_address);
        } else if (place?.name) {
          setAddressInput(place.name);
        }
      });
    } catch (err) {
      console.warn('Places Autocomplete initialization note:', err);
    }
  }, [placesLibrary, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const targetAddress = addressInput.trim() || inputRef.current?.value?.trim() || '';
    if (!targetAddress) {
      setErrorMessage('Please enter any US street address or select a verified test parcel.');
      return;
    }

    setIsLoading(true);
    setErrorMessage(null);

    try {
      setCurrentStep('Standardizing address with USPS CASS & resolving parcel coordinates...');
      
      const response = await fetch('/api/property/measure', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          address: targetAddress,
          tenantId: selectedTenantId,
          notes: notes.trim() || undefined,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `Measurement failed with HTTP status ${response.status}`);
      }

      setCurrentStep('Extracting roof geometry segments & computing takeoff metrics...');
      const result = await response.json();
      
      if (result.property) {
        onPropertyMeasured(result.property);
        onClose();
      } else {
        throw new Error('No property record returned from measurement pipeline.');
      }
    } catch (err: any) {
      console.error('Intake pipeline error:', err);
      setErrorMessage(err.message || 'Failed to process address through pipeline.');
    } finally {
      setIsLoading(false);
      setCurrentStep(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-xl max-w-xl w-full shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 shrink-0">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-semibold text-white">Intake Property &amp; Extract Roof Geometry</h2>
              <span className="px-2 py-0.5 text-[10px] font-mono font-bold bg-cyan-950 text-cyan-300 border border-cyan-800/80 rounded">
                All 50 US States
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              USPS CASS standardization, geodetic parcel coordinates, and Google Solar API 3D roof takeoff.
            </p>
          </div>
          <button
            onClick={onClose}
            disabled={isLoading}
            className="text-slate-400 hover:text-white p-1 rounded-md transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto flex-1">
          {/* Nationwide Coverage Notice */}
          <div className="p-3 bg-cyan-950/30 border border-cyan-800/50 rounded-lg flex items-start gap-2.5 text-xs text-slate-300">
            <Globe2 className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-cyan-200 block">Nationwide USA Coverage Active</span>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Enter any valid street address in any US city or state (Texas, Florida, New York, Illinois, Washington, California, etc.).
              </p>
            </div>
          </div>

          {/* Tenant Selector */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              Assign to Regional CRM Branch / Tenant
            </label>
            <div className="flex items-center bg-slate-800/80 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-200">
              <Building className="w-4 h-4 text-cyan-400 mr-2 shrink-0" />
              <select
                value={selectedTenantId}
                onChange={(e) => setSelectedTenantId(e.target.value)}
                disabled={isLoading}
                className="w-full bg-transparent text-slate-200 outline-none cursor-pointer text-xs"
              >
                {tenants.map((t) => (
                  <option key={t.id} value={t.id} className="bg-slate-900 text-slate-200">
                    {t.name} ({t.region})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Places UI Kit Autocomplete & Manual Address Input */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-medium text-slate-300">
                Street Address Anywhere in the USA
              </label>
              <span className="text-xs font-mono text-cyan-400">
                USPS CASS &middot; Solar API
              </span>
            </div>

            <div className="relative">
              <input
                ref={inputRef}
                type="text"
                value={addressInput}
                onChange={(e) => setAddressInput(e.target.value)}
                placeholder="e.g. 500 E 4th St, Austin, TX or 100 Biscayne Blvd, Miami, FL..."
                disabled={isLoading}
                className="w-full bg-slate-800/90 border border-slate-700 rounded-lg pl-9 pr-4 py-2.5 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 font-sans"
              />
              <MapPin className="w-4 h-4 text-slate-400 absolute left-3 top-3 pointer-events-none" />
            </div>

            {placesLibrary && (
              <div className="mt-2 text-[11px] text-slate-500 flex items-center gap-1.5">
                <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                <span>Places Autocomplete active across the United States</span>
              </div>
            )}
          </div>

          {/* Quick 1-Click Verification Test Addresses across the USA */}
          <div>
            <span className="text-xs font-medium text-slate-400 block mb-2">
              Or pick an instant verified nationwide sample:
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {NATIONWIDE_SAMPLE_ADDRESSES.map((sample) => (
                <button
                  key={sample.address}
                  type="button"
                  onClick={() => setAddressInput(sample.address)}
                  disabled={isLoading}
                  className="text-left px-3 py-2 bg-slate-800/50 hover:bg-slate-800 border border-slate-700/60 rounded-lg transition-colors group cursor-pointer"
                >
                  <div className="text-xs font-semibold text-slate-200 group-hover:text-cyan-400 transition-colors">
                    {sample.label}
                  </div>
                  <div className="text-[11px] text-slate-400 truncate mt-0.5">
                    {sample.address}
                  </div>
                  <div className="text-[10px] text-slate-500 mt-0.5 font-mono">
                    {sample.type}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Notes Input */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              Project / Intake Notes (Optional)
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Commercial 400kW solar assessment & R-value insulation"
              disabled={isLoading}
              className="w-full bg-slate-800/90 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Error Message */}
          {errorMessage && (
            <div className="p-3 bg-rose-950/40 border border-rose-800/60 rounded-lg flex items-start gap-2.5 text-xs text-rose-300">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Pipeline Progress Step */}
          {isLoading && (
            <div className="p-3 bg-slate-800/80 border border-cyan-800/40 rounded-lg flex items-center gap-3 text-xs text-cyan-300">
              <Loader2 className="w-4 h-4 text-cyan-400 animate-spin shrink-0" />
              <span>{currentStep || 'Processing pipeline intake...'}</span>
            </div>
          )}

          {/* Modal Footer */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              disabled={isLoading}
              className="px-4 py-2 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isLoading}
              className="flex items-center gap-2 px-5 py-2 text-xs font-semibold text-white bg-cyan-600 hover:bg-cyan-500 disabled:bg-cyan-800 disabled:opacity-60 rounded-lg shadow-sm transition-colors cursor-pointer"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>Resolving Geometry...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Execute Roof Takeoff</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
