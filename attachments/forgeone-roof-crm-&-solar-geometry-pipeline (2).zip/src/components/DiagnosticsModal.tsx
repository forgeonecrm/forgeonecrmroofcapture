import React from 'react';
import {
  X,
  Activity,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  ShieldCheck,
  Building,
  MapPin,
  Sun,
  Layers,
  Clock,
  ExternalLink,
  Info,
} from 'lucide-react';
import { PropertyRecord } from '../types/pipeline.js';

interface DiagnosticsModalProps {
  isOpen: boolean;
  onClose: () => void;
  property: PropertyRecord | null;
}

export const DiagnosticsModal: React.FC<DiagnosticsModalProps> = ({
  isOpen,
  onClose,
  property,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-xl max-w-3xl w-full shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 rounded-lg bg-cyan-950/70 border border-cyan-800/80 text-cyan-400">
              <Activity className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm font-bold text-white">
                  API Diagnostics &amp; Measurement Provenance
                </h2>
                <span className="px-2 py-0.5 text-[10px] font-mono font-bold bg-slate-800 text-slate-300 rounded border border-slate-700">
                  Project: gmp-demo-project-576437582
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Inspect Google Cloud services, API responses, data provenance, and edge delineation status.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-md transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6 overflow-y-auto flex-1 text-xs">
          {!property ? (
            <div className="p-8 text-center text-slate-500">
              <Activity className="w-8 h-8 mx-auto mb-2 text-slate-600" />
              <p className="font-semibold text-slate-300">No Property Selected</p>
              <p className="text-[11px] text-slate-500 mt-1">
                Select a property from the pipeline or intake an address to view live API diagnostics.
              </p>
            </div>
          ) : (
            <>
              {/* 1. Identified Property & Coordinates Overview */}
              <div className="p-4 bg-slate-800/40 border border-slate-700/60 rounded-lg space-y-3">
                <div className="flex items-center justify-between border-b border-slate-700/60 pb-2">
                  <div className="flex items-center gap-2 font-bold text-slate-200">
                    <MapPin className="w-4 h-4 text-cyan-400" />
                    <span>Identified Property</span>
                  </div>
                  {property.isDemoMode ? (
                    <span className="px-2 py-0.5 text-[10px] font-mono font-bold bg-amber-950/80 text-amber-300 border border-amber-800/80 rounded">
                      DEMO MODE SAMPLE
                    </span>
                  ) : (
                    <span className="px-2 py-0.5 text-[10px] font-mono font-bold bg-cyan-950/80 text-cyan-300 border border-cyan-800/80 rounded">
                      LIVE INTAKE
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-[11px] font-mono">
                  <div>
                    <span className="text-slate-500 block text-[10px]">Input Street Address</span>
                    <span className="text-slate-200 font-sans font-medium">{property.inputAddress}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">USPS Standardized Premise</span>
                    <span className="text-slate-200 font-sans font-medium">{property.standardizedAddress}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">Google Place ID (Tier 1 Perpetual)</span>
                    <span className="text-cyan-400 break-all">{property.googlePlaceId}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">Rooftop Lat/Lng (Tier 2 30-Day TTL)</span>
                    <span className="text-slate-200">
                      {property.coordinates.latitude.toFixed(6)}, {property.coordinates.longitude.toFixed(6)}
                    </span>
                  </div>
                </div>
              </div>

              {/* 2. Google Cloud Platform API Statuses */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Geocoding Status */}
                <div className="p-3.5 bg-slate-800/40 border border-slate-700/60 rounded-lg space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-200">Geocoding &amp; Address Validation</span>
                    <span className="flex items-center gap-1 text-emerald-400 font-mono text-[11px] font-semibold">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      ACTIVE (200 OK)
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400 font-mono space-y-1">
                    <div>Validation: {property.verdict?.validationGranularity || 'PREMISE'}</div>
                    <div>Geocode Level: {property.verdict?.geocodeGranularity || 'ROOFTOP'}</div>
                    <div>USPS CASS: {property.verdict?.uspsCassProcessed ? 'Processed (DPV Verified)' : 'Passed'}</div>
                  </div>
                </div>

                {/* Google Solar API Status */}
                <div className="p-3.5 bg-slate-800/40 border border-slate-700/60 rounded-lg space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-200">Google Solar API</span>
                    {property.solarDataAvailable ? (
                      <span className="flex items-center gap-1 text-emerald-400 font-mono text-[11px] font-semibold">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        AVAILABLE ({property.segments.length} planes)
                      </span>
                    ) : property.solarCoverageStatus === 'NO_COVERAGE_404' ? (
                      <span className="flex items-center gap-1 text-amber-400 font-mono text-[11px] font-semibold">
                        <AlertTriangle className="w-3.5 h-3.5" />
                        NO 3D COVERAGE (404)
                      </span>
                    ) : (
                      <span className="flex items-center gap-1 text-rose-400 font-mono text-[11px] font-semibold">
                        <XCircle className="w-3.5 h-3.5" />
                        {property.solarCoverageStatus || 'NOT AVAILABLE'}
                      </span>
                    )}
                  </div>
                  <div className="text-[11px] text-slate-400 font-mono space-y-1">
                    <div>Coverage Status: {property.solarCoverageStatus}</div>
                    <div>
                      Building Footprint:{' '}
                      {property.solarDataAvailable ? 'Extracted successfully' : 'Not available — requires additional analysis'}
                    </div>
                    <div>
                      DataLayers Rasters:{' '}
                      {property.dataLayers?.dsmUrl ? 'Active (DSM, RGB, Flux)' : '0-day ephemeral'}
                    </div>
                  </div>
                </div>
              </div>

              {/* 3. Measurement Provenance & Truth Table (Priority 2) */}
              <div className="p-4 bg-slate-800/40 border border-slate-700/60 rounded-lg space-y-3">
                <div className="flex items-center justify-between border-b border-slate-700/60 pb-2">
                  <div className="flex items-center gap-2 font-bold text-slate-200">
                    <Info className="w-4 h-4 text-cyan-400" />
                    <span>Measurement Provenance &amp; Verification Breakdown</span>
                  </div>
                  <span className="text-[10px] font-mono text-slate-400">
                    Zero-Fabrication Policy
                  </span>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-[11px]">
                    <thead>
                      <tr className="border-b border-slate-700 text-slate-400 font-mono">
                        <th className="py-1.5 pr-3">Measurement Metric</th>
                        <th className="py-1.5 px-3">Value</th>
                        <th className="py-1.5 px-3">Data Provenance</th>
                        <th className="py-1.5 pl-3">Verification Note</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/80 font-mono text-slate-300">
                      {/* Direct Solar API */}
                      <tr>
                        <td className="py-2 pr-3 font-semibold text-slate-200">Total Roof Surface Area</td>
                        <td className="py-2 px-3 text-cyan-400 font-bold tabular-nums">
                          {property.solarDataAvailable
                            ? `${property.takeoff.totalRoofAreaSqFt.toLocaleString()} sq ft`
                            : 'Not available — requires additional analysis'}
                        </td>
                        <td className="py-2 px-3">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-800/60">
                            DIRECT GOOGLE SOLAR
                          </span>
                        </td>
                        <td className="py-2 pl-3 text-slate-400 text-[10.5px] font-sans">
                          Extracted from Google Solar buildingInsights.wholeRoofStats.
                        </td>
                      </tr>

                      <tr>
                        <td className="py-2 pr-3 font-semibold text-slate-200">Roof Planes / Segments</td>
                        <td className="py-2 px-3 text-cyan-400 font-bold tabular-nums">
                          {property.solarDataAvailable
                            ? `${property.segments.length} planes`
                            : 'Not available — requires additional analysis'}
                        </td>
                        <td className="py-2 px-3">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-800/60">
                            DIRECT GOOGLE SOLAR
                          </span>
                        </td>
                        <td className="py-2 pl-3 text-slate-400 text-[10.5px] font-sans">
                          Extracted from roofSegmentStats with true pitch &amp; azimuth.
                        </td>
                      </tr>

                      <tr>
                        <td className="py-2 pr-3 font-semibold text-slate-200">Dominant Pitch &amp; Azimuth</td>
                        <td className="py-2 px-3 text-slate-200 font-bold tabular-nums">
                          {property.solarDataAvailable
                            ? `${property.takeoff.dominantPitchRatio} (${property.takeoff.dominantPitchDegrees}°) / ${property.takeoff.dominantAzimuthDirection}`
                            : 'Not available — requires additional analysis'}
                        </td>
                        <td className="py-2 px-3">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-800/60">
                            DIRECT GOOGLE SOLAR
                          </span>
                        </td>
                        <td className="py-2 pl-3 text-slate-400 text-[10.5px] font-sans">
                          Area-weighted distribution of Google Solar roof facets.
                        </td>
                      </tr>

                      {/* Calculated Geometry */}
                      <tr>
                        <td className="py-2 pr-3 font-semibold text-slate-200">Planar Footprint / Squares</td>
                        <td className="py-2 px-3 text-slate-300 tabular-nums">
                          {property.solarDataAvailable
                            ? `${property.takeoff.groundFootprintSqFt.toLocaleString()} sq ft (${property.takeoff.totalRoofSquares} sq)`
                            : 'Not available — requires additional analysis'}
                        </td>
                        <td className="py-2 px-3">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-950 text-amber-300 border border-amber-800/60">
                            CALCULATED GEOMETRY
                          </span>
                        </td>
                        <td className="py-2 pl-3 text-slate-400 text-[10.5px] font-sans">
                          Calculated from ground Area projection and area/100.
                        </td>
                      </tr>

                      {/* Linear Edges - Google Solar does NOT provide these */}
                      <tr>
                        <td className="py-2 pr-3 font-semibold text-slate-200">Ridges, Hips &amp; Valleys</td>
                        <td className="py-2 px-3 tabular-nums">
                          {property.takeoff.linearEdgesAvailable && property.takeoff.estimatedRidgesFeet != null ? (
                            <span className="text-slate-200">
                              R: {property.takeoff.estimatedRidgesFeet}&apos; &middot; H: {property.takeoff.estimatedHipsFeet}&apos; &middot; V: {property.takeoff.estimatedValleysFeet}&apos;
                            </span>
                          ) : (
                            <span className="text-amber-400 font-semibold text-[10.5px]">
                              Not available — requires additional analysis
                            </span>
                          )}
                        </td>
                        <td className="py-2 px-3">
                          {property.takeoff.linearEdgesAvailable ? (
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-950 text-purple-300 border border-purple-800/60">
                              {property.isDemoMode ? 'DEMO CAD SPEC' : 'MANUAL CAD ENTRY'}
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-slate-400 border border-slate-700">
                              UNAVAILABLE (NO FABRICATION)
                            </span>
                          )}
                        </td>
                        <td className="py-2 pl-3 text-slate-400 text-[10.5px] font-sans">
                          Google Solar API does not classify linear edge vectors. Delineated manually via editor.
                        </td>
                      </tr>

                      <tr>
                        <td className="py-2 pr-3 font-semibold text-slate-200">Eaves &amp; Rakes (Perimeter)</td>
                        <td className="py-2 px-3 tabular-nums">
                          {property.takeoff.linearEdgesAvailable && property.takeoff.estimatedEavesFeet != null ? (
                            <span className="text-slate-200">
                              E: {property.takeoff.estimatedEavesFeet}&apos; &middot; Rk: {property.takeoff.estimatedRakesFeet}&apos;
                            </span>
                          ) : (
                            <span className="text-amber-400 font-semibold text-[10.5px]">
                              Not available — requires additional analysis
                            </span>
                          )}
                        </td>
                        <td className="py-2 px-3">
                          {property.takeoff.linearEdgesAvailable ? (
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-950 text-purple-300 border border-purple-800/60">
                              {property.isDemoMode ? 'DEMO CAD SPEC' : 'MANUAL CAD ENTRY'}
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-slate-400 border border-slate-700">
                              UNAVAILABLE (NO FABRICATION)
                            </span>
                          )}
                        </td>
                        <td className="py-2 pl-3 text-slate-400 text-[10.5px] font-sans">
                          Not estimated blindly in live mode. Adjustable in Interactive Plane Tuner.
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              {/* 4. Diagnostic Event Log */}
              <div className="p-4 bg-slate-900 border border-slate-800 rounded-lg space-y-2">
                <span className="font-bold text-slate-300 block">
                  Sanitized Pipeline Diagnostic Log
                </span>
                <div className="bg-slate-950 p-3 rounded font-mono text-[10.5px] space-y-1.5 max-h-48 overflow-y-auto">
                  {property.diagnostics && property.diagnostics.length > 0 ? (
                    property.diagnostics.map((log, i) => (
                      <div key={i} className="flex items-start gap-2 text-slate-400">
                        <span className="text-slate-600 shrink-0">
                          [{new Date(log.timestamp).toLocaleTimeString()}]
                        </span>
                        <span
                          className={`font-semibold shrink-0 ${
                            log.status === 'SUCCESS'
                              ? 'text-emerald-400'
                              : log.status === 'WARNING'
                              ? 'text-amber-400'
                              : log.status === 'ERROR'
                              ? 'text-rose-400'
                              : 'text-cyan-400'
                          }`}
                        >
                          [{log.service}]
                        </span>
                        <span className="text-slate-300">{log.message}</span>
                      </div>
                    ))
                  ) : (
                    <div className="text-slate-500">
                      [{new Date(property.createdAt).toLocaleTimeString()}] [PIPELINE] Initialized parcel intake and 3-Tier Anti-Caching boundary.
                    </div>
                  )}
                </div>
                <div className="text-[10px] text-slate-500 font-mono">
                  All requests processed via server-side proxy. Credentials redacted from client surfaces.
                </div>
              </div>
            </>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-3.5 border-t border-slate-800 bg-slate-900/90 shrink-0 text-xs">
          <span className="text-slate-500 font-mono">
            Google Solar API &middot; Geocoding API &middot; Address Validation Pro
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-semibold text-slate-200 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors cursor-pointer"
          >
            Close Diagnostics
          </button>
        </div>
      </div>
    </div>
  );
};
