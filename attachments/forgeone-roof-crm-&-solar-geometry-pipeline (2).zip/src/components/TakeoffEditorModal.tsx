import React, { useState, useEffect } from 'react';
import {
  X,
  Save,
  RotateCcw,
  Plus,
  Trash2,
  Ruler,
  Layers,
  Sun,
  ShieldCheck,
  Check,
  AlertTriangle,
} from 'lucide-react';
import { PropertyRecord, RoofSegment, TakeoffSummary, ExistingSolarSystem } from '../types/pipeline.js';

interface TakeoffEditorModalProps {
  isOpen: boolean;
  onClose: () => void;
  property: PropertyRecord;
  onSave: (updatedProperty: PropertyRecord) => void;
}

export const TakeoffEditorModal: React.FC<TakeoffEditorModalProps> = ({
  isOpen,
  onClose,
  property,
  onSave,
}) => {
  const [activeTab, setActiveTab] = useState<'edges' | 'planes' | 'solar'>('edges');

  // Local state for editable edges
  const [eaves, setEaves] = useState<number>(property.takeoff.estimatedEavesFeet || 0);
  const [ridges, setRidges] = useState<number>(property.takeoff.estimatedRidgesFeet || 0);
  const [rakes, setRakes] = useState<number>(property.takeoff.estimatedRakesFeet || 0);
  const [hips, setHips] = useState<number>(property.takeoff.estimatedHipsFeet || 0);
  const [valleys, setValleys] = useState<number>(property.takeoff.estimatedValleysFeet || 0);

  // Local state for editable segments
  const [segments, setSegments] = useState<RoofSegment[]>(
    JSON.parse(JSON.stringify(property.segments || []))
  );

  // Local state for existing solar
  const [existingSolar, setExistingSolar] = useState<ExistingSolarSystem>(
    property.takeoff.existingSolar || {
      hasExistingSolar: false,
      panelCount: 0,
      capacityKw: 0,
      installedYear: 2020,
      condition: 'GOOD',
      inverterType: 'MICROINVERTER',
      notes: '',
    }
  );

  const [dominantPitchRatio, setDominantPitchRatio] = useState(property.takeoff.dominantPitchRatio || '5.0:12');
  const [dominantAzimuthDirection, setDominantAzimuthDirection] = useState(property.takeoff.dominantAzimuthDirection || 'SSW');
  const [isSaving, setIsSaving] = useState(false);

  // Reset local state when property changes or modal opens
  useEffect(() => {
    if (isOpen) {
      setEaves(property.takeoff.estimatedEavesFeet || 0);
      setRidges(property.takeoff.estimatedRidgesFeet || 0);
      setRakes(property.takeoff.estimatedRakesFeet || 0);
      setHips(property.takeoff.estimatedHipsFeet || 0);
      setValleys(property.takeoff.estimatedValleysFeet || 0);
      setSegments(JSON.parse(JSON.stringify(property.segments || [])));
      setExistingSolar(
        property.takeoff.existingSolar || {
          hasExistingSolar: false,
          panelCount: 0,
          capacityKw: 0,
          installedYear: 2020,
          condition: 'GOOD',
          inverterType: 'MICROINVERTER',
          notes: '',
        }
      );
      setDominantPitchRatio(property.takeoff.dominantPitchRatio || '5.0:12');
      setDominantAzimuthDirection(property.takeoff.dominantAzimuthDirection || 'SSW');
    }
  }, [isOpen, property]);

  if (!isOpen) return null;

  // Real-time calculation of total linear footage
  const totalLinearFeet = eaves + ridges + rakes + hips + valleys;

  // Real-time calculation of total roof surface area from planes
  const calculatedTotalAreaSqFt = segments.reduce((sum, seg) => sum + (seg.areaSqFt || 0), 0);
  const calculatedTotalSquares = Math.round((calculatedTotalAreaSqFt / 100) * 10) / 10;
  const calculatedAreaM2 = Math.round(calculatedTotalAreaSqFt / 10.7639);

  // Handle plane dimension modification
  const handleUpdatePlane = (
    index: number,
    field: keyof RoofSegment,
    value: any
  ) => {
    setSegments((prev) => {
      const copy = [...prev];
      const target = { ...copy[index], [field]: value };

      // If length or width modified, auto-recalculate area if user hasn't typed an explicit area
      if (field === 'estimatedLengthFeet' || field === 'estimatedWidthFeet') {
        const l = field === 'estimatedLengthFeet' ? Number(value) : target.estimatedLengthFeet;
        const w = field === 'estimatedWidthFeet' ? Number(value) : target.estimatedWidthFeet;
        if (l > 0 && w > 0) {
          target.areaSqFt = Math.round(l * w);
          target.areaMeters2 = Math.round((target.areaSqFt / 10.7639) * 10) / 10;
        }
      }

      // If areaSqFt explicitly modified
      if (field === 'areaSqFt') {
        target.areaMeters2 = Math.round((Number(value) / 10.7639) * 10) / 10;
      }

      copy[index] = target;
      return copy;
    });
  };

  // Add new plane
  const handleAddPlane = () => {
    const nextIdx = segments.length;
    const centerLat = property.coordinates.latitude;
    const centerLng = property.coordinates.longitude;

    const newPlane: RoofSegment = {
      segmentIndex: nextIdx,
      pitchDegrees: 20.0,
      pitchRatio: '4.5:12',
      azimuthDegrees: 180,
      azimuthDirection: 'S',
      areaMeters2: 45,
      areaSqFt: 485,
      groundAreaMeters2: 42,
      groundAreaSqFt: 452,
      planeHeightMeters: 6.0,
      planeHeightFeet: 19.5,
      center: { latitude: centerLat, longitude: centerLng },
      boundingBox: {
        sw: { latitude: centerLat - 0.00005, longitude: centerLng - 0.00005 },
        ne: { latitude: centerLat + 0.00005, longitude: centerLng + 0.00005 },
      },
      estimatedLengthFeet: 25,
      estimatedWidthFeet: 19,
      hasExistingPanels: false,
      existingPanelCount: 0,
    };

    setSegments((prev) => [...prev, newPlane]);
  };

  // Remove plane
  const handleRemovePlane = (index: number) => {
    if (segments.length <= 1) {
      alert('A roof model requires at least one plane facet.');
      return;
    }
    setSegments((prev) =>
      prev
        .filter((_, i) => i !== index)
        .map((seg, idx) => ({ ...seg, segmentIndex: idx }))
    );
  };

  // Save changes to backend
  const handleSaveChanges = async () => {
    setIsSaving(true);
    try {
      const updatedTakeoff: TakeoffSummary = {
        ...property.takeoff,
        totalRoofAreaSqFt: calculatedTotalAreaSqFt,
        totalRoofAreaMeters2: calculatedAreaM2,
        totalRoofSquares: calculatedTotalSquares,
        dominantPitchRatio,
        dominantAzimuthDirection,
        totalSegments: segments.length,
        estimatedEavesFeet: eaves,
        estimatedRidgesFeet: ridges,
        estimatedRakesFeet: rakes,
        estimatedHipsFeet: hips,
        estimatedValleysFeet: valleys,
        estimatedTotalLinearEdgeFeet: totalLinearFeet,
        existingSolar,
      };

      const response = await fetch(`/api/pipeline/properties/${property.id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          takeoff: updatedTakeoff,
          segments,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to update property takeoff specifications.');
      }

      const data = await response.json();
      onSave(data.property);
      onClose();
    } catch (err: any) {
      console.error('Error saving takeoff edits:', err);
      alert(`Error saving edits: ${err.message}`);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-xl max-w-3xl w-full shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/90 shrink-0">
          <div>
            <div className="flex items-center gap-2">
              <Ruler className="w-4 h-4 text-cyan-400" />
              <h2 className="text-base font-semibold text-white">
                Edit Roof Geometry &amp; Takeoff Specifications
              </h2>
            </div>
            <p className="text-xs text-slate-400 mt-0.5 truncate max-w-lg">
              {property.inputAddress} &middot; Calibrate planes, edge linear footage, and existing solar installations
            </p>
          </div>
          <button
            onClick={onClose}
            disabled={isSaving}
            className="text-slate-400 hover:text-white p-1 rounded-md transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Controls */}
        <div className="flex items-center gap-2 px-6 pt-3 border-b border-slate-800 bg-slate-900/50 shrink-0">
          <button
            onClick={() => setActiveTab('edges')}
            className={`pb-2.5 text-xs font-semibold border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'edges'
                ? 'border-cyan-400 text-cyan-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Ruler className="w-3.5 h-3.5" />
            <span>Roof Edges &amp; Linears ({totalLinearFeet} ft)</span>
          </button>
          <button
            onClick={() => setActiveTab('planes')}
            className={`pb-2.5 text-xs font-semibold border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'planes'
                ? 'border-cyan-400 text-cyan-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Roof Planes &amp; Dimensions ({segments.length} facets)</span>
          </button>
          <button
            onClick={() => setActiveTab('solar')}
            className={`pb-2.5 text-xs font-semibold border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'solar'
                ? 'border-cyan-400 text-cyan-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sun className="w-3.5 h-3.5 text-amber-400" />
            <span>Existing Solar System</span>
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* TAB 1: EDGES & TAKEOFF LINEARS */}
          {activeTab === 'edges' && (
            <div className="space-y-5">
              <div className="p-3.5 bg-slate-800/40 border border-slate-700/60 rounded-lg flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-white block">
                    Total Estimated Linear Perimeter
                  </span>
                  <span className="text-[11px] text-slate-400 font-mono">
                    Sum of eaves, ridges, rakes, hips, and valleys
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-2xl font-bold font-mono text-cyan-400 tabular-nums">
                    {totalLinearFeet.toLocaleString()}
                  </span>
                  <span className="text-xs text-slate-400 ml-1 font-mono">ft</span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Eaves */}
                <div className="p-3.5 bg-slate-800/60 border border-slate-700/60 rounded-lg space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold text-slate-200">
                      Eaves (Drip Edge Base)
                    </label>
                    <span className="text-[11px] font-mono text-cyan-400">Horizontal base</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      min={0}
                      value={eaves}
                      onChange={(e) => setEaves(Math.max(0, parseInt(e.target.value) || 0))}
                      className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-1.5 text-sm font-mono text-white focus:outline-none focus:border-cyan-500"
                    />
                    <span className="text-xs text-slate-400 font-mono">ft</span>
                  </div>
                  <p className="text-[10px] text-slate-500">
                    Lower edges where gutters and fascia attach.
                  </p>
                </div>

                {/* Ridges */}
                <div className="p-3.5 bg-slate-800/60 border border-slate-700/60 rounded-lg space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold text-slate-200">
                      Ridges (Peak Caps)
                    </label>
                    <span className="text-[11px] font-mono text-cyan-400">Horizontal apex</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      min={0}
                      value={ridges}
                      onChange={(e) => setRidges(Math.max(0, parseInt(e.target.value) || 0))}
                      className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-1.5 text-sm font-mono text-white focus:outline-none focus:border-cyan-500"
                    />
                    <span className="text-xs text-slate-400 font-mono">ft</span>
                  </div>
                  <p className="text-[10px] text-slate-500">
                    Highest horizontal intersections of two roof planes.
                  </p>
                </div>

                {/* Rakes */}
                <div className="p-3.5 bg-slate-800/60 border border-slate-700/60 rounded-lg space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold text-slate-200">
                      Rakes (Gable Edges)
                    </label>
                    <span className="text-[11px] font-mono text-cyan-400">Sloped gable</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      min={0}
                      value={rakes}
                      onChange={(e) => setRakes(Math.max(0, parseInt(e.target.value) || 0))}
                      className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-1.5 text-sm font-mono text-white focus:outline-none focus:border-cyan-500"
                    />
                    <span className="text-xs text-slate-400 font-mono">ft</span>
                  </div>
                  <p className="text-[10px] text-slate-500">
                    Slanted edges on gable ends running from eave to ridge.
                  </p>
                </div>

                {/* Hips */}
                <div className="p-3.5 bg-slate-800/60 border border-slate-700/60 rounded-lg space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold text-slate-200">
                      Hips (Exterior Inclines)
                    </label>
                    <span className="text-[11px] font-mono text-cyan-400">Diagonal peak</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      min={0}
                      value={hips}
                      onChange={(e) => setHips(Math.max(0, parseInt(e.target.value) || 0))}
                      className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-1.5 text-sm font-mono text-white focus:outline-none focus:border-cyan-500"
                    />
                    <span className="text-xs text-slate-400 font-mono">ft</span>
                  </div>
                  <p className="text-[10px] text-slate-500">
                    Inclined external junctions forming hip corners.
                  </p>
                </div>

                {/* Valleys */}
                <div className="p-3.5 bg-slate-800/60 border border-slate-700/60 rounded-lg space-y-2 sm:col-span-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold text-slate-200">
                      Valleys (Internal Drainage Channels)
                    </label>
                    <span className="text-[11px] font-mono text-cyan-400">Internal angle</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      min={0}
                      value={valleys}
                      onChange={(e) => setValleys(Math.max(0, parseInt(e.target.value) || 0))}
                      className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-1.5 text-sm font-mono text-white focus:outline-none focus:border-cyan-500"
                    />
                    <span className="text-xs text-slate-400 font-mono">ft</span>
                  </div>
                  <p className="text-[10px] text-slate-500">
                    Internal v-shaped drainage channels requiring heavy-duty valley flashing.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: ROOF PLANES & FACETS */}
          {activeTab === 'planes' && (
            <div className="space-y-4">
              <div className="p-3.5 bg-slate-800/40 border border-slate-700/60 rounded-lg flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-white block">
                    Calculated Roof Surface Area
                  </span>
                  <span className="text-[11px] text-slate-400 font-mono">
                    {calculatedTotalAreaSqFt.toLocaleString()} sq ft ({calculatedAreaM2.toLocaleString()} m&sup2;)
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-2xl font-bold font-mono text-cyan-400 tabular-nums">
                    {calculatedTotalSquares}
                  </span>
                  <span className="text-xs text-slate-400 ml-1 font-mono">squares</span>
                </div>
              </div>

              {/* Dominant Pitch & Azimuth inputs */}
              <div className="grid grid-cols-2 gap-3 p-3 bg-slate-800/30 border border-slate-700/50 rounded-lg">
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">
                    Dominant Pitch Ratio
                  </label>
                  <input
                    type="text"
                    value={dominantPitchRatio}
                    onChange={(e) => setDominantPitchRatio(e.target.value)}
                    placeholder="e.g. 5.0:12"
                    className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1 text-xs font-mono text-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">
                    Dominant Azimuth Facing
                  </label>
                  <input
                    type="text"
                    value={dominantAzimuthDirection}
                    onChange={(e) => setDominantAzimuthDirection(e.target.value)}
                    placeholder="e.g. SSW"
                    className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1 text-xs font-mono text-white"
                  />
                </div>
              </div>

              {/* Individual Plane Cards */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-200">
                    Individual Roof Planes ({segments.length})
                  </span>
                  <button
                    type="button"
                    onClick={handleAddPlane}
                    className="flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-cyan-300 bg-cyan-950/60 hover:bg-cyan-900/60 border border-cyan-800/60 rounded-md transition-colors cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Plane</span>
                  </button>
                </div>

                {segments.map((seg, idx) => (
                  <div
                    key={idx}
                    className="p-3.5 bg-slate-800/60 border border-slate-700/70 rounded-lg space-y-3"
                  >
                    <div className="flex items-center justify-between border-b border-slate-700/60 pb-2">
                      <div className="flex items-center gap-2">
                        <span className="w-5 h-5 rounded bg-cyan-600 text-white font-mono font-bold text-xs flex items-center justify-center">
                          #{idx + 1}
                        </span>
                        <span className="text-xs font-bold text-slate-200">
                          Plane #{idx + 1} Takeoff
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleRemovePlane(idx)}
                        className="text-slate-500 hover:text-rose-400 p-1 transition-colors"
                        title="Delete Plane"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs font-mono">
                      <div>
                        <label className="text-[10px] text-slate-400 block mb-0.5">Length (ft)</label>
                        <input
                          type="number"
                          value={seg.estimatedLengthFeet}
                          onChange={(e) =>
                            handleUpdatePlane(idx, 'estimatedLengthFeet', Math.max(1, parseInt(e.target.value) || 0))
                          }
                          className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-xs text-white"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-slate-400 block mb-0.5">Width (ft)</label>
                        <input
                          type="number"
                          value={seg.estimatedWidthFeet}
                          onChange={(e) =>
                            handleUpdatePlane(idx, 'estimatedWidthFeet', Math.max(1, parseInt(e.target.value) || 0))
                          }
                          className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-xs text-white"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-slate-400 block mb-0.5">Area (sq ft)</label>
                        <input
                          type="number"
                          value={seg.areaSqFt}
                          onChange={(e) =>
                            handleUpdatePlane(idx, 'areaSqFt', Math.max(1, parseInt(e.target.value) || 0))
                          }
                          className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-xs text-white"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-slate-400 block mb-0.5">Height (ft)</label>
                        <input
                          type="number"
                          step="0.5"
                          value={seg.planeHeightFeet}
                          onChange={(e) =>
                            handleUpdatePlane(idx, 'planeHeightFeet', parseFloat(e.target.value) || 0)
                          }
                          className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-xs text-white"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs font-mono pt-1">
                      <div>
                        <label className="text-[10px] text-slate-400 block mb-0.5">Pitch Ratio</label>
                        <input
                          type="text"
                          value={seg.pitchRatio}
                          onChange={(e) => handleUpdatePlane(idx, 'pitchRatio', e.target.value)}
                          className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-xs text-white"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-slate-400 block mb-0.5">Pitch (deg)</label>
                        <input
                          type="number"
                          step="0.5"
                          value={seg.pitchDegrees}
                          onChange={(e) =>
                            handleUpdatePlane(idx, 'pitchDegrees', parseFloat(e.target.value) || 0)
                          }
                          className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-xs text-white"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-slate-400 block mb-0.5">Azimuth (facing)</label>
                        <input
                          type="text"
                          value={seg.azimuthDirection}
                          onChange={(e) => handleUpdatePlane(idx, 'azimuthDirection', e.target.value)}
                          className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-xs text-white"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-slate-400 block mb-0.5">Azimuth (deg)</label>
                        <input
                          type="number"
                          value={seg.azimuthDegrees}
                          onChange={(e) =>
                            handleUpdatePlane(idx, 'azimuthDegrees', parseInt(e.target.value) || 0)
                          }
                          className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-xs text-white"
                        />
                      </div>
                    </div>

                    {/* Facet Existing Solar Toggle */}
                    <div className="flex items-center justify-between pt-2 border-t border-slate-700/40 text-xs">
                      <label className="flex items-center gap-2 cursor-pointer text-slate-300">
                        <input
                          type="checkbox"
                          checked={Boolean(seg.hasExistingPanels)}
                          onChange={(e) =>
                            handleUpdatePlane(idx, 'hasExistingPanels', e.target.checked)
                          }
                          className="rounded border-slate-700 text-cyan-500 focus:ring-0"
                        />
                        <span>Existing solar panels mounted on this plane</span>
                      </label>

                      {seg.hasExistingPanels && (
                        <div className="flex items-center gap-1.5 font-mono">
                          <span className="text-[11px] text-slate-400">Panels:</span>
                          <input
                            type="number"
                            min={1}
                            value={seg.existingPanelCount || 10}
                            onChange={(e) =>
                              handleUpdatePlane(idx, 'existingPanelCount', parseInt(e.target.value) || 0)
                            }
                            className="w-16 bg-slate-900 border border-slate-700 rounded px-2 py-0.5 text-xs text-white font-mono"
                          />
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: EXISTING SOLAR SYSTEM */}
          {activeTab === 'solar' && (
            <div className="space-y-4">
              <div className="p-4 bg-slate-800/60 border border-slate-700/60 rounded-lg space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Sun className="w-5 h-5 text-amber-400" />
                    <div>
                      <h3 className="text-sm font-semibold text-white">
                        Existing Solar PV System Audit
                      </h3>
                      <p className="text-xs text-slate-400">
                        Record pre-installed panels for reroof detach/reset or system expansions.
                      </p>
                    </div>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={existingSolar.hasExistingSolar}
                      onChange={(e) =>
                        setExistingSolar((prev) => ({
                          ...prev,
                          hasExistingSolar: e.target.checked,
                          panelCount: e.target.checked && prev.panelCount === 0 ? 20 : prev.panelCount,
                          capacityKw: e.target.checked && prev.capacityKw === 0 ? 7.6 : prev.capacityKw,
                        }))
                      }
                      className="sr-only peer"
                    />
                    <div className="w-9 h-5 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-amber-500"></div>
                  </label>
                </div>

                {existingSolar.hasExistingSolar && (
                  <div className="space-y-4 pt-3 border-t border-slate-700/60">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-medium text-slate-300 mb-1">
                          Existing Panel Count
                        </label>
                        <input
                          type="number"
                          min={1}
                          value={existingSolar.panelCount}
                          onChange={(e) =>
                            setExistingSolar((prev) => ({
                              ...prev,
                              panelCount: Math.max(0, parseInt(e.target.value) || 0),
                            }))
                          }
                          className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white font-mono"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-slate-300 mb-1">
                          System Capacity (kW)
                        </label>
                        <input
                          type="number"
                          step="0.1"
                          value={existingSolar.capacityKw}
                          onChange={(e) =>
                            setExistingSolar((prev) => ({
                              ...prev,
                              capacityKw: Math.max(0, parseFloat(e.target.value) || 0),
                            }))
                          }
                          className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white font-mono"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-slate-300 mb-1">
                          Inverter Architecture
                        </label>
                        <select
                          value={existingSolar.inverterType}
                          onChange={(e) =>
                            setExistingSolar((prev) => ({
                              ...prev,
                              inverterType: e.target.value as any,
                            }))
                          }
                          className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white"
                        >
                          <option value="MICROINVERTER">Microinverters (Enphase, APsystems)</option>
                          <option value="OPTIMIZER">DC Optimizers (SolarEdge)</option>
                          <option value="STRING">Central String Inverter (SMA, Fronius)</option>
                          <option value="UNKNOWN">Unknown / Other</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-slate-300 mb-1">
                          Reroof Operational Condition
                        </label>
                        <select
                          value={existingSolar.condition}
                          onChange={(e) =>
                            setExistingSolar((prev) => ({
                              ...prev,
                              condition: e.target.value as any,
                            }))
                          }
                          className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white"
                        >
                          <option value="GOOD">Good Condition (Operational)</option>
                          <option value="FAIR">Fair Condition (Functional)</option>
                          <option value="NEEDS_REROOF_DETACH_RESET">
                            Requires Detach &amp; Reset for Reroof
                          </option>
                          <option value="OBSOLETE_DECOMMISSION">
                            Obsolete / Decommission &amp; Recycle
                          </option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-slate-300 mb-1">
                          Approx. Installation Year
                        </label>
                        <input
                          type="number"
                          min={2000}
                          max={2026}
                          value={existingSolar.installedYear || 2019}
                          onChange={(e) =>
                            setExistingSolar((prev) => ({
                              ...prev,
                              installedYear: parseInt(e.target.value) || 2019,
                            }))
                          }
                          className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white font-mono"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-300 mb-1">
                        Roofing Detach / Reset Scope Notes
                      </label>
                      <textarea
                        rows={2}
                        value={existingSolar.notes || ''}
                        onChange={(e) =>
                          setExistingSolar((prev) => ({
                            ...prev,
                            notes: e.target.value,
                          }))
                        }
                        placeholder="e.g. 24 panels on South gable plane. Requires new roof stanchions and flashings after tear-off."
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                      />
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-slate-800 bg-slate-900/90 shrink-0">
          <div className="text-[11px] text-slate-400 font-mono">
            <span>Squares: </span>
            <span className="text-cyan-400 font-bold">{calculatedTotalSquares} sq</span>
            <span className="mx-2">&middot;</span>
            <span>Perimeter: </span>
            <span className="text-cyan-400 font-bold">{totalLinearFeet} ft</span>
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              disabled={isSaving}
              className="px-4 py-2 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSaveChanges}
              disabled={isSaving}
              className="flex items-center gap-1.5 px-5 py-2 text-xs font-semibold text-white bg-cyan-600 hover:bg-cyan-500 rounded-lg shadow-sm transition-colors cursor-pointer"
            >
              <Save className="w-3.5 h-3.5" />
              <span>{isSaving ? 'Saving Edits...' : 'Save Takeoff Specs'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
