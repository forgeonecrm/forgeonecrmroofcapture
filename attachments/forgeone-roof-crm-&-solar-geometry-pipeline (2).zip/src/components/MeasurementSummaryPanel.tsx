import React, { useState, useEffect, useMemo } from 'react';
import {
  Compass,
  Layers,
  Ruler,
  Sun,
  ShieldCheck,
  CheckCircle,
  FileSpreadsheet,
  Download,
  AlertCircle,
  Clock,
  Database,
  ArrowRight,
  ExternalLink,
  Edit3,
  Sliders,
  Check,
  RotateCcw,
  Save,
  X,
  Eye,
  EyeOff,
  Activity,
  Plus,
  Minus,
  Package,
  Boxes,
  DollarSign,
  Percent,
  Shield,
  Hammer,
  Info,
} from 'lucide-react';
import {
  PropertyRecord,
  RoofSegment,
  StructuralVisibility,
  TakeoffSummary,
} from '../types/pipeline.js';
import { recalculateSegmentBoundingBox } from '../utils/roofGeometryOverlays.js';
import {
  RoofingMaterialType,
  MATERIAL_PROFILES,
  calculateMaterialTakeoff,
  MaterialTakeoffResult,
} from '../utils/materialTakeoffCalculator.js';
import { TakeoffEditorModal } from './TakeoffEditorModal.js';

interface MeasurementSummaryPanelProps {
  property: PropertyRecord | null;
  selectedSegmentIndex: number | null;
  onSelectSegment: (index: number | null) => void;
  onUpdateStatus: (newStatus: PropertyRecord['status']) => void;
  onPropertyUpdated?: (updatedProperty: PropertyRecord) => void;
  onOpenDiagnostics?: () => void;
  structuralVisibility: StructuralVisibility;
  onToggleStructuralVisibility: (key: keyof StructuralVisibility) => void;
}

const COMMON_PITCH_RATIOS = [
  { ratio: '3.0:12', deg: 14.0 },
  { ratio: '4.0:12', deg: 18.4 },
  { ratio: '5.0:12', deg: 22.6 },
  { ratio: '6.0:12', deg: 26.6 },
  { ratio: '7.0:12', deg: 30.3 },
  { ratio: '8.0:12', deg: 33.7 },
  { ratio: '9.0:12', deg: 36.9 },
  { ratio: '10.0:12', deg: 39.8 },
  { ratio: '12.0:12', deg: 45.0 },
];

export const MeasurementSummaryPanel: React.FC<MeasurementSummaryPanelProps> = ({
  property,
  selectedSegmentIndex,
  onSelectSegment,
  onUpdateStatus,
  onPropertyUpdated,
  onOpenDiagnostics,
  structuralVisibility,
  onToggleStructuralVisibility,
}) => {
  const [activeTab, setActiveTab] = useState<
    'takeoff' | 'materials' | 'planes' | 'diagnostics' | 'validation' | 'geotiff'
  >('takeoff');
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [isInteractiveEditMode, setIsInteractiveEditMode] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Material Takeoff State
  const [selectedMaterial, setSelectedMaterial] = useState<RoofingMaterialType>('shingle');
  const [wasteFactor, setWasteFactor] = useState<number>(10);
  const [customUnitCosts, setCustomUnitCosts] = useState<Record<string, number>>({});
  const [editingCostItemId, setEditingCostItemId] = useState<string | null>(null);

  // Local working copy for real-time in-panel editing
  const [workingSegments, setWorkingSegments] = useState<RoofSegment[]>([]);
  const [workingEdges, setWorkingEdges] = useState({
    eaves: 0,
    ridges: 0,
    hips: 0,
    valleys: 0,
    rakes: 0,
  });

  // Sync working state when property changes or when entering edit mode
  useEffect(() => {
    if (property) {
      setWorkingSegments(JSON.parse(JSON.stringify(property.segments || [])));
      setWorkingEdges({
        eaves: property.takeoff?.estimatedEavesFeet ?? 0,
        ridges: property.takeoff?.estimatedRidgesFeet ?? 0,
        hips: property.takeoff?.estimatedHipsFeet ?? 0,
        valleys: property.takeoff?.estimatedValleysFeet ?? 0,
        rakes: property.takeoff?.estimatedRakesFeet ?? 0,
      });
    }
  }, [property?.id, isInteractiveEditMode]);

  if (!property) {
    return (
      <div className="w-96 md:w-[420px] bg-slate-900 border-l border-slate-800 p-8 flex flex-col items-center justify-center text-center text-slate-500 h-full">
        <Ruler className="w-10 h-10 text-slate-600 mb-3" />
        <p className="text-sm font-semibold text-slate-300">No Property Selected</p>
        <p className="text-xs text-slate-500 mt-1">
          Select a property from the pipeline or intake a new street address to view roof geometry and takeoff metrics.
        </p>
      </div>
    );
  }

  const { takeoff, verdict, segments, coordinates, googlePlaceId, dataLayers } = property;
  const activeSegments = isInteractiveEditMode ? workingSegments : segments;
  const isSolarAvailable = property.solarDataAvailable !== false && activeSegments.length > 0;

  // Currently active plane for editing (default to first plane if none selected)
  const currentEditIndex =
    selectedSegmentIndex !== null && selectedSegmentIndex < activeSegments.length
      ? selectedSegmentIndex
      : 0;
  const currentPlane = activeSegments[currentEditIndex] || null;

  // Real-time live totals based on working state
  const liveTotalRoofAreaSqFt = activeSegments.reduce((sum, s) => sum + (s.areaSqFt || 0), 0);
  const liveTotalSquares = Math.round((liveTotalRoofAreaSqFt / 100) * 10) / 10;
  const liveTotalEdgesFeet =
    workingEdges.eaves +
    workingEdges.ridges +
    workingEdges.hips +
    workingEdges.valleys +
    workingEdges.rakes;

  // Dynamic Material Takeoff Calculation based on current roof surface areas & linear edges
  const materialTakeoff: MaterialTakeoffResult = useMemo(() => {
    const netArea = isInteractiveEditMode
      ? liveTotalRoofAreaSqFt
      : (property.takeoff?.totalRoofAreaSqFt || 0);
    const eaves = isInteractiveEditMode ? workingEdges.eaves : (property.takeoff?.estimatedEavesFeet || 0);
    const ridges = isInteractiveEditMode ? workingEdges.ridges : (property.takeoff?.estimatedRidgesFeet || 0);
    const hips = isInteractiveEditMode ? workingEdges.hips : (property.takeoff?.estimatedHipsFeet || 0);
    const valleys = isInteractiveEditMode ? workingEdges.valleys : (property.takeoff?.estimatedValleysFeet || 0);
    const rakes = isInteractiveEditMode ? workingEdges.rakes : (property.takeoff?.estimatedRakesFeet || 0);

    const result = calculateMaterialTakeoff({
      materialType: selectedMaterial,
      netAreaSqFt: netArea,
      wastePercent: wasteFactor,
      eavesFeet: eaves,
      ridgesFeet: ridges,
      hipsFeet: hips,
      valleysFeet: valleys,
      rakesFeet: rakes,
    });

    if (Object.keys(customUnitCosts).length > 0) {
      result.items = result.items.map((item) => {
        if (customUnitCosts[item.id] !== undefined) {
          const newCost = customUnitCosts[item.id];
          return {
            ...item,
            unitCost: newCost,
            totalCost: Math.round(item.quantity * newCost * 100) / 100,
          };
        }
        return item;
      });
      result.totalMaterialCost = Math.round(result.items.reduce((sum, item) => sum + item.totalCost, 0));
      result.costPerSquare = result.grossSquares > 0 ? Math.round(result.totalMaterialCost / result.grossSquares) : 0;
    }

    return result;
  }, [
    selectedMaterial,
    wasteFactor,
    isInteractiveEditMode,
    liveTotalRoofAreaSqFt,
    workingEdges,
    property.takeoff,
    customUnitCosts,
  ]);

  // Interactive Plane Dimension Adjuster Handler
  const handlePlaneDimensionChange = (
    field: 'length' | 'width' | 'height' | 'pitch' | 'azimuth' | 'area',
    value: number | string
  ) => {
    if (!currentPlane || currentEditIndex === null) return;

    setWorkingSegments((prev) => {
      const copy = [...prev];
      let target = { ...copy[currentEditIndex] };

      let newLen = target.estimatedLengthFeet;
      let newWid = target.estimatedWidthFeet;
      let newHeight = target.planeHeightFeet;
      let newPitchDeg = target.pitchDegrees;
      let newPitchRatio = target.pitchRatio;
      let newAzDeg = target.azimuthDegrees;
      let newAzDir = target.azimuthDirection;

      if (field === 'length') {
        newLen = Math.max(1, Number(value));
      } else if (field === 'width') {
        newWid = Math.max(1, Number(value));
      } else if (field === 'height') {
        newHeight = Math.max(1, Number(value));
        target.planeHeightFeet = newHeight;
        target.planeHeightMeters = Math.round((newHeight / 3.28084) * 10) / 10;
      } else if (field === 'pitch') {
        const matched = COMMON_PITCH_RATIOS.find((p) => p.ratio === value);
        if (matched) {
          newPitchRatio = matched.ratio;
          newPitchDeg = matched.deg;
          target.pitchRatio = newPitchRatio;
          target.pitchDegrees = newPitchDeg;
        }
      } else if (field === 'azimuth') {
        newAzDeg = Math.round(Number(value)) % 360;
        target.azimuthDegrees = newAzDeg;
        if (newAzDeg >= 337.5 || newAzDeg < 22.5) newAzDir = 'N';
        else if (newAzDeg < 67.5) newAzDir = 'NE';
        else if (newAzDeg < 112.5) newAzDir = 'E';
        else if (newAzDeg < 157.5) newAzDir = 'SE';
        else if (newAzDeg < 202.5) newAzDir = 'S';
        else if (newAzDeg < 247.5) newAzDir = 'SW';
        else if (newAzDeg < 292.5) newAzDir = 'W';
        else newAzDir = 'NW';
        target.azimuthDirection = newAzDir;
      } else if (field === 'area') {
        const customArea = Math.max(10, Number(value));
        target.areaSqFt = customArea;
        target.areaMeters2 = Math.round((customArea / 10.7639) * 10) / 10;
      }

      target = recalculateSegmentBoundingBox(target, newLen, newWid);
      target.source = 'MANUAL_EDIT';
      copy[currentEditIndex] = target;

      if (onPropertyUpdated) {
        const liveProperty: PropertyRecord = {
          ...property,
          segments: copy,
          takeoff: {
            ...property.takeoff,
            totalRoofAreaSqFt: copy.reduce((sum, s) => sum + s.areaSqFt, 0),
            totalRoofAreaMeters2: Math.round(
              copy.reduce((sum, s) => sum + s.areaSqFt, 0) / 10.7639
            ),
            totalRoofSquares:
              Math.round(
                (copy.reduce((sum, s) => sum + s.areaSqFt, 0) / 100) * 10
              ) / 10,
          },
        };
        onPropertyUpdated(liveProperty);
      }

      return copy;
    });
  };

  // Save changes to backend server
  const handleSaveInteractiveEdits = async () => {
    setIsSaving(true);
    setSaveSuccess(false);

    try {
      const updatedTakeoff: TakeoffSummary = {
        ...property.takeoff,
        totalRoofAreaSqFt: liveTotalRoofAreaSqFt,
        totalRoofAreaMeters2: Math.round((liveTotalRoofAreaSqFt / 10.7639) * 10) / 10,
        totalRoofSquares: liveTotalSquares,
        linearEdgesAvailable: true,
        estimatedEavesFeet: workingEdges.eaves,
        estimatedRidgesFeet: workingEdges.ridges,
        estimatedHipsFeet: workingEdges.hips,
        estimatedValleysFeet: workingEdges.valleys,
        estimatedRakesFeet: workingEdges.rakes,
        estimatedTotalLinearEdgeFeet: liveTotalEdgesFeet,
        totalSegments: workingSegments.length,
      };

      const res = await fetch(`/api/pipeline/properties/${property.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          takeoff: updatedTakeoff,
          segments: workingSegments,
          customEdges: property.customEdges,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        if (onPropertyUpdated && data.property) {
          onPropertyUpdated(data.property);
        }
        setSaveSuccess(true);
        setTimeout(() => setSaveSuccess(false), 2500);
      }
    } catch (err) {
      console.error('Save error:', err);
    } finally {
      setIsSaving(false);
    }
  };

  const handleResetInteractiveEdits = () => {
    setWorkingSegments(JSON.parse(JSON.stringify(property.segments || [])));
    setWorkingEdges({
      eaves: property.takeoff?.estimatedEavesFeet ?? 0,
      ridges: property.takeoff?.estimatedRidgesFeet ?? 0,
      hips: property.takeoff?.estimatedHipsFeet ?? 0,
      valleys: property.takeoff?.estimatedValleysFeet ?? 0,
      rakes: property.takeoff?.estimatedRakesFeet ?? 0,
    });
    if (onPropertyUpdated) {
      onPropertyUpdated(property);
    }
  };

  // Export Material BOM CSV
  const handleExportMaterialBomCsv = () => {
    if (!property) return;

    const rows: (string | number)[][] = [
      ['--- ROOFING MATERIAL TAKEOFF BILL OF MATERIALS (BOM) ---'],
      ['Property ID', property.id],
      ['Standardized Address', property.standardizedAddress],
      ['Selected Material System', materialTakeoff.materialName],
      ['Net Roof Surface Area', `${materialTakeoff.netAreaSqFt.toLocaleString()} sq ft (${materialTakeoff.netSquares} squares)`],
      ['Waste Factor Allowance', `${materialTakeoff.wastePercent}%`],
      ['Gross Estimated Roof Area', `${materialTakeoff.grossAreaSqFt.toLocaleString()} sq ft (${materialTakeoff.grossSquares} squares)`],
      ['Estimated Total Material Cost', `$${materialTakeoff.totalMaterialCost.toLocaleString()}`],
      ['Estimated Cost Per Square', `$${materialTakeoff.costPerSquare} / sq`],
      [],
      [
        'Item Category',
        'Material Description',
        'Commercial Specification',
        'Coverage Formula',
        'Quantity Required',
        'Order Unit',
        'Est. Unit Cost ($)',
        'Extended Total ($)',
      ],
    ];

    materialTakeoff.items.forEach((item) => {
      rows.push([
        item.category.toUpperCase().replace(/_/g, ' '),
        item.name,
        item.specification,
        item.coverageFormula,
        item.quantity,
        item.unit,
        item.unitCost.toFixed(2),
        item.totalCost.toFixed(2),
      ]);
    });

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      rows
        .map((row) =>
          row
            .map((cell) => {
              const str = (cell ?? '').toString();
              if (str.includes(',') || str.includes('"') || str.includes('\n')) {
                return `"${str.replace(/"/g, '""')}"`;
              }
              return str;
            })
            .join(',')
        )
        .join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `material-bom-${materialTakeoff.materialType}-${property.id}.csv`);
    document.body.appendChild(link);
    link.click();
    link.remove();
  };

  // Comprehensive Takeoff + Materials CSV Export
  const handleExportCsv = () => {
    if (!property) return;

    const rows: (string | number)[][] = [
      ['--- PROPERTY & ROOF TAKEOFF SUMMARY ---'],
      ['Property ID', property.id],
      ['Input Address', property.inputAddress],
      ['Standardized Premise', property.standardizedAddress],
      ['Google Place ID', property.googlePlaceId],
      ['Tenant', `${property.tenantName} (${property.tenantId})`],
      ['Assessment Mode', property.isDemoMode ? 'DEMO MODE SAMPLE' : 'LIVE SOLAR INTAKE'],
      ['Solar Geometry Available', property.solarDataAvailable ? 'YES' : 'NO — REQUIRES ADDITIONAL ANALYSIS'],
      ['Latitude', property.coordinates.latitude],
      ['Longitude', property.coordinates.longitude],
      ['Coordinates Cached At', property.coordinates.cachedAt],
      ['Coordinates 30-Day TTL Expires At', property.coordinates.expiresAt],
      ['Pipeline Status', property.status],
      ['Total Roof Surface Area (sq ft)', property.solarDataAvailable ? property.takeoff.totalRoofAreaSqFt : 'Not available — requires additional analysis'],
      ['Total Roof Surface Area (m2)', property.solarDataAvailable ? property.takeoff.totalRoofAreaMeters2 : 'Not available — requires additional analysis'],
      ['Total Roof Squares (100 sq ft)', property.solarDataAvailable ? property.takeoff.totalRoofSquares : 'Not available — requires additional analysis'],
      ['Ground Planar Footprint (sq ft)', property.solarDataAvailable ? property.takeoff.groundFootprintSqFt : 'Not available — requires additional analysis'],
      ['Dominant Pitch Ratio', property.solarDataAvailable ? property.takeoff.dominantPitchRatio : 'Not available — requires additional analysis'],
      ['Dominant Pitch (degrees)', property.solarDataAvailable ? property.takeoff.dominantPitchDegrees : 'Not available — requires additional analysis'],
      ['Dominant Azimuth Direction', property.solarDataAvailable ? property.takeoff.dominantAzimuthDirection : 'N/A'],
      ['Dominant Azimuth (degrees)', property.solarDataAvailable ? property.takeoff.dominantAzimuthDegrees : 'N/A'],
      ['Total Roof Planes Count', property.segments.length],
      ['Estimated Eaves (linear ft)', property.takeoff.linearEdgesAvailable && property.takeoff.estimatedEavesFeet != null ? property.takeoff.estimatedEavesFeet : 'Not available — requires additional analysis'],
      ['Estimated Ridges (linear ft)', property.takeoff.linearEdgesAvailable && property.takeoff.estimatedRidgesFeet != null ? property.takeoff.estimatedRidgesFeet : 'Not available — requires additional analysis'],
      ['Estimated Rakes (linear ft)', property.takeoff.linearEdgesAvailable && property.takeoff.estimatedRakesFeet != null ? property.takeoff.estimatedRakesFeet : 'Not available — requires additional analysis'],
      ['Estimated Hips (linear ft)', property.takeoff.linearEdgesAvailable && property.takeoff.estimatedHipsFeet != null ? property.takeoff.estimatedHipsFeet : 'Not available — requires additional analysis'],
      ['Estimated Valleys (linear ft)', property.takeoff.linearEdgesAvailable && property.takeoff.estimatedValleysFeet != null ? property.takeoff.estimatedValleysFeet : 'Not available — requires additional analysis'],
      ['Estimated Total Linear Edge (linear ft)', property.takeoff.linearEdgesAvailable && property.takeoff.estimatedTotalLinearEdgeFeet != null ? property.takeoff.estimatedTotalLinearEdgeFeet : 'Not available — requires additional analysis'],
      ['Max Solar Panels Count', property.solarDataAvailable ? property.takeoff.maxPanelsCount : 'N/A'],
      ['Solar System Capacity (kWp)', property.solarDataAvailable ? property.takeoff.maxCapacityKw : 'N/A'],
      [],
      ['--- INDIVIDUAL ROOF PLANE GEOMETRY (GOOGLE SOLAR) ---'],
      [
        'Plane #',
        'Pitch Ratio',
        'Pitch (deg)',
        'Azimuth Direction',
        'Azimuth (deg)',
        'Surface Area (sq ft)',
        'Surface Area (m2)',
        'Ground Area (sq ft)',
        'Est. Length (ft)',
        'Est. Width (ft)',
        'Plane Height (ft)',
        'Center Latitude',
        'Center Longitude',
        'Existing Solar Panels',
        'Data Source',
      ],
    ];

    property.segments.forEach((seg) => {
      rows.push([
        `#${seg.segmentIndex + 1}`,
        seg.pitchRatio,
        seg.pitchDegrees,
        seg.azimuthDirection,
        seg.azimuthDegrees,
        seg.areaSqFt,
        seg.areaMeters2,
        seg.groundAreaSqFt,
        seg.estimatedLengthFeet,
        seg.estimatedWidthFeet,
        seg.planeHeightFeet,
        seg.center.latitude,
        seg.center.longitude,
        seg.hasExistingPanels ? `${seg.existingPanelCount || 0} panels` : 'None',
        seg.source || 'DIRECT_SOLAR_API',
      ]);
    });

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      rows
        .map((row) =>
          row
            .map((cell) => {
              const str = (cell ?? '').toString();
              if (str.includes(',') || str.includes('"') || str.includes('\n')) {
                return `"${str.replace(/"/g, '""')}"`;
              }
              return str;
            })
            .join(',')
        )
        .join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `roof-takeoff-${property.id}.csv`);
    document.body.appendChild(link);
    link.click();
    link.remove();
  };

  const handleExportJson = () => {
    const exportPayload = {
      ...property,
      materialTakeoff,
    };
    const dataStr =
      'data:text/json;charset=utf-8,' +
      encodeURIComponent(JSON.stringify(exportPayload, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `roof-takeoff-${property.id}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="w-96 md:w-[420px] bg-slate-900 border-l border-slate-800 flex flex-col h-full shrink-0 overflow-hidden text-slate-200">
      {/* Panel Top Header */}
      <div className="p-4 border-b border-slate-800 space-y-2.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span
              className={`w-2 h-2 rounded-full ${
                property.solarDataAvailable ? 'bg-cyan-400' : 'bg-amber-400 animate-pulse'
              }`}
            ></span>
            <h2 className="text-sm font-bold text-white truncate max-w-[170px]">
              {property.inputAddress}
            </h2>
          </div>

          <div className="flex items-center gap-1.5">
            {/* Demo Mode or Live Status Badge */}
            {property.isDemoMode ? (
              <span className="px-2 py-0.5 text-[10px] font-mono font-bold bg-amber-950/80 text-amber-300 border border-amber-800/80 rounded">
                DEMO MODE
              </span>
            ) : property.solarDataAvailable ? (
              <span className="px-2 py-0.5 text-[10px] font-mono font-bold bg-cyan-950/80 text-cyan-300 border border-cyan-800/80 rounded">
                SOLAR API
              </span>
            ) : (
              <span className="px-2 py-0.5 text-[10px] font-mono font-bold bg-rose-950/80 text-rose-300 border border-rose-800/80 rounded">
                GEOCODED ONLY
              </span>
            )}

            {/* Interactive Edit Mode Toggle Button */}
            <button
              type="button"
              onClick={() => setIsInteractiveEditMode(!isInteractiveEditMode)}
              className={`flex items-center gap-1 px-2 py-1 text-xs font-semibold rounded-md border transition-all cursor-pointer ${
                isInteractiveEditMode
                  ? 'bg-cyan-600 text-white border-cyan-400 shadow-md ring-2 ring-cyan-500/30'
                  : 'bg-slate-800 text-slate-300 hover:text-white border-slate-700 hover:bg-slate-700'
              }`}
              title="Toggle interactive editing of roof planes and edges"
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>{isInteractiveEditMode ? 'Editing' : 'Edit'}</span>
            </button>

            {/* Modal Specs Editor */}
            <button
              onClick={() => setIsEditorOpen(true)}
              className="p-1 text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-md transition-colors cursor-pointer"
              title="Open full-screen modal editor"
            >
              <Edit3 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        <p className="text-xs text-slate-400 line-clamp-1">
          {property.standardizedAddress}
        </p>

        {/* Tab Controls */}
        <div className="flex items-center gap-1 p-0.5 bg-slate-800/80 rounded-md text-[11px] font-medium pt-1 overflow-x-auto">
          <button
            onClick={() => setActiveTab('takeoff')}
            className={`flex-1 py-1 px-1.5 rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeTab === 'takeoff'
                ? 'bg-slate-700 text-white shadow-xs'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Takeoff
          </button>
          <button
            onClick={() => setActiveTab('materials')}
            className={`flex-1 py-1 px-1.5 rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer flex items-center justify-center gap-1 ${
              activeTab === 'materials'
                ? 'bg-cyan-700 text-white shadow-xs font-semibold'
                : 'text-cyan-400 hover:text-cyan-200 bg-cyan-950/40'
            }`}
          >
            <Boxes className="w-3 h-3" />
            <span>Materials</span>
          </button>
          <button
            onClick={() => setActiveTab('planes')}
            className={`flex-1 py-1 px-1.5 rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeTab === 'planes'
                ? 'bg-slate-700 text-white shadow-xs'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Planes ({activeSegments.length})
          </button>
          <button
            onClick={() => setActiveTab('diagnostics')}
            className={`flex-1 py-1 px-1.5 rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer flex items-center justify-center gap-1 ${
              activeTab === 'diagnostics'
                ? 'bg-slate-700 text-white shadow-xs font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Activity className="w-3 h-3 text-cyan-400" />
            <span>Diagnostics</span>
          </button>
          <button
            onClick={() => setActiveTab('validation')}
            className={`flex-1 py-1 px-1.5 rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeTab === 'validation'
                ? 'bg-slate-700 text-white shadow-xs'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            USPS CASS
          </button>
          <button
            onClick={() => setActiveTab('geotiff')}
            className={`flex-1 py-1 px-1.5 rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeTab === 'geotiff'
                ? 'bg-slate-700 text-white shadow-xs'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            GeoTIFF
          </button>
        </div>
      </div>

      {/* Main Scrollable Body */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* INTERACTIVE EDITING MODE BANNER & TOOLBOX */}
        {isInteractiveEditMode && (
          <div className="p-3.5 bg-cyan-950/40 border border-cyan-800/80 rounded-lg space-y-3.5 shadow-sm">
            <div className="flex items-center justify-between border-b border-cyan-800/50 pb-2">
              <div className="flex items-center gap-1.5">
                <Sliders className="w-4 h-4 text-cyan-400" />
                <span className="text-xs font-bold text-white uppercase tracking-wider">
                  Interactive Plane Tuner
                </span>
              </div>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={handleResetInteractiveEdits}
                  className="px-2 py-0.5 text-[10px] text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded border border-slate-700 transition-colors cursor-pointer"
                  title="Reset to initial values"
                >
                  <RotateCcw className="w-2.5 h-2.5 inline mr-1" />
                  Reset
                </button>
                <button
                  type="button"
                  onClick={handleSaveInteractiveEdits}
                  disabled={isSaving}
                  className="flex items-center gap-1 px-2.5 py-0.5 text-[10px] font-semibold text-white bg-cyan-600 hover:bg-cyan-500 rounded shadow-xs transition-colors cursor-pointer"
                >
                  {saveSuccess ? (
                    <>
                      <Check className="w-2.5 h-2.5 text-emerald-300" />
                      <span>Saved!</span>
                    </>
                  ) : (
                    <>
                      <Save className="w-2.5 h-2.5" />
                      <span>{isSaving ? 'Saving...' : 'Save'}</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Plane Selector Chips */}
            <div>
              <span className="text-[10px] text-slate-400 block mb-1.5 font-medium">
                Select Plane to Adjust Dimensions:
              </span>
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                {activeSegments.map((seg, idx) => {
                  const isCur = idx === currentEditIndex;
                  return (
                    <button
                      key={`edit-chip-${idx}`}
                      type="button"
                      onClick={() => onSelectSegment(idx)}
                      className={`px-2.5 py-1 rounded text-xs font-mono font-semibold transition-colors shrink-0 cursor-pointer ${
                        isCur
                          ? 'bg-cyan-500 text-slate-950 shadow-xs ring-1 ring-white'
                          : 'bg-slate-800 text-slate-300 hover:bg-slate-700 border border-slate-700'
                      }`}
                    >
                      Plane #{idx + 1}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Current Plane Controls */}
            {currentPlane && (
              <div className="space-y-3 pt-1">
                <div className="flex items-center justify-between text-xs font-mono bg-slate-900/80 p-2 rounded border border-slate-800">
                  <span className="text-slate-400">Target: Plane #{currentEditIndex + 1}</span>
                  <span className="text-cyan-400 font-bold tabular-nums">
                    {currentPlane.areaSqFt.toLocaleString()} sq ft ({Math.round((currentPlane.areaSqFt / 100) * 10) / 10} sq)
                  </span>
                </div>

                {/* Length & Width Adjustment Sliders & Number Steppers */}
                <div className="grid grid-cols-2 gap-2.5">
                  {/* Length */}
                  <div className="bg-slate-900/60 p-2.5 rounded border border-slate-800 space-y-1.5">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-slate-400">Length (ft)</span>
                      <span className="font-mono text-white font-bold tabular-nums">
                        {currentPlane.estimatedLengthFeet}&apos;
                      </span>
                    </div>
                    <input
                      type="range"
                      min="5"
                      max="120"
                      step="1"
                      value={currentPlane.estimatedLengthFeet}
                      onChange={(e) =>
                        handlePlaneDimensionChange('length', Number(e.target.value))
                      }
                      className="w-full accent-cyan-500 h-1.5 bg-slate-700 rounded-lg cursor-pointer"
                    />
                    <div className="flex items-center justify-between pt-0.5">
                      <button
                        type="button"
                        onClick={() =>
                          handlePlaneDimensionChange(
                            'length',
                            Math.max(1, currentPlane.estimatedLengthFeet - 1)
                          )
                        }
                        className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
                      >
                        <Minus className="w-2.5 h-2.5" />
                      </button>
                      <input
                        type="number"
                        min="1"
                        max="200"
                        value={currentPlane.estimatedLengthFeet}
                        onChange={(e) =>
                          handlePlaneDimensionChange('length', Number(e.target.value))
                        }
                        className="w-14 bg-slate-950 border border-slate-700 rounded px-1 py-0.5 text-center text-xs font-mono text-white"
                      />
                      <button
                        type="button"
                        onClick={() =>
                          handlePlaneDimensionChange(
                            'length',
                            currentPlane.estimatedLengthFeet + 1
                          )
                        }
                        className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
                      >
                        <Plus className="w-2.5 h-2.5" />
                      </button>
                    </div>
                  </div>

                  {/* Width */}
                  <div className="bg-slate-900/60 p-2.5 rounded border border-slate-800 space-y-1.5">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-slate-400">Width (ft)</span>
                      <span className="font-mono text-white font-bold tabular-nums">
                        {currentPlane.estimatedWidthFeet}&apos;
                      </span>
                    </div>
                    <input
                      type="range"
                      min="5"
                      max="120"
                      step="1"
                      value={currentPlane.estimatedWidthFeet}
                      onChange={(e) =>
                        handlePlaneDimensionChange('width', Number(e.target.value))
                      }
                      className="w-full accent-cyan-500 h-1.5 bg-slate-700 rounded-lg cursor-pointer"
                    />
                    <div className="flex items-center justify-between pt-0.5">
                      <button
                        type="button"
                        onClick={() =>
                          handlePlaneDimensionChange(
                            'width',
                            Math.max(1, currentPlane.estimatedWidthFeet - 1)
                          )
                        }
                        className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
                      >
                        <Minus className="w-2.5 h-2.5" />
                      </button>
                      <input
                        type="number"
                        min="1"
                        max="200"
                        value={currentPlane.estimatedWidthFeet}
                        onChange={(e) =>
                          handlePlaneDimensionChange('width', Number(e.target.value))
                        }
                        className="w-14 bg-slate-950 border border-slate-700 rounded px-1 py-0.5 text-center text-xs font-mono text-white"
                      />
                      <button
                        type="button"
                        onClick={() =>
                          handlePlaneDimensionChange(
                            'width',
                            currentPlane.estimatedWidthFeet + 1
                          )
                        }
                        className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
                      >
                        <Plus className="w-2.5 h-2.5" />
                      </button>
                    </div>
                  </div>
                </div>

                {/* Plane Elevation Height */}
                <div className="bg-slate-900/60 p-2.5 rounded border border-slate-800 space-y-1">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-slate-400">Plane Elevation / Height (ft)</span>
                    <span className="font-mono text-white font-bold tabular-nums">
                      {currentPlane.planeHeightFeet} ft
                    </span>
                  </div>
                  <input
                    type="range"
                    min="5"
                    max="60"
                    step="0.5"
                    value={currentPlane.planeHeightFeet}
                    onChange={(e) =>
                      handlePlaneDimensionChange('height', Number(e.target.value))
                    }
                    className="w-full accent-cyan-500 h-1.5 bg-slate-700 rounded-lg cursor-pointer"
                  />
                </div>

                {/* Pitch Ratio Quick Selector */}
                <div className="bg-slate-900/60 p-2.5 rounded border border-slate-800 space-y-1.5">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-slate-400">Roof Slope Pitch</span>
                    <span className="font-mono text-cyan-400 font-bold">
                      {currentPlane.pitchRatio} ({currentPlane.pitchDegrees}&deg;)
                    </span>
                  </div>
                  <div className="grid grid-cols-3 gap-1">
                    {COMMON_PITCH_RATIOS.slice(0, 6).map((p) => (
                      <button
                        key={p.ratio}
                        type="button"
                        onClick={() => handlePlaneDimensionChange('pitch', p.ratio)}
                        className={`py-1 text-[10px] font-mono rounded cursor-pointer transition-colors ${
                          currentPlane.pitchRatio === p.ratio
                            ? 'bg-cyan-600 text-white font-bold'
                            : 'bg-slate-800 text-slate-400 hover:text-white'
                        }`}
                      >
                        {p.ratio}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Azimuth / Aspect Orientation */}
                <div className="bg-slate-900/60 p-2.5 rounded border border-slate-800 space-y-1.5">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-slate-400">Solar Aspect / Compass Azimuth</span>
                    <span className="font-mono text-amber-400 font-bold">
                      {currentPlane.azimuthDirection} ({currentPlane.azimuthDegrees}&deg;)
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="359"
                    step="5"
                    value={currentPlane.azimuthDegrees}
                    onChange={(e) =>
                      handlePlaneDimensionChange('azimuth', Number(e.target.value))
                    }
                    className="w-full accent-amber-500 h-1.5 bg-slate-700 rounded-lg cursor-pointer"
                  />
                </div>
              </div>
            )}
          </div>
        )}

        {/* STRUCTURAL ELEMENTS & MAP OVERLAY VISIBILITY */}
        <div className="p-3.5 bg-slate-800/40 border border-slate-700/60 rounded-lg space-y-2.5">
          <div className="flex items-center justify-between border-b border-slate-700/60 pb-2">
            <div className="flex items-center gap-1.5">
              <Activity className="w-3.5 h-3.5 text-cyan-400" />
              <span className="text-xs font-bold text-slate-200">
                Structural Overlay Visibility
              </span>
            </div>
            <span className="text-[10px] font-mono text-slate-400">
              Live Map Layers
            </span>
          </div>

          <div className="space-y-1.5 text-xs font-mono">
            {/* 1. Ridges */}
            <div className="flex items-center justify-between p-1.5 rounded hover:bg-slate-800/60 transition-colors">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => onToggleStructuralVisibility('ridges')}
                  className={`w-4 h-4 rounded flex items-center justify-center transition-colors cursor-pointer ${
                    structuralVisibility.ridges
                      ? 'bg-red-500 text-white'
                      : 'bg-slate-700 text-slate-500'
                  }`}
                  title="Toggle Ridge Peaks Overlay"
                >
                  {structuralVisibility.ridges ? (
                    <Eye className="w-2.5 h-2.5" />
                  ) : (
                    <EyeOff className="w-2.5 h-2.5" />
                  )}
                </button>
                <span className="w-2.5 h-1 rounded-full bg-red-500 shrink-0"></span>
                <span className="text-slate-300 font-sans">Ridges (Peak Caps):</span>
              </div>
              <div className="flex items-center gap-1">
                {isInteractiveEditMode ? (
                  <>
                    <button
                      type="button"
                      onClick={() =>
                        setWorkingEdges((prev) => ({
                          ...prev,
                          ridges: Math.max(0, prev.ridges - 5),
                        }))
                      }
                      className="w-4 h-4 rounded bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center cursor-pointer"
                    >
                      -
                    </button>
                    <span className="tabular-nums font-semibold text-slate-200">
                      {workingEdges.ridges} ft
                    </span>
                    <button
                      type="button"
                      onClick={() =>
                        setWorkingEdges((prev) => ({
                          ...prev,
                          ridges: prev.ridges + 5,
                        }))
                      }
                      className="w-4 h-4 rounded bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center cursor-pointer"
                    >
                      +
                    </button>
                  </>
                ) : takeoff.linearEdgesAvailable && takeoff.estimatedRidgesFeet != null ? (
                  <span className="tabular-nums font-semibold text-slate-200">
                    {takeoff.estimatedRidgesFeet} ft
                  </span>
                ) : (
                  <span className="text-[10px] text-amber-400 font-sans italic">
                    Not available — requires analysis
                  </span>
                )}
              </div>
            </div>

            {/* 2. Hips */}
            <div className="flex items-center justify-between p-1.5 rounded hover:bg-slate-800/60 transition-colors">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => onToggleStructuralVisibility('hips')}
                  className={`w-4 h-4 rounded flex items-center justify-center transition-colors cursor-pointer ${
                    structuralVisibility.hips
                      ? 'bg-orange-500 text-white'
                      : 'bg-slate-700 text-slate-500'
                  }`}
                  title="Toggle Hip Diagonals Overlay"
                >
                  {structuralVisibility.hips ? (
                    <Eye className="w-2.5 h-2.5" />
                  ) : (
                    <EyeOff className="w-2.5 h-2.5" />
                  )}
                </button>
                <span className="w-2.5 h-1 rounded-full bg-orange-500 shrink-0"></span>
                <span className="text-slate-300 font-sans">Hips (Diagonals):</span>
              </div>
              <div className="flex items-center gap-1">
                {isInteractiveEditMode ? (
                  <>
                    <button
                      type="button"
                      onClick={() =>
                        setWorkingEdges((prev) => ({
                          ...prev,
                          hips: Math.max(0, prev.hips - 5),
                        }))
                      }
                      className="w-4 h-4 rounded bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center cursor-pointer"
                    >
                      -
                    </button>
                    <span className="tabular-nums font-semibold text-slate-200">
                      {workingEdges.hips} ft
                    </span>
                    <button
                      type="button"
                      onClick={() =>
                        setWorkingEdges((prev) => ({
                          ...prev,
                          hips: prev.hips + 5,
                        }))
                      }
                      className="w-4 h-4 rounded bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center cursor-pointer"
                    >
                      +
                    </button>
                  </>
                ) : takeoff.linearEdgesAvailable && takeoff.estimatedHipsFeet != null ? (
                  <span className="tabular-nums font-semibold text-slate-200">
                    {takeoff.estimatedHipsFeet} ft
                  </span>
                ) : (
                  <span className="text-[10px] text-amber-400 font-sans italic">
                    Not available — requires analysis
                  </span>
                )}
              </div>
            </div>

            {/* 3. Valleys */}
            <div className="flex items-center justify-between p-1.5 rounded hover:bg-slate-800/60 transition-colors">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => onToggleStructuralVisibility('valleys')}
                  className={`w-4 h-4 rounded flex items-center justify-center transition-colors cursor-pointer ${
                    structuralVisibility.valleys
                      ? 'bg-cyan-500 text-white'
                      : 'bg-slate-700 text-slate-500'
                  }`}
                  title="Toggle Valley Channels Overlay"
                >
                  {structuralVisibility.valleys ? (
                    <Eye className="w-2.5 h-2.5" />
                  ) : (
                    <EyeOff className="w-2.5 h-2.5" />
                  )}
                </button>
                <span className="w-2.5 h-1 rounded-full bg-cyan-500 shrink-0"></span>
                <span className="text-slate-300 font-sans">Valleys (Drainage):</span>
              </div>
              <div className="flex items-center gap-1">
                {isInteractiveEditMode ? (
                  <>
                    <button
                      type="button"
                      onClick={() =>
                        setWorkingEdges((prev) => ({
                          ...prev,
                          valleys: Math.max(0, prev.valleys - 5),
                        }))
                      }
                      className="w-4 h-4 rounded bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center cursor-pointer"
                    >
                      -
                    </button>
                    <span className="tabular-nums font-semibold text-slate-200">
                      {workingEdges.valleys} ft
                    </span>
                    <button
                      type="button"
                      onClick={() =>
                        setWorkingEdges((prev) => ({
                          ...prev,
                          valleys: prev.valleys + 5,
                        }))
                      }
                      className="w-4 h-4 rounded bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center cursor-pointer"
                    >
                      +
                    </button>
                  </>
                ) : takeoff.linearEdgesAvailable && takeoff.estimatedValleysFeet != null ? (
                  <span className="tabular-nums font-semibold text-slate-200">
                    {takeoff.estimatedValleysFeet} ft
                  </span>
                ) : (
                  <span className="text-[10px] text-amber-400 font-sans italic">
                    Not available — requires analysis
                  </span>
                )}
              </div>
            </div>

            {/* 4. Eaves */}
            <div className="flex items-center justify-between p-1.5 rounded hover:bg-slate-800/60 transition-colors">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => onToggleStructuralVisibility('eaves')}
                  className={`w-4 h-4 rounded flex items-center justify-center transition-colors cursor-pointer ${
                    structuralVisibility.eaves
                      ? 'bg-emerald-500 text-white'
                      : 'bg-slate-700 text-slate-500'
                  }`}
                  title="Toggle Eave Drip Edge Overlay"
                >
                  {structuralVisibility.eaves ? (
                    <Eye className="w-2.5 h-2.5" />
                  ) : (
                    <EyeOff className="w-2.5 h-2.5" />
                  )}
                </button>
                <span className="w-2.5 h-1 rounded-full bg-emerald-500 shrink-0"></span>
                <span className="text-slate-300 font-sans">Eaves (Drip Edge):</span>
              </div>
              <div className="flex items-center gap-1">
                {isInteractiveEditMode ? (
                  <>
                    <button
                      type="button"
                      onClick={() =>
                        setWorkingEdges((prev) => ({
                          ...prev,
                          eaves: Math.max(0, prev.eaves - 5),
                        }))
                      }
                      className="w-4 h-4 rounded bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center cursor-pointer"
                    >
                      -
                    </button>
                    <span className="tabular-nums font-semibold text-slate-200">
                      {workingEdges.eaves} ft
                    </span>
                    <button
                      type="button"
                      onClick={() =>
                        setWorkingEdges((prev) => ({
                          ...prev,
                          eaves: prev.eaves + 5,
                        }))
                      }
                      className="w-4 h-4 rounded bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center cursor-pointer"
                    >
                      +
                    </button>
                  </>
                ) : takeoff.linearEdgesAvailable && takeoff.estimatedEavesFeet != null ? (
                  <span className="tabular-nums font-semibold text-slate-200">
                    {takeoff.estimatedEavesFeet} ft
                  </span>
                ) : (
                  <span className="text-[10px] text-amber-400 font-sans italic">
                    Not available — requires analysis
                  </span>
                )}
              </div>
            </div>

            {/* 5. Rakes */}
            <div className="flex items-center justify-between p-1.5 rounded hover:bg-slate-800/60 transition-colors">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => onToggleStructuralVisibility('rakes')}
                  className={`w-4 h-4 rounded flex items-center justify-center transition-colors cursor-pointer ${
                    structuralVisibility.rakes
                      ? 'bg-purple-500 text-white'
                      : 'bg-slate-700 text-slate-500'
                  }`}
                  title="Toggle Rake Gable Edges Overlay"
                >
                  {structuralVisibility.rakes ? (
                    <Eye className="w-2.5 h-2.5" />
                  ) : (
                    <EyeOff className="w-2.5 h-2.5" />
                  )}
                </button>
                <span className="w-2.5 h-1 rounded-full bg-purple-500 shrink-0"></span>
                <span className="text-slate-300 font-sans">Rakes (Gable Edges):</span>
              </div>
              <div className="flex items-center gap-1">
                {isInteractiveEditMode ? (
                  <>
                    <button
                      type="button"
                      onClick={() =>
                        setWorkingEdges((prev) => ({
                          ...prev,
                          rakes: Math.max(0, prev.rakes - 5),
                        }))
                      }
                      className="w-4 h-4 rounded bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center cursor-pointer"
                    >
                      -
                    </button>
                    <span className="tabular-nums font-semibold text-slate-200">
                      {workingEdges.rakes} ft
                    </span>
                    <button
                      type="button"
                      onClick={() =>
                        setWorkingEdges((prev) => ({
                          ...prev,
                          rakes: prev.rakes + 5,
                        }))
                      }
                      className="w-4 h-4 rounded bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center cursor-pointer"
                    >
                      +
                    </button>
                  </>
                ) : takeoff.linearEdgesAvailable && takeoff.estimatedRakesFeet != null ? (
                  <span className="tabular-nums font-semibold text-slate-200">
                    {takeoff.estimatedRakesFeet} ft
                  </span>
                ) : (
                  <span className="text-[10px] text-amber-400 font-sans italic">
                    Not available — requires analysis
                  </span>
                )}
              </div>
            </div>

            {/* 6. Facet Polygons Toggle */}
            <div className="flex items-center justify-between p-1.5 rounded hover:bg-slate-800/60 transition-colors border-t border-slate-700/40 pt-2">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => onToggleStructuralVisibility('facets')}
                  className={`w-4 h-4 rounded flex items-center justify-center transition-colors cursor-pointer ${
                    structuralVisibility.facets
                      ? 'bg-cyan-600 text-white'
                      : 'bg-slate-700 text-slate-500'
                  }`}
                  title="Toggle Roof Facet Polygons"
                >
                  {structuralVisibility.facets ? (
                    <Eye className="w-2.5 h-2.5" />
                  ) : (
                    <EyeOff className="w-2.5 h-2.5" />
                  )}
                </button>
                <span className="w-2.5 h-2.5 rounded-xs bg-amber-500/70 border border-amber-400 shrink-0"></span>
                <span className="text-slate-300 font-sans">Roof Facets (Planes):</span>
              </div>
              <span className="tabular-nums font-semibold text-cyan-400">
                {activeSegments.length} planes
              </span>
            </div>
          </div>
        </div>

        {/* TAB 1: TAKEOFF METRICS */}
        {activeTab === 'takeoff' && (
          <div className="space-y-4">
            {/* If Solar Geometry is not available from Google Solar API */}
            {!isSolarAvailable && (
              <div className="p-4 bg-amber-950/40 border border-amber-800/80 rounded-lg space-y-2 text-xs">
                <div className="flex items-center gap-2 text-amber-300 font-bold">
                  <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>Solar Geometry Not Available</span>
                </div>
                <p className="text-slate-300 text-[11px] leading-relaxed">
                  Google Solar API does not have 3D building footprint or imagery coverage at this parcel location.
                </p>
                <div className="p-2 bg-slate-900/90 rounded border border-slate-800 text-amber-300 font-mono font-semibold text-[11px]">
                  Status: Not available — requires additional analysis
                </div>
                <p className="text-slate-400 text-[10.5px]">
                  Parcel coordinates and address deliverability have been resolved. Use the <strong>Edit Mode</strong> button above to delineate planes manually.
                </p>
              </div>
            )}

            {/* Primary KPI Grid */}
            <div className="grid grid-cols-2 gap-2.5">
              <div className="p-3 bg-slate-800/60 border border-slate-700/60 rounded-lg">
                <div className="flex items-center justify-between mb-0.5">
                  <span className="text-[11px] text-slate-400 font-medium">Dominant Pitch</span>
                  <span className="text-[9px] font-mono text-emerald-400 bg-emerald-950/60 px-1 rounded border border-emerald-800/40">
                    DIRECT API
                  </span>
                </div>
                <div className="flex items-baseline gap-1.5">
                  <span className="text-xl font-bold font-mono text-cyan-400 tabular-nums">
                    {isSolarAvailable ? takeoff.dominantPitchRatio : 'N/A'}
                  </span>
                  {isSolarAvailable && (
                    <span className="text-xs text-slate-400 font-mono">
                      ({takeoff.dominantPitchDegrees}&deg;)
                    </span>
                  )}
                </div>
                <div className="text-[10px] text-slate-500 mt-1 font-mono">
                  {isSolarAvailable
                    ? `Range: ${takeoff.minPitchDegrees}° - ${takeoff.maxPitchDegrees}°`
                    : 'Requires analysis'}
                </div>
              </div>

              <div className="p-3 bg-slate-800/60 border border-slate-700/60 rounded-lg">
                <div className="flex items-center justify-between mb-0.5">
                  <span className="text-[11px] text-slate-400 font-medium">Dominant Azimuth</span>
                  <span className="text-[9px] font-mono text-emerald-400 bg-emerald-950/60 px-1 rounded border border-emerald-800/40">
                    DIRECT API
                  </span>
                </div>
                <div className="flex items-baseline gap-1.5">
                  <span className="text-xl font-bold font-mono text-amber-400 tabular-nums">
                    {isSolarAvailable ? takeoff.dominantAzimuthDirection : 'N/A'}
                  </span>
                  {isSolarAvailable && (
                    <span className="text-xs text-slate-400 font-mono">
                      {takeoff.dominantAzimuthDegrees}&deg;
                    </span>
                  )}
                </div>
                <div className="text-[10px] text-slate-500 mt-1 font-mono">
                  {isSolarAvailable ? 'Solar Aspect: Optimal plane' : 'Requires analysis'}
                </div>
              </div>

              <div className="p-3 bg-slate-800/60 border border-slate-700/60 rounded-lg">
                <div className="flex items-center justify-between mb-0.5">
                  <span className="text-[11px] text-slate-400 font-medium">Total Surface Area</span>
                  <span className="text-[9px] font-mono text-emerald-400 bg-emerald-950/60 px-1 rounded border border-emerald-800/40">
                    DIRECT API
                  </span>
                </div>
                <div className="text-lg font-bold font-mono text-white tabular-nums">
                  {isSolarAvailable
                    ? `${(isInteractiveEditMode ? liveTotalRoofAreaSqFt : takeoff.totalRoofAreaSqFt).toLocaleString()} sq ft`
                    : 'Not available — requires analysis'}
                </div>
                <div className="text-[10px] text-slate-500 mt-1 font-mono">
                  {isSolarAvailable
                    ? `${isInteractiveEditMode ? liveTotalSquares : takeoff.totalRoofSquares} squares`
                    : 'Requires additional analysis'}
                </div>
              </div>

              <div className="p-3 bg-slate-800/60 border border-slate-700/60 rounded-lg">
                <div className="flex items-center justify-between mb-0.5">
                  <span className="text-[11px] text-slate-400 font-medium">Planar Footprint</span>
                  <span className="text-[9px] font-mono text-amber-400 bg-amber-950/60 px-1 rounded border border-amber-800/40">
                    CALCULATED
                  </span>
                </div>
                <div className="text-lg font-bold font-mono text-white tabular-nums">
                  {isSolarAvailable
                    ? `${takeoff.groundFootprintSqFt.toLocaleString()} sq ft`
                    : 'Not available'}
                </div>
                <div className="text-[10px] text-slate-500 mt-1 font-mono">
                  {isSolarAvailable && takeoff.groundFootprintSqFt > 0
                    ? `Pitch multiplier: ×${(takeoff.totalRoofAreaSqFt / takeoff.groundFootprintSqFt).toFixed(2)}`
                    : 'Requires analysis'}
                </div>
              </div>
            </div>

            {/* Quick Link to Material Calculator */}
            <div className="p-3 bg-cyan-950/30 border border-cyan-800/60 rounded-lg flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-cyan-200 block">
                  Material Takeoff Calculator
                </span>
                <span className="text-[10px] text-slate-400">
                  Calculates bundles, underlayment, drip edge &amp; ridge cap from this area.
                </span>
              </div>
              <button
                type="button"
                onClick={() => setActiveTab('materials')}
                className="px-2.5 py-1 text-xs font-semibold text-white bg-cyan-600 hover:bg-cyan-500 rounded transition-colors cursor-pointer shrink-0"
              >
                View Materials &rarr;
              </button>
            </div>

            {/* Existing Solar System Status Card */}
            {takeoff.existingSolar?.hasExistingSolar ? (
              <div className="p-3.5 bg-amber-950/30 border border-amber-800/60 rounded-lg space-y-2">
                <div className="flex items-center justify-between border-b border-amber-800/40 pb-1.5">
                  <div className="flex items-center gap-1.5">
                    <Sun className="w-3.5 h-3.5 text-amber-400" />
                    <span className="text-xs font-bold text-amber-200">
                      Existing Solar System
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setIsEditorOpen(true)}
                    className="text-[10px] text-amber-300 hover:text-amber-100 underline font-mono cursor-pointer"
                  >
                    Edit Solar
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs font-mono pt-1 text-slate-300">
                  <div>
                    <span className="text-[10px] text-slate-500 block">Existing Panels</span>
                    <span className="font-semibold text-amber-200 tabular-nums">
                      {takeoff.existingSolar.panelCount} panels ({takeoff.existingSolar.capacityKw} kW)
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 block">Inverter Architecture</span>
                    <span className="font-semibold text-slate-200">
                      {takeoff.existingSolar.inverterType}
                    </span>
                  </div>
                  <div className="col-span-2">
                    <span className="text-[10px] text-slate-500 block">Reroof Condition</span>
                    <span className="font-semibold text-amber-300">
                      {takeoff.existingSolar.condition.replace(/_/g, ' ')}
                    </span>
                  </div>
                  {takeoff.existingSolar.notes && (
                    <div className="col-span-2 text-[11px] text-slate-400 italic font-sans pt-1">
                      &ldquo;{takeoff.existingSolar.notes}&rdquo;
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div className="p-3 bg-slate-800/30 border border-dashed border-slate-700/60 rounded-lg flex items-center justify-between text-xs">
                <div className="flex items-center gap-1.5 text-slate-400">
                  <Sun className="w-3.5 h-3.5 text-slate-500" />
                  <span>No existing solar recorded</span>
                </div>
                <button
                  type="button"
                  onClick={() => setIsEditorOpen(true)}
                  className="text-xs text-cyan-400 hover:text-cyan-300 font-semibold cursor-pointer"
                >
                  + Add Existing Solar
                </button>
              </div>
            )}

            {/* Solar Production Potential */}
            {isSolarAvailable && (
              <div className="p-3.5 bg-slate-800/40 border border-slate-700/60 rounded-lg space-y-2">
                <div className="flex items-center justify-between border-b border-slate-700/60 pb-1.5">
                  <div className="flex items-center gap-1.5">
                    <Sun className="w-3.5 h-3.5 text-amber-400" />
                    <span className="text-xs font-bold text-slate-200">
                      Solar Potential (Google Solar API)
                    </span>
                  </div>
                  <span className="text-xs font-mono text-amber-400 font-semibold tabular-nums">
                    {takeoff.maxCapacityKw} kWp
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs font-mono pt-1">
                  <div>
                    <span className="text-[10px] text-slate-500 block">Max Solar Panels</span>
                    <span className="font-semibold text-slate-200 tabular-nums">
                      {takeoff.maxPanelsCount} panels ({takeoff.panelCapacityWatts}W)
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 block">Annual Sunlight</span>
                    <span className="font-semibold text-slate-200 tabular-nums">
                      {takeoff.maxSunshineHoursPerYear} hrs/yr
                    </span>
                  </div>
                  <div className="col-span-2">
                    <span className="text-[10px] text-slate-500 block">Est. Carbon Offset</span>
                    <span className="font-semibold text-emerald-400 tabular-nums">
                      {(takeoff.carbonOffsetKgPerYear / 1000).toFixed(1)} metric tons CO&sup2; / yr
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: ROOFING MATERIAL TAKEOFF CALCULATOR */}
        {activeTab === 'materials' && (
          <div className="space-y-4">
            {/* Material System Selection Bar */}
            <div className="space-y-2">
              <span className="text-xs font-bold text-slate-200 block">
                Select Roofing Material System:
              </span>
              <div className="grid grid-cols-2 gap-2">
                {(
                  [
                    { key: 'shingle', label: 'Asphalt Shingle', sub: '30-Yr Architectural' },
                    { key: 'metal', label: 'Standing Seam', sub: '24ga Steel 16"' },
                    { key: 'tile', label: 'Spanish Tile', sub: 'Clay/Concrete "S"' },
                    { key: 'tpo', label: 'Commercial TPO', sub: '60-mil Single-Ply' },
                  ] as const
                ).map((mat) => {
                  const isSelected = selectedMaterial === mat.key;
                  return (
                    <button
                      key={mat.key}
                      type="button"
                      onClick={() => setSelectedMaterial(mat.key)}
                      className={`p-2.5 rounded-lg border text-left transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-cyan-950/70 border-cyan-400 ring-1 ring-cyan-500/50 shadow-xs'
                          : 'bg-slate-800/40 hover:bg-slate-800/80 border-slate-700/60'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-0.5">
                        <span
                          className={`text-xs font-bold ${
                            isSelected ? 'text-white' : 'text-slate-300'
                          }`}
                        >
                          {mat.label}
                        </span>
                        {isSelected && (
                          <span className="w-2 h-2 rounded-full bg-cyan-400"></span>
                        )}
                      </div>
                      <span className="text-[10px] text-slate-400 font-mono block">
                        {mat.sub}
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* Selected Profile Specification Note */}
              <div className="p-2.5 bg-slate-800/40 border border-slate-700/60 rounded-md text-[11px] text-slate-300 space-y-1">
                <div className="flex items-center justify-between text-slate-400 font-mono text-[10px]">
                  <span>Specification: {MATERIAL_PROFILES[selectedMaterial].warranty}</span>
                  <span>Ideal: {MATERIAL_PROFILES[selectedMaterial].idealSlope}</span>
                </div>
                <p className="text-slate-400 text-[10.5px]">
                  {MATERIAL_PROFILES[selectedMaterial].description}
                </p>
              </div>
            </div>

            {/* Waste Factor Allowance Selector */}
            <div className="p-3 bg-slate-800/40 border border-slate-700/60 rounded-lg space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <Percent className="w-3.5 h-3.5 text-cyan-400" />
                  <span className="text-xs font-bold text-slate-200">
                    Waste Factor Allowance
                  </span>
                </div>
                <span className="text-xs font-mono font-semibold text-cyan-400">
                  {wasteFactor}% Waste Added
                </span>
              </div>

              <div className="flex items-center gap-1.5 pt-0.5">
                {[
                  { val: 5, label: '5% (Simple)' },
                  { val: 10, label: '10% (Std)' },
                  { val: 12, label: '12% (Hips)' },
                  { val: 15, label: '15% (Valleys)' },
                  { val: 20, label: '20% (Complex)' },
                ].map((wf) => (
                  <button
                    key={wf.val}
                    type="button"
                    onClick={() => setWasteFactor(wf.val)}
                    className={`flex-1 py-1 text-[10px] font-mono font-semibold rounded cursor-pointer transition-colors ${
                      wasteFactor === wf.val
                        ? 'bg-cyan-600 text-white shadow-xs'
                        : 'bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    {wf.label}
                  </button>
                ))}
              </div>
              <p className="text-[10px] text-slate-500 font-mono">
                Cut waste accounts for diagonal hip ridges, valleys, and rakes.
              </p>
            </div>

            {/* Material Takeoff Cost & Squares KPI Grid */}
            <div className="grid grid-cols-3 gap-2">
              <div className="p-2.5 bg-slate-800/60 border border-slate-700/60 rounded-lg">
                <span className="text-[10px] text-slate-400 block mb-0.5 font-medium">
                  Gross Squares
                </span>
                <span className="text-base font-bold font-mono text-cyan-400 tabular-nums">
                  {materialTakeoff.grossSquares} sq
                </span>
                <span className="text-[10px] text-slate-500 font-mono block">
                  Net: {materialTakeoff.netSquares} sq
                </span>
              </div>

              <div className="p-2.5 bg-slate-800/60 border border-slate-700/60 rounded-lg">
                <span className="text-[10px] text-slate-400 block mb-0.5 font-medium">
                  Est. Total Cost
                </span>
                <span className="text-base font-bold font-mono text-emerald-400 tabular-nums">
                  ${materialTakeoff.totalMaterialCost.toLocaleString()}
                </span>
                <span className="text-[10px] text-slate-500 font-mono block">
                  Material only
                </span>
              </div>

              <div className="p-2.5 bg-slate-800/60 border border-slate-700/60 rounded-lg">
                <span className="text-[10px] text-slate-400 block mb-0.5 font-medium">
                  Cost / Square
                </span>
                <span className="text-base font-bold font-mono text-white tabular-nums">
                  ${materialTakeoff.costPerSquare}
                </span>
                <span className="text-[10px] text-slate-500 font-mono block">
                  per 100 sq ft
                </span>
              </div>
            </div>

            {/* Bill of Materials (BOM) Itemized List */}
            <div className="space-y-2">
              <div className="flex items-center justify-between border-b border-slate-700/60 pb-1.5">
                <div className="flex items-center gap-1.5">
                  <Package className="w-3.5 h-3.5 text-cyan-400" />
                  <span className="text-xs font-bold text-white">
                    Itemized Bill of Materials (BOM)
                  </span>
                </div>
                <button
                  type="button"
                  onClick={handleExportMaterialBomCsv}
                  className="flex items-center gap-1 text-[11px] font-semibold text-emerald-400 hover:text-emerald-300 transition-colors cursor-pointer"
                >
                  <FileSpreadsheet className="w-3 h-3" />
                  <span>Export Quote CSV</span>
                </button>
              </div>

              <div className="space-y-2">
                {materialTakeoff.items.map((item) => (
                  <div
                    key={item.id}
                    className="p-2.5 bg-slate-800/40 border border-slate-700/60 rounded-lg space-y-1.5 text-xs hover:border-slate-600 transition-colors"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="font-semibold text-slate-200">
                          {item.name}
                        </div>
                        <div className="text-[10px] text-slate-400 font-mono">
                          {item.specification}
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <span className="text-sm font-bold font-mono text-cyan-400 tabular-nums">
                          {item.quantity.toLocaleString()} {item.unit}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-1 border-t border-slate-700/40 text-[10.5px] font-mono">
                      <span className="text-slate-500 truncate max-w-[200px]">
                        {item.coverageFormula}
                      </span>
                      <div className="flex items-center gap-1.5 shrink-0">
                        {editingCostItemId === item.id ? (
                          <div className="flex items-center gap-1">
                            <span className="text-slate-400">$</span>
                            <input
                              type="number"
                              step="0.5"
                              defaultValue={item.unitCost}
                              autoFocus
                              onBlur={(e) => {
                                const val = parseFloat(e.target.value);
                                if (!isNaN(val) && val >= 0) {
                                  setCustomUnitCosts((prev) => ({
                                    ...prev,
                                    [item.id]: val,
                                  }));
                                }
                                setEditingCostItemId(null);
                              }}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                  e.currentTarget.blur();
                                }
                              }}
                              className="w-14 bg-slate-950 border border-cyan-500 rounded px-1 py-0.5 text-right text-xs text-white"
                            />
                          </div>
                        ) : (
                          <button
                            type="button"
                            onClick={() => setEditingCostItemId(item.id)}
                            className="text-slate-400 hover:text-cyan-300 underline cursor-pointer"
                            title="Click to edit unit cost"
                          >
                            ${item.unitCost.toFixed(2)} / {item.unit.split(' ')[0]}
                          </button>
                        )}
                        <span className="text-slate-600">&middot;</span>
                        <span className="font-semibold text-emerald-400">
                          ${Math.round(item.totalCost).toLocaleString()}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Export Button */}
            <button
              type="button"
              onClick={handleExportMaterialBomCsv}
              className="w-full flex items-center justify-center gap-2 py-2 px-3 text-xs font-semibold text-slate-100 bg-slate-800 hover:bg-slate-700 border border-slate-700 hover:border-slate-600 rounded-lg transition-colors cursor-pointer shadow-xs"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
              <span>Download {materialTakeoff.materialName} BOM (CSV)</span>
            </button>
          </div>
        )}

        {/* TAB 3: ROOF PLANES LIST & INSPECTION */}
        {activeTab === 'planes' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>Select plane to inspect or tune:</span>
              <div className="flex items-center gap-2">
                <span className="font-mono text-cyan-400 font-semibold">
                  {activeSegments.length} planes identified
                </span>
              </div>
            </div>

            {activeSegments.length === 0 ? (
              <div className="p-6 bg-slate-800/40 border border-slate-700/60 rounded-lg text-center text-xs text-slate-400">
                <p className="font-semibold text-slate-300">No Roof Planes Available</p>
                <p className="text-[11px] text-slate-500 mt-1">
                  Google Solar API has no building footprint for this location. Toggle <strong>Edit Mode</strong> to delineate planes manually.
                </p>
              </div>
            ) : (
              <div className="space-y-2">
                {activeSegments.map((seg, idx) => {
                  const isSelected = selectedSegmentIndex === idx;
                  return (
                    <div
                      key={`seg-card-${idx}`}
                      onClick={() => onSelectSegment(isSelected ? null : idx)}
                      className={`p-3 rounded-lg border cursor-pointer transition-all ${
                        isSelected
                          ? 'bg-slate-800 border-cyan-400 shadow-sm ring-1 ring-cyan-500/30'
                          : 'bg-slate-800/40 hover:bg-slate-800/70 border-slate-700/60'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span
                            className={`w-5 h-5 rounded flex items-center justify-center text-[10px] font-mono font-bold ${
                              isSelected
                                ? 'bg-cyan-500 text-slate-950'
                                : 'bg-slate-700 text-slate-300'
                            }`}
                          >
                            #{idx + 1}
                          </span>
                          <span className="text-xs font-semibold text-slate-200">
                            {seg.pitchRatio} Pitch ({seg.pitchDegrees}&deg;)
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-mono font-semibold text-amber-400 tabular-nums">
                            {seg.azimuthDirection} ({seg.azimuthDegrees}&deg;)
                          </span>
                          {!isInteractiveEditMode && (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                onSelectSegment(idx);
                                setIsInteractiveEditMode(true);
                              }}
                              className="p-1 rounded bg-slate-700 hover:bg-cyan-600 text-slate-300 hover:text-white transition-colors"
                              title="Fine-tune dimensions for this plane"
                            >
                              <Sliders className="w-3 h-3" />
                            </button>
                          )}
                        </div>
                      </div>

                      <div className="grid grid-cols-3 gap-2 mt-2 pt-2 border-t border-slate-700/40 text-[11px] font-mono text-slate-400">
                        <div>
                          <span className="text-[10px] text-slate-500 block">Area</span>
                          <span className="text-slate-200 font-semibold tabular-nums">
                            {seg.areaSqFt} sq ft
                          </span>
                        </div>
                        <div>
                          <span className="text-[10px] text-slate-500 block">Dimensions</span>
                          <span className="text-slate-200 tabular-nums">
                            {seg.estimatedLengthFeet}&apos; &times; {seg.estimatedWidthFeet}&apos;
                          </span>
                        </div>
                        <div>
                          <span className="text-[10px] text-slate-500 block">Height</span>
                          <span className="text-slate-200 tabular-nums">
                            {seg.planeHeightFeet} ft
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* TAB 4: API DIAGNOSTICS & PROVENANCE (PRIORITY 5) */}
        {activeTab === 'diagnostics' && (
          <div className="space-y-4">
            <div className="p-3.5 bg-slate-800/60 border border-slate-700/60 rounded-lg space-y-3">
              <div className="flex items-center justify-between border-b border-slate-700/60 pb-2">
                <div className="flex items-center gap-1.5">
                  <Activity className="w-4 h-4 text-cyan-400" />
                  <span className="text-xs font-bold text-white">
                    API Status &amp; Provenance
                  </span>
                </div>
                {onOpenDiagnostics && (
                  <button
                    type="button"
                    onClick={onOpenDiagnostics}
                    className="text-[11px] text-cyan-400 hover:text-cyan-300 font-semibold cursor-pointer underline"
                  >
                    Open Full Inspector
                  </button>
                )}
              </div>

              <div className="space-y-2 text-xs font-mono">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">GCP Project:</span>
                  <span className="text-slate-200 font-semibold">gmp-demo-project-576437582</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Solar API Status:</span>
                  <span
                    className={`font-semibold ${
                      property.solarDataAvailable ? 'text-emerald-400' : 'text-amber-400'
                    }`}
                  >
                    {property.solarCoverageStatus || (property.solarDataAvailable ? 'AVAILABLE' : 'NOT_AVAILABLE')}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Geocoding:</span>
                  <span className="text-emerald-400 font-semibold">SUCCESS (ROOFTOP)</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Google Place ID:</span>
                  <span className="text-cyan-400 truncate max-w-[180px]">{property.googlePlaceId}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Linear Edge Delineation:</span>
                  <span className="text-slate-300">
                    {takeoff.linearEdgesAvailable ? 'CAD Delineated' : 'Not available — requires analysis'}
                  </span>
                </div>
              </div>
            </div>

            {/* Event log snippet */}
            <div className="p-3 bg-slate-900 border border-slate-800 rounded-lg space-y-1.5 font-mono text-[10.5px]">
              <span className="text-slate-400 font-bold block mb-1">Recent Diagnostic Log:</span>
              {property.diagnostics && property.diagnostics.length > 0 ? (
                property.diagnostics.slice(-3).map((d, i) => (
                  <div key={i} className="text-slate-400">
                    <span className="text-slate-600">[{new Date(d.timestamp).toLocaleTimeString()}]</span>{' '}
                    <span className="text-cyan-400 font-semibold">[{d.service}]</span>{' '}
                    <span>{d.message}</span>
                  </div>
                ))
              ) : (
                <div className="text-slate-500">Pipeline intake initialized.</div>
              )}
            </div>
          </div>
        )}

        {/* TAB 5: ADDRESS VALIDATION PRO & USPS CASS */}
        {activeTab === 'validation' && (
          <div className="space-y-4">
            <div className="p-3.5 bg-slate-800/60 border border-slate-700/60 rounded-lg space-y-3">
              <div className="flex items-center justify-between border-b border-slate-700/60 pb-2">
                <div className="flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span className="text-xs font-bold text-white">
                    USPS CASS &amp; DPV Standardization
                  </span>
                </div>
                <span className="text-[10px] font-mono text-emerald-400">
                  Deliverable
                </span>
              </div>

              <div className="space-y-2 text-xs font-mono">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Validation Granularity:</span>
                  <span className="text-cyan-400 font-semibold">
                    {verdict.validationGranularity || 'PREMISE'}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Geocode Precision:</span>
                  <span className="text-slate-200">
                    {verdict.geocodeGranularity || 'ROOFTOP'}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Premise Classification:</span>
                  <span className="text-slate-200">
                    {verdict.isResidential
                      ? 'Residential Premise'
                      : verdict.isBusiness
                      ? 'Commercial Premise'
                      : 'Standard Premise'}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">USPS DPV Confirmation:</span>
                  <span className="text-emerald-400 font-semibold">
                    Code {verdict.dpvConfirmation || 'Y'} (Confirmed)
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">USPS Carrier Route:</span>
                  <span className="text-slate-200">
                    {verdict.carrierRoute || 'C012'}
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 6: GEOTIFF LAYERS (TIER 3 EPHEMERAL) */}
        {activeTab === 'geotiff' && (
          <div className="space-y-4">
            <div className="p-3 bg-cyan-950/30 border border-cyan-800/60 rounded-lg text-xs space-y-1">
              <div className="flex items-center gap-1.5 font-bold text-cyan-300">
                <Database className="w-3.5 h-3.5" />
                <span>Tier 3 Ephemeral Compliance</span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Raw GeoTIFF raster links from Google Solar API are displayed with 0-day retention.
              </p>
            </div>

            <div className="space-y-2 text-xs">
              <div className="p-3 bg-slate-800/50 border border-slate-700/60 rounded-lg flex items-center justify-between">
                <div>
                  <div className="font-semibold text-slate-200">
                    DSM (Digital Surface Model)
                  </div>
                  <div className="text-[11px] text-slate-400 font-mono">
                    Topographical 3D elevation layer
                  </div>
                </div>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-cyan-950 text-cyan-400 border border-cyan-800/60">
                  {dataLayers.dsmUrl ? 'Available' : 'Processed'}
                </span>
              </div>

              <div className="p-3 bg-slate-800/50 border border-slate-700/60 rounded-lg flex items-center justify-between">
                <div>
                  <div className="font-semibold text-slate-200">
                    RGB Aerial Imagery
                  </div>
                  <div className="text-[11px] text-slate-400 font-mono">
                    High-res optical orthomosaic
                  </div>
                </div>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-cyan-950 text-cyan-400 border border-cyan-800/60">
                  {dataLayers.rgbUrl ? 'Available' : 'Processed'}
                </span>
              </div>

              <div className="p-3 bg-slate-800/50 border border-slate-700/60 rounded-lg flex items-center justify-between">
                <div>
                  <div className="font-semibold text-slate-200">
                    Rooftop Boundary Mask
                  </div>
                  <div className="text-[11px] text-slate-400 font-mono">
                    Building perimeter polygon mask
                  </div>
                </div>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-cyan-950 text-cyan-400 border border-cyan-800/60">
                  {dataLayers.maskUrl ? 'Available' : 'Active'}
                </span>
              </div>

              <div className="p-3 bg-slate-800/50 border border-slate-700/60 rounded-lg flex items-center justify-between">
                <div>
                  <div className="font-semibold text-slate-200">
                    Annual Solar Flux Map
                  </div>
                  <div className="text-[11px] text-slate-400 font-mono">
                    kWh/m&sup2;/year irradiance distribution
                  </div>
                </div>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-cyan-950 text-cyan-400 border border-cyan-800/60">
                  {dataLayers.annualFluxUrl ? 'Available' : 'Active'}
                </span>
              </div>

              <div className="p-3 bg-slate-800/50 border border-slate-700/60 rounded-lg flex items-center justify-between">
                <div>
                  <div className="font-semibold text-slate-200">
                    Hourly Shadow Simulations
                  </div>
                  <div className="text-[11px] text-slate-400 font-mono">
                    12-month solar trajectory shades
                  </div>
                </div>
                <span className="text-[11px] font-mono text-slate-300">
                  {dataLayers.hourlyShadeUrlsCount || 12} rasters
                </span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Panel Footer Actions */}
      <div className="p-4 border-t border-slate-800 space-y-2 bg-slate-900/90 shrink-0">
        <div className="flex items-center gap-2">
          {property.status !== 'PROPOSAL_GENERATED' ? (
            <button
              onClick={() => onUpdateStatus('PROPOSAL_GENERATED')}
              className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-semibold text-white bg-cyan-600 hover:bg-cyan-500 rounded-lg transition-colors cursor-pointer"
            >
              <span>Promote to Proposal</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          ) : (
            <div className="flex-1 py-1.5 text-center text-xs font-semibold text-emerald-400 bg-emerald-950/40 border border-emerald-800/60 rounded-lg">
              Proposal Ready (Phase 1 Complete)
            </div>
          )}

          <button
            onClick={handleExportCsv}
            className="flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-100 hover:text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 hover:border-slate-600 rounded-lg transition-colors cursor-pointer whitespace-nowrap shadow-xs"
            title="Download roof geometry, takeoff metrics & material BOM as CSV"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span>Download CSV</span>
          </button>

          <button
            onClick={handleExportJson}
            title="Export JSON Takeoff & Material BOM Report"
            className="flex items-center justify-center p-2 text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4" />
          </button>
        </div>

        <div className="text-[10px] text-slate-500 flex items-center justify-between pt-1 font-mono">
          <span>Tenant: {property.tenantId}</span>
          <span>Updated: {new Date(property.updatedAt).toLocaleTimeString()}</span>
        </div>
      </div>

      {/* Takeoff Geometry & Existing Solar Editor Modal */}
      {property && (
        <TakeoffEditorModal
          isOpen={isEditorOpen}
          onClose={() => setIsEditorOpen(false)}
          property={property}
          onSave={(updated) => {
            if (onPropertyUpdated) {
              onPropertyUpdated(updated);
            }
          }}
        />
      )}
    </div>
  );
};
