import React, { useState } from 'react';
import { Search, MapPin, Compass, Layers, CheckCircle2, Clock, AlertTriangle } from 'lucide-react';
import { PropertyRecord } from '../types/pipeline.js';

interface PipelineSidebarProps {
  properties: PropertyRecord[];
  selectedPropertyId: string | null;
  onSelectProperty: (property: PropertyRecord) => void;
  onOpenIntakeModal: () => void;
}

export const PipelineSidebar: React.FC<PipelineSidebarProps> = ({
  properties,
  selectedPropertyId,
  onSelectProperty,
  onOpenIntakeModal,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'VERIFIED' | 'INTAKE'>('ALL');

  const filteredProperties = properties.filter((p) => {
    const matchesSearch =
      p.inputAddress.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.standardizedAddress.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.tenantName.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;

    if (statusFilter === 'VERIFIED') {
      return p.status === 'TAKEOFF_VERIFIED' || p.status === 'PROPOSAL_GENERATED';
    }
    if (statusFilter === 'INTAKE') {
      return p.status === 'INTAKE_VALIDATED' || p.status === 'ROOF_GEOMETRY_EXTRACTED';
    }
    return true;
  });

  return (
    <aside className="w-80 md:w-96 flex flex-col bg-slate-900 border-r border-slate-800 shrink-0 h-full overflow-hidden">
      {/* Sidebar Header & Search */}
      <div className="p-4 border-b border-slate-800 space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
            Pipeline Properties ({filteredProperties.length})
          </h2>
          <span className="text-[11px] font-mono text-cyan-400">
            Phase 1 Intake
          </span>
        </div>

        {/* Search input */}
        <div className="relative">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search address or tenant..."
            className="w-full bg-slate-800/80 border border-slate-700/80 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
          />
          <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-2 pointer-events-none" />
        </div>

        {/* Filter Segmented Controls */}
        <div className="flex items-center gap-1 p-0.5 bg-slate-800 rounded-md">
          <button
            onClick={() => setStatusFilter('ALL')}
            className={`flex-1 py-1 text-[11px] font-medium rounded transition-colors whitespace-nowrap shrink-0 ${
              statusFilter === 'ALL'
                ? 'bg-slate-700 text-white shadow-xs'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            All ({properties.length})
          </button>
          <button
            onClick={() => setStatusFilter('VERIFIED')}
            className={`flex-1 py-1 text-[11px] font-medium rounded transition-colors whitespace-nowrap shrink-0 ${
              statusFilter === 'VERIFIED'
                ? 'bg-slate-700 text-white shadow-xs'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Takeoff Verified
          </button>
          <button
            onClick={() => setStatusFilter('INTAKE')}
            className={`flex-1 py-1 text-[11px] font-medium rounded transition-colors whitespace-nowrap shrink-0 ${
              statusFilter === 'INTAKE'
                ? 'bg-slate-700 text-white shadow-xs'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Intake
          </button>
        </div>
      </div>

      {/* Properties List */}
      <div className="flex-1 overflow-y-auto divide-y divide-slate-800/60 p-2 space-y-1">
        {filteredProperties.length === 0 ? (
          <div className="py-12 px-4 text-center">
            <MapPin className="w-8 h-8 text-slate-600 mx-auto mb-2" />
            <p className="text-xs font-medium text-slate-400">No properties found</p>
            <p className="text-[11px] text-slate-500 mt-1 max-w-xs mx-auto">
              No parcel records match your filter. Intake a street address to extract roof geometry.
            </p>
            <button
              onClick={onOpenIntakeModal}
              className="mt-4 px-3 py-1.5 text-xs font-semibold text-cyan-300 bg-cyan-950/60 hover:bg-cyan-900/60 border border-cyan-800/60 rounded-md transition-colors"
            >
              Intake New Property
            </button>
          </div>
        ) : (
          filteredProperties.map((property) => {
            const isSelected = property.id === selectedPropertyId;
            const squares = property.takeoff?.totalRoofSquares ?? 0;
            const pitchRatio = property.takeoff?.dominantPitchRatio ?? '0:12';
            const segmentsCount = property.segments?.length ?? 0;
            const isCoordinatesExpired = property.coordinates.isExpired;

            return (
              <div
                key={property.id}
                onClick={() => onSelectProperty(property)}
                className={`p-3 rounded-lg cursor-pointer transition-all ${
                  isSelected
                    ? 'bg-slate-800/95 border border-cyan-500/50 shadow-md'
                    : 'bg-slate-900/60 hover:bg-slate-800/60 border border-transparent'
                }`}
              >
                {/* Clean 1-line Header without Pill Badges */}
                <div className="flex items-start justify-between gap-2">
                  <h3 className="text-xs font-semibold text-slate-100 line-clamp-1 leading-snug">
                    {property.inputAddress}
                  </h3>
                  <span className="text-[10px] font-mono text-cyan-400 shrink-0 tabular-nums">
                    {squares.toLocaleString()} sq
                  </span>
                </div>

                {/* Standardized USPS Premise */}
                <p className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">
                  {property.standardizedAddress}
                </p>

                {/* Metadata Line */}
                <div className="flex items-center flex-wrap gap-x-2 gap-y-1 text-[11px] text-slate-400 mt-2 font-mono tabular-nums">
                  {property.solarDataAvailable === false ? (
                    <span className="text-amber-400">Solar geometry not available — requires analysis</span>
                  ) : (
                    <>
                      <span className="text-slate-300 font-semibold">{pitchRatio} pitch</span>
                      <span aria-hidden="true" className="text-slate-600">&middot;</span>
                      <span>{segmentsCount} planes</span>
                      <span aria-hidden="true" className="text-slate-600">&middot;</span>
                      <span>{property.takeoff?.dominantAzimuthDirection || 'N/A'}</span>
                      <span aria-hidden="true" className="text-slate-600">&middot;</span>
                      <span className="text-slate-400">{(property.takeoff?.totalRoofAreaSqFt || 0).toLocaleString()} sq ft</span>
                    </>
                  )}
                </div>

                {/* Anti-Caching & Status Verification Line */}
                <div className="flex items-center justify-between text-[10px] text-slate-500 mt-2 pt-2 border-t border-slate-800/50">
                  <span className="text-slate-400 truncate max-w-[150px]">
                    {property.tenantName}
                  </span>
                  
                  {property.isDemoMode || property.status === 'DEMO_SAMPLE' ? (
                    <span className="text-amber-300 font-bold px-1.5 py-0.5 rounded bg-amber-950/60 border border-amber-800/60 text-[9px] uppercase tracking-wider">
                      DEMO MODE
                    </span>
                  ) : isCoordinatesExpired ? (
                    <span className="text-amber-400 flex items-center gap-1">
                      <AlertTriangle className="w-3 h-3" />
                      30d TTL Expired
                    </span>
                  ) : property.solarDataAvailable === false ? (
                    <span className="text-amber-400 flex items-center gap-1">
                      <AlertTriangle className="w-3 h-3" />
                      Needs Analysis
                    </span>
                  ) : property.status === 'TAKEOFF_VERIFIED' ? (
                    <span className="text-emerald-400 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" />
                      Takeoff Verified
                    </span>
                  ) : (
                    <span className="text-cyan-400 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" />
                      Solar Extracted
                    </span>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>
    </aside>
  );
};
