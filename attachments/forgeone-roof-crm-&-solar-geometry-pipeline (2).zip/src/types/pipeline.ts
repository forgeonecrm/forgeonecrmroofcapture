export type PipelineStatus = 
  | 'INTAKE_VALIDATED'
  | 'PARCEL_GEOCODED'
  | 'ROOF_GEOMETRY_EXTRACTED'
  | 'TAKEOFF_VERIFIED'
  | 'PROPOSAL_GENERATED'
  | 'NEEDS_ANALYSIS'
  | 'DEMO_SAMPLE';

export type SolarCoverageStatus =
  | 'AVAILABLE'
  | 'NO_COVERAGE_404'
  | 'SERVICE_DISABLED_403'
  | 'RATE_LIMITED_429'
  | 'NOT_AVAILABLE'
  | 'UNRESOLVED';

export type MeasurementSource =
  | 'DIRECT_SOLAR_API'
  | 'CALCULATED_GEOMETRY'
  | 'UNAVAILABLE'
  | 'MANUAL_EDIT';

export interface RoofSegment {
  segmentIndex: number;
  pitchDegrees: number;
  pitchRatio: string;
  azimuthDegrees: number;
  azimuthDirection: string;
  areaMeters2: number;
  areaSqFt: number;
  groundAreaMeters2: number;
  groundAreaSqFt: number;
  planeHeightMeters: number;
  planeHeightFeet: number;
  center: {
    latitude: number;
    longitude: number;
  };
  boundingBox: {
    sw: { latitude: number; longitude: number };
    ne: { latitude: number; longitude: number };
  };
  polygonPath?: { lat: number; lng: number }[];
  estimatedLengthFeet: number;
  estimatedWidthFeet: number;
  source?: MeasurementSource;
  // Existing solar on this facet
  hasExistingPanels?: boolean;
  existingPanelCount?: number;
  name?: string;
}

export interface ExistingSolarSystem {
  hasExistingSolar: boolean;
  panelCount: number;
  capacityKw: number;
  installedYear?: number;
  condition: 'GOOD' | 'FAIR' | 'NEEDS_REROOF_DETACH_RESET' | 'OBSOLETE_DECOMMISSION';
  inverterType: 'STRING' | 'MICROINVERTER' | 'OPTIMIZER' | 'UNKNOWN';
  notes?: string;
}

export interface TakeoffSummary {
  totalRoofAreaMeters2: number;
  totalRoofAreaSqFt: number;
  totalRoofSquares: number;
  groundFootprintSqFt: number;
  dominantPitchDegrees: number;
  dominantPitchRatio: string;
  minPitchDegrees: number;
  maxPitchDegrees: number;
  weightedPitchDegrees: number;
  dominantAzimuthDegrees: number;
  dominantAzimuthDirection: string;
  totalSegments: number;
  linearEdgesAvailable?: boolean;
  estimatedEavesFeet?: number | null;
  estimatedRidgesFeet?: number | null;
  estimatedHipsFeet?: number | null;
  estimatedValleysFeet?: number | null;
  estimatedRakesFeet?: number | null;
  estimatedTotalLinearEdgeFeet?: number | null;
  maxPanelsCount: number;
  panelCapacityWatts: number;
  maxCapacityKw: number;
  maxSunshineHoursPerYear: number;
  carbonOffsetKgPerYear: number;
  dataProvenance?: Record<string, MeasurementSource>;
  // Existing solar
  existingSolar?: ExistingSolarSystem;
}

export interface AddressValidationVerdict {
  inputGranularity?: string;
  validationGranularity?: string;
  geocodeGranularity?: string;
  addressComplete?: boolean;
  hasUnconfirmedComponents?: boolean;
  hasInferredComponents?: boolean;
  hasReplacedComponents?: boolean;
  uspsCassProcessed?: boolean;
  dpvConfirmation?: string;
  carrierRoute?: string;
  isResidential?: boolean;
  isBusiness?: boolean;
}

export interface GeoTIFFLayers {
  imageryDate?: { year: number; month: number; day: number };
  imageryQuality?: string;
  dsmUrl?: string;
  rgbUrl?: string;
  maskUrl?: string;
  annualFluxUrl?: string;
  monthlyFluxUrl?: string;
  hourlyShadeUrlsCount?: number;
}

export interface DiagnosticLog {
  timestamp: string;
  service: 'ADDRESS_VALIDATION' | 'GEOCODING' | 'SOLAR_API' | 'DATA_LAYERS';
  status: 'SUCCESS' | 'WARNING' | 'ERROR' | 'INFO';
  statusCode?: number;
  message: string;
  details?: string;
}

export interface PropertyRecord {
  id: string;
  tenantId: string;
  tenantName: string;
  inputAddress: string;
  standardizedAddress: string;
  googlePlaceId: string;
  isDemoMode?: boolean;
  solarDataAvailable: boolean;
  solarCoverageStatus: SolarCoverageStatus;
  solarErrorMessage?: string;
  geocodingStatus?: 'SUCCESS' | 'SIMULATED' | 'FAILED';
  diagnostics?: DiagnosticLog[];
  coordinates: {
    latitude: number;
    longitude: number;
    cachedAt: string;
    expiresAt: string;
    isExpired: boolean;
  };
  bounds?: {
    sw: { latitude: number; longitude: number };
    ne: { latitude: number; longitude: number };
  };
  status: PipelineStatus;
  verdict: AddressValidationVerdict;
  takeoff: TakeoffSummary;
  segments: RoofSegment[];
  customEdges?: StructuralLine[];
  dataLayers: GeoTIFFLayers;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface TenantInfo {
  id: string;
  name: string;
  slug: string;
  region: string;
  primaryContact: string;
}

export interface StructuralVisibility {
  facets: boolean;
  ridges: boolean;
  hips: boolean;
  valleys: boolean;
  eaves: boolean;
  rakes: boolean;
  markers: boolean;
}

export interface StructuralLine {
  id: string;
  type: 'ridge' | 'hip' | 'valley' | 'eave' | 'rake' | 'flashing';
  name: string;
  segmentIndex?: number;
  path: { lat: number; lng: number }[];
  lengthFeet: number;
}

