import React from 'react';

declare global {
  namespace JSX {
    interface IntrinsicElements {
      'gmp-basic-place-autocomplete': React.DetailedHTMLProps<
        React.HTMLAttributes<HTMLElement>,
        HTMLElement
      > & {
        ref?: any;
        className?: string;
      };
      'gmp-map-3d': React.DetailedHTMLProps<
        React.HTMLAttributes<HTMLElement>,
        HTMLElement
      > & {
        ref?: any;
        center?: any;
        range?: number;
        heading?: number;
        tilt?: number;
        roll?: number;
        mode?: string;
      };
    }
  }
}
