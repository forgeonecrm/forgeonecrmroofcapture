/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { APIProvider } from '@vis.gl/react-google-maps';
import { Header } from './components/Header.js';
import { PipelineSidebar } from './components/PipelineSidebar.js';
import { RoofGeometryMap } from './components/RoofGeometryMap.js';
import { MeasurementSummaryPanel } from './components/MeasurementSummaryPanel.js';
import { AddressIntakeModal } from './components/AddressIntakeModal.js';
import { ComplianceModal } from './components/ComplianceModal.js';
import { DiagnosticsModal } from './components/DiagnosticsModal.js';
import { PropertyRecord, TenantInfo, StructuralVisibility } from './types/pipeline.js';
import { Loader2, Plus, Sparkles, Building2, MapPin } from 'lucide-react';

const FALLBACK_API_KEY =
  import.meta.env.VITE_GOOGLE_MAPS_API_KEY ||
  'AIzaSyDgX-zgWxGTnwQc-LOAgwahbtypQYtUdjo';

export default function App() {
  const [apiKey, setApiKey] = useState<string>(FALLBACK_API_KEY);
  const [tenants, setTenants] = useState<TenantInfo[]>([]);
  const [selectedTenantId, setSelectedTenantId] = useState<string>('all-us-national');
  const [properties, setProperties] = useState<PropertyRecord[]>([]);
  const [selectedPropertyId, setSelectedPropertyId] = useState<string | null>(null);
  const [selectedSegmentIndex, setSelectedSegmentIndex] = useState<number | null>(null);

  const [isIntakeModalOpen, setIsIntakeModalOpen] = useState<boolean>(false);
  const [isComplianceModalOpen, setIsComplianceModalOpen] = useState<boolean>(false);
  const [isDiagnosticsModalOpen, setIsDiagnosticsModalOpen] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'pipeline' | 'map' | 'compliance'>('pipeline');
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Structural Element Visibility on the Map Overlay
  const [structuralVisibility, setStructuralVisibility] = useState<StructuralVisibility>({
    facets: true,
    ridges: true,
    hips: true,
    valleys: true,
    eaves: true,
    rakes: true,
    markers: true,
  });

  const handleToggleStructuralVisibility = useCallback((key: keyof StructuralVisibility) => {
    setStructuralVisibility((prev) => ({
      ...prev,
      [key]: !prev[key],
    }));
  }, []);

  // Fetch server config and properties on mount
  useEffect(() => {
    async function initApp() {
      try {
        setIsLoading(true);

        // 1. Fetch server config for Google Maps API Key
        try {
          const configRes = await fetch('/api/config');
          if (configRes.ok) {
            const configData = await configRes.json();
            if (configData.googleMapsApiKey) {
              setApiKey(configData.googleMapsApiKey);
            }
          }
        } catch (e) {
          console.warn('Config fetch error, using default key:', e);
        }

        // 2. Fetch Tenants
        try {
          const tenantsRes = await fetch('/api/tenants');
          if (tenantsRes.ok) {
            const tenantsData = await tenantsRes.json();
            if (tenantsData.tenants && tenantsData.tenants.length > 0) {
              setTenants(tenantsData.tenants);
              // Default to national pipeline if available, otherwise first
              const nationalTenant = tenantsData.tenants.find((t: TenantInfo) => t.id === 'all-us-national');
              setSelectedTenantId(nationalTenant ? nationalTenant.id : tenantsData.tenants[0].id);
            }
          }
        } catch (e) {
          console.warn('Tenants fetch error:', e);
        }

        // 3. Fetch Initial Pipeline Properties
        const propsRes = await fetch('/api/pipeline/properties');
        if (propsRes.ok) {
          const propsData = await propsRes.json();
          if (propsData.properties && propsData.properties.length > 0) {
            setProperties(propsData.properties);
            setSelectedPropertyId(propsData.properties[0].id);
          }
        }
      } catch (err) {
        console.error('Initialization error:', err);
      } finally {
        setIsLoading(false);
      }
    }

    initApp();
  }, []);

  // Filter properties by selected tenant (or return all if national overview)
  const tenantProperties =
    selectedTenantId === 'all-us-national'
      ? properties
      : properties.filter((p) => p.tenantId === selectedTenantId);
  const currentPropertiesList = tenantProperties.length > 0 ? tenantProperties : properties;

  // Currently selected property object
  const selectedProperty =
    properties.find((p) => p.id === selectedPropertyId) ||
    currentPropertiesList[0] ||
    null;

  // Handle adding new property from measurement pipeline
  const handlePropertyMeasured = useCallback((newProperty: PropertyRecord) => {
    setProperties((prev) => [newProperty, ...prev.filter((p) => p.id !== newProperty.id)]);
    setSelectedPropertyId(newProperty.id);
    setSelectedSegmentIndex(null);
    setActiveTab('map');
  }, []);

  // Handle promoting or updating pipeline status
  const handleUpdateStatus = useCallback(async (newStatus: PropertyRecord['status']) => {
    if (!selectedPropertyId) return;

    try {
      const res = await fetch(`/api/pipeline/properties/${selectedPropertyId}/status`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ status: newStatus }),
      });

      if (res.ok) {
        const data = await res.json();
        setProperties((prev) =>
          prev.map((p) => (p.id === selectedPropertyId ? data.property : p))
        );
      }
    } catch (err) {
      console.error('Failed to update status:', err);
    }
  }, [selectedPropertyId]);

  return (
    <APIProvider
      apiKey={apiKey}
      version="beta" // Required for Places UI Kit & Advanced Marker web elements
      libraries={['places', 'marker', 'geometry']}
    >
      <div className="flex flex-col h-screen w-screen bg-slate-950 text-slate-100 overflow-hidden font-sans">
        {/* Top Bar Navigation (Strict 3-zone contract) */}
        <Header
          tenants={tenants}
          selectedTenantId={selectedTenantId}
          onSelectTenant={(id) => {
            setSelectedTenantId(id);
            const first = properties.find((p) => p.tenantId === id);
            if (first) {
              setSelectedPropertyId(first.id);
              setSelectedSegmentIndex(null);
            }
          }}
          onOpenIntakeModal={() => setIsIntakeModalOpen(true)}
          onOpenDiagnostics={() => setIsDiagnosticsModalOpen(true)}
          activeTab={activeTab}
          setActiveTab={(tab) => {
            if (tab === 'compliance') {
              setIsComplianceModalOpen(true);
            } else {
              setActiveTab(tab);
            }
          }}
        />

        {/* Main Work Area */}
        {isLoading ? (
          <div className="flex-1 flex flex-col items-center justify-center text-slate-400 gap-3">
            <Loader2 className="w-8 h-8 text-cyan-400 animate-spin" />
            <p className="text-xs font-mono">Initializing CRM Pipeline &amp; Solar API Engine...</p>
          </div>
        ) : (
          <main className="flex-1 flex min-h-0 overflow-hidden relative">
            {/* Left Pipeline Sidebar (hidden on pure canvas focus for maximum CAD width) */}
            {activeTab !== 'map' && (
              <PipelineSidebar
                properties={currentPropertiesList}
                selectedPropertyId={selectedPropertyId}
                onSelectProperty={(prop) => {
                  setSelectedPropertyId(prop.id);
                  setSelectedSegmentIndex(null);
                }}
                onOpenIntakeModal={() => setIsIntakeModalOpen(true)}
              />
            )}

            {/* Center: Interactive Google Vector Map Canvas with Explicit Height */}
            <div className="flex-1 flex flex-col min-h-0 h-full relative overflow-hidden">
              {activeTab === 'map' && (
                <div className="absolute top-4 right-4 z-20">
                  <button
                    type="button"
                    onClick={() => setActiveTab('pipeline')}
                    className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-slate-900/90 hover:bg-slate-800 text-slate-200 border border-slate-700 rounded-lg shadow-lg backdrop-blur-md cursor-pointer transition-colors"
                  >
                    <span>&larr; Show Properties List</span>
                  </button>
                </div>
              )}
              <RoofGeometryMap
                property={selectedProperty}
                allProperties={currentPropertiesList}
                selectedSegmentIndex={selectedSegmentIndex}
                onSelectSegment={(index) => setSelectedSegmentIndex(index)}
                onSelectProperty={(prop) => {
                  setSelectedPropertyId(prop.id);
                  setSelectedSegmentIndex(null);
                }}
                structuralVisibility={structuralVisibility}
                onToggleStructuralVisibility={handleToggleStructuralVisibility}
                onPropertyUpdated={(updated) => {
                  setProperties((prev) =>
                    prev.map((p) => (p.id === updated.id ? updated : p))
                  );
                }}
              />
            </div>

            {/* Right: Roof Takeoff & Measurement Summary Panel with Interactive Editing Mode */}
            <MeasurementSummaryPanel
              property={selectedProperty}
              selectedSegmentIndex={selectedSegmentIndex}
              onSelectSegment={(index) => setSelectedSegmentIndex(index)}
              onUpdateStatus={handleUpdateStatus}
              onOpenDiagnostics={() => setIsDiagnosticsModalOpen(true)}
              structuralVisibility={structuralVisibility}
              onToggleStructuralVisibility={handleToggleStructuralVisibility}
              onPropertyUpdated={(updated) => {
                setProperties((prev) =>
                  prev.map((p) => (p.id === updated.id ? updated : p))
                );
              }}
            />
          </main>
        )}

        {/* Modal: Intake Street Address & Solar API Processing */}
        <AddressIntakeModal
          isOpen={isIntakeModalOpen}
          onClose={() => setIsIntakeModalOpen(false)}
          tenantId={selectedTenantId}
          tenants={tenants}
          onPropertyMeasured={handlePropertyMeasured}
        />

        {/* Modal: 3-Tier Anti-Caching & Google Maps Platform Compliance */}
        <ComplianceModal
          isOpen={isComplianceModalOpen}
          onClose={() => setIsComplianceModalOpen(false)}
        />

        {/* Modal: API Diagnostics & Provenance Inspector (Priority 5) */}
        <DiagnosticsModal
          isOpen={isDiagnosticsModalOpen}
          onClose={() => setIsDiagnosticsModalOpen(false)}
          property={selectedProperty}
        />
      </div>
    </APIProvider>
  );
}
