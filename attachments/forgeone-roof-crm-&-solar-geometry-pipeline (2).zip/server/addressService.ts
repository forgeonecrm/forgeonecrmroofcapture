import { AddressValidationVerdict } from './types.js';

const SOLUTION_ID = 'gmp_mcp_codeassist_v1_aistudio';

function sanitizeLog(msg: string): string {
  if (!msg) return '';
  return msg.replace(/key=[A-Za-z0-9_-]+/gi, 'key=[REDACTED]');
}

export interface AddressValidationResult {
  standardizedAddress: string;
  placeId?: string;
  location?: {
    latitude: number;
    longitude: number;
  };
  bounds?: {
    sw: { latitude: number; longitude: number };
    ne: { latitude: number; longitude: number };
  };
  verdict: AddressValidationVerdict;
  rawResponse?: unknown;
}

export class AddressValidationError extends Error {
  public statusCode: number;
  public reason?: string;
  constructor(statusCode: number, message: string, reason?: string) {
    super(message);
    this.name = 'AddressValidationError';
    this.statusCode = statusCode;
    this.reason = reason;
  }
}

export async function validateAddressWithGoogle(
  addressString: string,
  apiKey: string
): Promise<AddressValidationResult> {
  const url = `https://addressvalidation.googleapis.com/v1:validateAddress?key=${apiKey}`;

  const requestBody = {
    address: {
      revision: 0,
      addressLines: [addressString],
    },
    enableUspsCass: true,
  };

  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-Goog-Maps-Solution-ID': SOLUTION_ID,
    },
    body: JSON.stringify(requestBody),
  });

  if (!response.ok) {
    let cleanReason = `HTTP ${response.status}`;
    try {
      const errJson = await response.json();
      if (errJson?.error?.message) {
        cleanReason = errJson.error.message;
      } else if (errJson?.error?.details?.[0]?.reason) {
        cleanReason = errJson.error.details[0].reason;
      }
    } catch {
      // response body was not valid json
    }

    // Clean single-line info log - avoid raw JSON dump or ErrorInfo objects
    console.info(`[Address Service] Address Validation API status: ${response.status} (${cleanReason}). Defaulting to Geocoding API.`);
    throw new AddressValidationError(response.status, cleanReason, cleanReason);
  }

  const data = await response.json();
  const res = data.result || {};
  const verdictObj = res.verdict || {};
  const usps = res.uspsData || {};
  const geocode = res.geocode || {};
  const postalAddress = res.address?.postalAddress || {};

  // Build standardized single line address
  const standardizedLines = [
    ...(postalAddress.addressLines || []),
    postalAddress.locality,
    postalAddress.administrativeArea,
    postalAddress.postalCode,
  ].filter(Boolean);

  const standardizedAddress =
    res.address?.formattedAddress ||
    standardizedLines.join(', ') ||
    addressString;

  const lat = geocode.location?.latitude;
  const lng = geocode.location?.longitude;

  return {
    standardizedAddress,
    placeId: geocode.placeId,
    location: lat && lng ? { latitude: lat, longitude: lng } : undefined,
    bounds: geocode.bounds
      ? {
          sw: {
            latitude: geocode.bounds.southWest?.latitude ?? lat,
            longitude: geocode.bounds.southWest?.longitude ?? lng,
          },
          ne: {
            latitude: geocode.bounds.northEast?.latitude ?? lat,
            longitude: geocode.bounds.northEast?.longitude ?? lng,
          },
        }
      : undefined,
    verdict: {
      inputGranularity: verdictObj.inputGranularity,
      validationGranularity: verdictObj.validationGranularity,
      geocodeGranularity: verdictObj.geocodeGranularity,
      addressComplete: verdictObj.addressComplete,
      hasUnconfirmedComponents: verdictObj.hasUnconfirmedComponents,
      hasInferredComponents: verdictObj.hasInferredComponents,
      hasReplacedComponents: verdictObj.hasReplacedComponents,
      uspsCassProcessed: Boolean(usps.cassProcessed),
      dpvConfirmation: usps.dpvConfirmation,
      carrierRoute: usps.carrierRoute,
      isResidential: usps.dpvResidentialIndicator === 'Y',
      isBusiness: usps.dpvResidentialIndicator === 'N',
    },
    rawResponse: data,
  };
}

export async function geocodeWithGoogle(
  query: { address?: string; placeId?: string },
  apiKey: string
): Promise<{
  formattedAddress: string;
  placeId: string;
  location: { latitude: number; longitude: number };
  bounds?: {
    sw: { latitude: number; longitude: number };
    ne: { latitude: number; longitude: number };
  };
}> {
  let param = '';
  if (query.placeId) {
    param = `place_id=${encodeURIComponent(query.placeId)}`;
  } else if (query.address) {
    param = `address=${encodeURIComponent(query.address)}`;
  } else {
    throw new Error('Either address or placeId must be provided for geocoding.');
  }

  const url = `https://maps.googleapis.com/maps/api/geocode/json?${param}&key=${apiKey}&solution_id=${SOLUTION_ID}`;

  const response = await fetch(url, {
    headers: {
      'X-Goog-Maps-Solution-ID': SOLUTION_ID,
    },
  });

  if (!response.ok) {
    let cleanReason = `HTTP ${response.status}`;
    try {
      const errJson = await response.json();
      cleanReason = errJson?.error_message || errJson?.status || cleanReason;
    } catch {
      // response body was not json
    }
    console.info(`[Geocoding API] Request returned status ${response.status}: ${cleanReason}`);
    throw new Error(`Geocoding failed (${response.status}): ${cleanReason}`);
  }

  const data = await response.json();
  if (data.status !== 'OK' || !data.results || data.results.length === 0) {
    const msg = `Geocoding status: ${data.status} - ${data.error_message || 'No results found'}`;
    console.info(`[Geocoding API] Status note: ${msg}`);
    throw new Error(msg);
  }

  const result = data.results[0];
  const loc = result.geometry.location;
  const viewport = result.geometry.viewport;

  return {
    formattedAddress: result.formatted_address,
    placeId: result.place_id,
    location: {
      latitude: loc.lat,
      longitude: loc.lng,
    },
    bounds: viewport
      ? {
          sw: { latitude: viewport.southwest.lat, longitude: viewport.southwest.lng },
          ne: { latitude: viewport.northeast.lat, longitude: viewport.northeast.lng },
        }
      : undefined,
  };
}
