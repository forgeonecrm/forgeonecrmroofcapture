import { RoofSegment, StructuralLine, TakeoffSummary } from './types.js';

export function calculateDistanceFeet(
  p1: { lat: number; lng: number },
  p2: { lat: number; lng: number }
): number {
  const R = 20902231; // feet
  const dLat = ((p2.lat - p1.lat) * Math.PI) / 180;
  const dLng = ((p2.lng - p1.lng) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((p1.lat * Math.PI) / 180) *
      Math.cos((p2.lat * Math.PI) / 180) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 10) / 10;
}

export function calculatePolygonAreaSqFt(path: { lat: number; lng: number }[]): number {
  if (!path || path.length < 3) return 0;
  const R = 20902231; // feet
  let area = 0;
  const len = path.length;
  const toRad = Math.PI / 180;
  for (let i = 0; i < len; i++) {
    const p1 = path[i];
    const p2 = path[(i + 1) % len];
    const x1 = p1.lng * toRad * Math.cos(((p1.lat + p2.lat) / 2) * toRad) * R;
    const y1 = p1.lat * toRad * R;
    const x2 = p2.lng * toRad * Math.cos(((p1.lat + p2.lat) / 2) * toRad) * R;
    const y2 = p2.lat * toRad * R;
    area += x1 * y2 - x2 * y1;
  }
  return Math.abs(Math.round(area / 2));
}

export function generateAutoCapturedRoof(
  centerLat: number,
  centerLng: number
): {
  segments: RoofSegment[];
  customEdges: StructuralLine[];
  takeoff: TakeoffSummary;
} {
  const feetPerLatDegree = 364173;
  const feetPerLngDegree = 364173 * Math.cos((centerLat * Math.PI) / 180);

  const halfLengthFt = 25; // 50 ft E-W
  const halfWidthFt = 18;  // 36 ft N-S
  const ridgeHalfLenFt = 12; // 24 ft ridge

  const dLatEave = halfWidthFt / feetPerLatDegree;
  const dLngEave = halfLengthFt / feetPerLngDegree;
  const dLngRidge = ridgeHalfLenFt / feetPerLngDegree;

  const sw = { lat: centerLat - dLatEave, lng: centerLng - dLngEave };
  const se = { lat: centerLat - dLatEave, lng: centerLng + dLngEave };
  const nw = { lat: centerLat + dLatEave, lng: centerLng - dLngEave };
  const ne = { lat: centerLat + dLatEave, lng: centerLng + dLngEave };

  const ridgeWest = { lat: centerLat, lng: centerLng - dLngRidge };
  const ridgeEast = { lat: centerLat, lng: centerLng + dLngRidge };

  const pitchDegrees = 22.6;
  const pitchRatio = '5.0:12';
  const pitchMultiplier = 1 / Math.cos((pitchDegrees * Math.PI) / 180);

  const southPath = [sw, se, ridgeEast, ridgeWest];
  const southGroundArea = calculatePolygonAreaSqFt(southPath);
  const southAreaSqFt = Math.round(southGroundArea * pitchMultiplier);

  const northPath = [nw, ridgeWest, ridgeEast, ne];
  const northGroundArea = calculatePolygonAreaSqFt(northPath);
  const northAreaSqFt = Math.round(northGroundArea * pitchMultiplier);

  const eastPath = [se, ne, ridgeEast];
  const eastGroundArea = calculatePolygonAreaSqFt(eastPath);
  const eastAreaSqFt = Math.round(eastGroundArea * pitchMultiplier);

  const westPath = [sw, ridgeWest, nw];
  const westGroundArea = calculatePolygonAreaSqFt(westPath);
  const westAreaSqFt = Math.round(westGroundArea * pitchMultiplier);

  const totalGroundSqFt = southGroundArea + northGroundArea + eastGroundArea + westGroundArea;
  const totalRoofAreaSqFt = southAreaSqFt + northAreaSqFt + eastAreaSqFt + westAreaSqFt;
  const totalRoofSquares = Math.round((totalRoofAreaSqFt / 100) * 10) / 10;
  const totalRoofAreaMeters2 = Math.round((totalRoofAreaSqFt / 10.7639) * 10) / 10;

  const segments: RoofSegment[] = [
    {
      segmentIndex: 0,
      name: 'South Main Facet',
      pitchDegrees,
      pitchRatio,
      azimuthDegrees: 180,
      azimuthDirection: 'S',
      areaSqFt: southAreaSqFt,
      areaMeters2: Math.round((southAreaSqFt / 10.7639) * 10) / 10,
      groundAreaSqFt: southGroundArea,
      groundAreaMeters2: Math.round((southGroundArea / 10.7639) * 10) / 10,
      planeHeightMeters: 4.8,
      planeHeightFeet: 15.7,
      center: { latitude: centerLat - dLatEave / 2, longitude: centerLng },
      boundingBox: {
        sw: { latitude: centerLat - dLatEave, longitude: centerLng - dLngEave },
        ne: { latitude: centerLat, longitude: centerLng + dLngEave },
      },
      polygonPath: southPath,
      estimatedLengthFeet: 50,
      estimatedWidthFeet: 19.5,
      source: 'CALCULATED_GEOMETRY',
      hasExistingPanels: false,
      existingPanelCount: 0,
    },
    {
      segmentIndex: 1,
      name: 'North Main Facet',
      pitchDegrees,
      pitchRatio,
      azimuthDegrees: 0,
      azimuthDirection: 'N',
      areaSqFt: northAreaSqFt,
      areaMeters2: Math.round((northAreaSqFt / 10.7639) * 10) / 10,
      groundAreaSqFt: northGroundArea,
      groundAreaMeters2: Math.round((northGroundArea / 10.7639) * 10) / 10,
      planeHeightMeters: 4.8,
      planeHeightFeet: 15.7,
      center: { latitude: centerLat + dLatEave / 2, longitude: centerLng },
      boundingBox: {
        sw: { latitude: centerLat, longitude: centerLng - dLngEave },
        ne: { latitude: centerLat + dLatEave, longitude: centerLng + dLngEave },
      },
      polygonPath: northPath,
      estimatedLengthFeet: 50,
      estimatedWidthFeet: 19.5,
      source: 'CALCULATED_GEOMETRY',
      hasExistingPanels: false,
      existingPanelCount: 0,
    },
    {
      segmentIndex: 2,
      name: 'East Hip Facet',
      pitchDegrees,
      pitchRatio,
      azimuthDegrees: 90,
      azimuthDirection: 'E',
      areaSqFt: eastAreaSqFt,
      areaMeters2: Math.round((eastAreaSqFt / 10.7639) * 10) / 10,
      groundAreaSqFt: eastGroundArea,
      groundAreaMeters2: Math.round((eastGroundArea / 10.7639) * 10) / 10,
      planeHeightMeters: 4.8,
      planeHeightFeet: 15.7,
      center: { latitude: centerLat, longitude: centerLng + dLngEave / 2 },
      boundingBox: {
        sw: { latitude: centerLat - dLatEave, longitude: centerLng + dLngRidge },
        ne: { latitude: centerLat + dLatEave, longitude: centerLng + dLngEave },
      },
      polygonPath: eastPath,
      estimatedLengthFeet: 36,
      estimatedWidthFeet: 14,
      source: 'CALCULATED_GEOMETRY',
      hasExistingPanels: false,
      existingPanelCount: 0,
    },
    {
      segmentIndex: 3,
      name: 'West Hip Facet',
      pitchDegrees,
      pitchRatio,
      azimuthDegrees: 270,
      azimuthDirection: 'W',
      areaSqFt: westAreaSqFt,
      areaMeters2: Math.round((westAreaSqFt / 10.7639) * 10) / 10,
      groundAreaSqFt: westGroundArea,
      groundAreaMeters2: Math.round((westGroundArea / 10.7639) * 10) / 10,
      planeHeightMeters: 4.8,
      planeHeightFeet: 15.7,
      center: { latitude: centerLat, longitude: centerLng - dLngEave / 2 },
      boundingBox: {
        sw: { latitude: centerLat - dLatEave, longitude: centerLng - dLngEave },
        ne: { latitude: centerLat + dLatEave, longitude: centerLng - dLngRidge },
      },
      polygonPath: westPath,
      estimatedLengthFeet: 36,
      estimatedWidthFeet: 14,
      source: 'CALCULATED_GEOMETRY',
      hasExistingPanels: false,
      existingPanelCount: 0,
    },
  ];

  const ridgeLength = calculateDistanceFeet(ridgeWest, ridgeEast);
  const southEaveLength = calculateDistanceFeet(sw, se);
  const northEaveLength = calculateDistanceFeet(nw, ne);
  const eastEaveLength = calculateDistanceFeet(se, ne);
  const westEaveLength = calculateDistanceFeet(sw, nw);

  const hipSWLength = calculateDistanceFeet(sw, ridgeWest);
  const hipNWLength = calculateDistanceFeet(nw, ridgeWest);
  const hipSELength = calculateDistanceFeet(se, ridgeEast);
  const hipNELength = calculateDistanceFeet(ne, ridgeEast);

  const totalEaves = southEaveLength + northEaveLength + eastEaveLength + westEaveLength;
  const totalHips = hipSWLength + hipNWLength + hipSELength + hipNELength;
  const totalRidges = ridgeLength;
  const totalEdges = totalEaves + totalHips + totalRidges;

  const customEdges: StructuralLine[] = [
    {
      id: 'edge-ridge-1',
      type: 'ridge',
      name: 'Center Ridge',
      path: [ridgeWest, ridgeEast],
      lengthFeet: ridgeLength,
    },
    {
      id: 'edge-eave-south',
      type: 'eave',
      name: 'South Eave (Gutter)',
      path: [sw, se],
      lengthFeet: southEaveLength,
    },
    {
      id: 'edge-eave-north',
      type: 'eave',
      name: 'North Eave (Gutter)',
      path: [nw, ne],
      lengthFeet: northEaveLength,
    },
    {
      id: 'edge-eave-east',
      type: 'eave',
      name: 'East Eave',
      path: [se, ne],
      lengthFeet: eastEaveLength,
    },
    {
      id: 'edge-eave-west',
      type: 'eave',
      name: 'West Eave',
      path: [sw, nw],
      lengthFeet: westEaveLength,
    },
    {
      id: 'edge-hip-sw',
      type: 'hip',
      name: 'SW Hip',
      path: [sw, ridgeWest],
      lengthFeet: hipSWLength,
    },
    {
      id: 'edge-hip-nw',
      type: 'hip',
      name: 'NW Hip',
      path: [nw, ridgeWest],
      lengthFeet: hipNWLength,
    },
    {
      id: 'edge-hip-se',
      type: 'hip',
      name: 'SE Hip',
      path: [se, ridgeEast],
      lengthFeet: hipSELength,
    },
    {
      id: 'edge-hip-ne',
      type: 'hip',
      name: 'NE Hip',
      path: [ne, ridgeEast],
      lengthFeet: hipNELength,
    },
  ];

  const takeoff: TakeoffSummary = {
    totalRoofAreaMeters2,
    totalRoofAreaSqFt,
    totalRoofSquares,
    groundFootprintSqFt: totalGroundSqFt,
    dominantPitchDegrees: pitchDegrees,
    dominantPitchRatio: pitchRatio,
    minPitchDegrees: pitchDegrees,
    maxPitchDegrees: pitchDegrees,
    weightedPitchDegrees: pitchDegrees,
    dominantAzimuthDegrees: 180,
    dominantAzimuthDirection: 'S',
    totalSegments: 4,
    linearEdgesAvailable: true,
    estimatedEavesFeet: Math.round(totalEaves),
    estimatedRidgesFeet: Math.round(totalRidges),
    estimatedHipsFeet: Math.round(totalHips),
    estimatedValleysFeet: 0,
    estimatedRakesFeet: 0,
    estimatedTotalLinearEdgeFeet: Math.round(totalEdges),
    maxPanelsCount: Math.round(totalRoofAreaSqFt / 22),
    panelCapacityWatts: 400,
    maxCapacityKw: Math.round((totalRoofAreaSqFt / 22) * 0.4 * 10) / 10,
    maxSunshineHoursPerYear: 1420,
    carbonOffsetKgPerYear: Math.round(totalRoofAreaSqFt * 2.8),
    dataProvenance: {
      totalRoofAreaSqFt: 'CALCULATED_GEOMETRY',
      totalRoofAreaMeters2: 'CALCULATED_GEOMETRY',
      dominantPitchDegrees: 'CALCULATED_GEOMETRY',
      dominantPitchRatio: 'CALCULATED_GEOMETRY',
      dominantAzimuthDegrees: 'CALCULATED_GEOMETRY',
      dominantAzimuthDirection: 'CALCULATED_GEOMETRY',
      totalRoofSquares: 'CALCULATED_GEOMETRY',
      groundFootprintSqFt: 'CALCULATED_GEOMETRY',
      maxPanelsCount: 'CALCULATED_GEOMETRY',
      maxCapacityKw: 'CALCULATED_GEOMETRY',
      maxSunshineHoursPerYear: 'CALCULATED_GEOMETRY',
      carbonOffsetKgPerYear: 'CALCULATED_GEOMETRY',
      estimatedEavesFeet: 'CALCULATED_GEOMETRY',
      estimatedRidgesFeet: 'CALCULATED_GEOMETRY',
      estimatedHipsFeet: 'CALCULATED_GEOMETRY',
      estimatedValleysFeet: 'CALCULATED_GEOMETRY',
      estimatedRakesFeet: 'CALCULATED_GEOMETRY',
      estimatedTotalLinearEdgeFeet: 'CALCULATED_GEOMETRY',
    },
  };

  return { segments, customEdges, takeoff };
}
