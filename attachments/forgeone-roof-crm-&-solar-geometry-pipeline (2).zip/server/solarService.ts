import {
  GeoTIFFLayers,
  ImageryQuality,
  RoofSegment,
  TakeoffSummary,
  SolarCoverageStatus,
  DiagnosticLog,
} from './types.js';

const SOLUTION_ID = 'gmp_mcp_codeassist_v1_aistudio';

// Sanitize any API key from log strings or errors
export function sanitizeLog(msg: string): string {
  if (!msg) return '';
  return msg.replace(/key=[A-Za-z0-9_-]+/gi, 'key=[REDACTED]');
}

// Convert degrees to radians
function toRadians(deg: number): number {
  return (deg * Math.PI) / 180;
}

// Convert pitch degrees into standard US roof slope ratio (e.g. 5.5:12)
export function degreesToPitchRatio(degrees: number): string {
  if (degrees <= 0) return '0:12';
  const riseOver12 = 12 * Math.tan(toRadians(degrees));
  return `${riseOver12.toFixed(1)}:12`;
}

// Convert azimuth degrees to 16-point compass direction
export function azimuthToCompass(degrees: number): string {
  const normalized = ((degrees % 360) + 360) % 360;
  const directions = [
    'N', 'NNE', 'NE', 'ENE',
    'E', 'ESE', 'SE', 'SSE',
    'S', 'SSW', 'SW', 'WSW',
    'W', 'WNW', 'NW', 'NNW',
  ];
  const index = Math.round(normalized / 22.5) % 16;
  return directions[index];
}

export interface SolarBuildingInsightsResult {
  buildingInsights: any;
  dataLayers: GeoTIFFLayers;
  takeoff: TakeoffSummary;
  segments: RoofSegment[];
  qualityUsed: ImageryQuality;
  diagnostics: DiagnosticLog[];
}

export class SolarApiError extends Error {
  public code: SolarCoverageStatus;
  public statusCode: number;
  public details?: string;

  constructor(code: SolarCoverageStatus, statusCode: number, message: string, details?: string) {
    super(message);
    this.name = 'SolarApiError';
    this.code = code;
    this.statusCode = statusCode;
    this.details = details;
  }
}

export async function fetchSolarData(
  latitude: number,
  longitude: number,
  apiKey: string
): Promise<SolarBuildingInsightsResult> {
  const diagnostics: DiagnosticLog[] = [];
  const qualities: ImageryQuality[] = ['HIGH', 'MEDIUM', 'BASE'];
  let rawInsights: any = null;
  let qualityUsed: ImageryQuality = 'HIGH';
  let lastError: any = null;
  let lastStatusCode = 0;

  // Attempt buildingInsights with fallback from HIGH -> MEDIUM -> BASE
  for (const quality of qualities) {
    const url = `https://solar.googleapis.com/v1/buildingInsights:findClosest?location.latitude=${latitude}&location.longitude=${longitude}&requiredQuality=${quality}&key=${apiKey}&solution_id=${SOLUTION_ID}`;

    try {
      const res = await fetch(url, {
        headers: {
          'X-Goog-Maps-Solution-ID': SOLUTION_ID,
        },
      });

      lastStatusCode = res.status;

      if (res.ok) {
        rawInsights = await res.json();
        qualityUsed = quality;
        diagnostics.push({
          timestamp: new Date().toISOString(),
          service: 'SOLAR_API',
          status: 'SUCCESS',
          statusCode: res.status,
          message: `Building Insights resolved successfully using ${quality} imagery quality tier.`,
        });
        break;
      } else {
        const errJson = await res.json().catch(() => null);
        lastError = errJson || { status: res.status, statusText: res.statusText };
        
        diagnostics.push({
          timestamp: new Date().toISOString(),
          service: 'SOLAR_API',
          status: res.status === 404 ? 'INFO' : 'ERROR',
          statusCode: res.status,
          message: `Quality tier ${quality} returned status ${res.status}: ${sanitizeLog(errJson?.error?.message || res.statusText)}`,
        });

        // If 404 NOT_FOUND, check if lower quality has coverage
        if (res.status === 404) {
          continue;
        } else if (res.status === 403) {
          throw new SolarApiError(
            'SERVICE_DISABLED_403',
            403,
            'Google Solar API returned 403 Forbidden. Verify that Solar API is enabled and authorized on Google Cloud Project gmp-demo-project-576437582.',
            sanitizeLog(errJson?.error?.message || 'Permission Denied / Service Disabled')
          );
        } else if (res.status === 429) {
          throw new SolarApiError(
            'RATE_LIMITED_429',
            429,
            'Google Solar API quota or rate limit exceeded.',
            sanitizeLog(errJson?.error?.message || 'Quota Exceeded')
          );
        } else {
          throw new SolarApiError(
            'NOT_AVAILABLE',
            res.status,
            `Solar API error (${res.status}): ${sanitizeLog(errJson?.error?.message || res.statusText)}`
          );
        }
      }
    } catch (e: any) {
      if (e instanceof SolarApiError) throw e;
      lastError = e;
    }
  }

  if (!rawInsights) {
    const errorMsg =
      lastStatusCode === 404
        ? 'No building footprint or solar geometry available for this parcel from Google Solar API. Location may be outside high-resolution 3D coverage.'
        : `Solar API request failed with status ${lastStatusCode}.`;
    
    console.info(`[Solar API] ${sanitizeLog(errorMsg)} (Lat: ${latitude.toFixed(5)}, Lng: ${longitude.toFixed(5)})`);

    throw new SolarApiError(
      'NO_COVERAGE_404',
      404,
      errorMsg,
      sanitizeLog(lastError?.error?.message || lastError?.message || 'NOT_FOUND')
    );
  }

  // Attempt dataLayers fetch for GeoTIFFs (DSM, RGB, Mask, Flux)
  const dataLayers: GeoTIFFLayers = {};
  try {
    const layersUrl = `https://solar.googleapis.com/v1/dataLayers:get?location.latitude=${latitude}&location.longitude=${longitude}&radiusMeters=60&view=FULL_LAYERS&requiredQuality=${qualityUsed}&key=${apiKey}&solution_id=${SOLUTION_ID}`;
    const layersRes = await fetch(layersUrl, {
      headers: {
        'X-Goog-Maps-Solution-ID': SOLUTION_ID,
      },
    });

    if (layersRes.ok) {
      const layersJson = await layersRes.json();
      dataLayers.imageryDate = layersJson.imageryDate;
      dataLayers.imageryQuality = layersJson.imageryQuality;
      dataLayers.dsmUrl = layersJson.dsmUrl;
      dataLayers.rgbUrl = layersJson.rgbUrl;
      dataLayers.maskUrl = layersJson.maskUrl;
      dataLayers.annualFluxUrl = layersJson.annualFluxUrl;
      dataLayers.monthlyFluxUrl = layersJson.monthlyFluxUrl;
      dataLayers.hourlyShadeUrlsCount = Array.isArray(layersJson.hourlyShadeUrls)
        ? layersJson.hourlyShadeUrls.length
        : 0;

      diagnostics.push({
        timestamp: new Date().toISOString(),
        service: 'DATA_LAYERS',
        status: 'SUCCESS',
        statusCode: layersRes.status,
        message: `DataLayers GeoTIFF URLs extracted (DSM, RGB, Mask, Annual Flux, ${dataLayers.hourlyShadeUrlsCount} hourly shade rasters). Ephemeral Tier-3 compliance active.`,
      });
    } else {
      diagnostics.push({
        timestamp: new Date().toISOString(),
        service: 'DATA_LAYERS',
        status: 'WARNING',
        statusCode: layersRes.status,
        message: 'DataLayers rasters not available for this radius. Continuing with Building Insights geometry.',
      });
    }
  } catch (err: any) {
    diagnostics.push({
      timestamp: new Date().toISOString(),
      service: 'DATA_LAYERS',
      status: 'WARNING',
      message: `DataLayers fetch skipped: ${sanitizeLog(err.message)}`,
    });
  }

  // Extract real roof segment stats directly from Google Solar API response
  const rawSegments = rawInsights.solarPotential?.roofSegmentStats || [];
  const segments: RoofSegment[] = [];

  let totalMeters2 = 0;
  let totalGroundMeters2 = 0;
  let weightedPitchSum = 0;
  let minPitch = 999;
  let maxPitch = 0;

  const pitchFreq = new Map<number, number>();
  const azimuthFreq = new Map<number, number>();

  rawSegments.forEach((seg: any, idx: number) => {
    const pitch = seg.pitchDegrees ?? 0;
    const azimuth = seg.azimuthDegrees ?? 0;
    const areaM2 = seg.stats?.areaMeters2 ?? 0;
    const groundM2 = seg.stats?.groundAreaMeters2 ?? Math.cos(toRadians(pitch)) * areaM2;
    const heightM = seg.planeHeightAtCenterMeters ?? 6.0;

    totalMeters2 += areaM2;
    totalGroundMeters2 += groundM2;
    weightedPitchSum += pitch * areaM2;

    if (pitch < minPitch) minPitch = pitch;
    if (pitch > maxPitch) maxPitch = pitch;

    const roundedPitch = Math.round(pitch * 2) / 2;
    pitchFreq.set(roundedPitch, (pitchFreq.get(roundedPitch) || 0) + areaM2);

    const roundedAzimuth = Math.round(azimuth / 15) * 15;
    azimuthFreq.set(roundedAzimuth, (azimuthFreq.get(roundedAzimuth) || 0) + areaM2);

    const areaSqFt = areaM2 * 10.7639;

    // Derived plane approximate aspect bounds from bounding box coordinates
    let estimatedLengthFeet = 0;
    let estimatedWidthFeet = 0;
    if (seg.boundingBox?.sw && seg.boundingBox?.ne) {
      // 1 deg latitude ~ 364,000 feet; 1 deg longitude ~ 364,000 * cos(lat)
      const latDiff = Math.abs(seg.boundingBox.ne.latitude - seg.boundingBox.sw.latitude);
      const lngDiff = Math.abs(seg.boundingBox.ne.longitude - seg.boundingBox.sw.longitude);
      const feetY = latDiff * 364000;
      const feetX = lngDiff * 364000 * Math.cos(toRadians(latitude));
      estimatedLengthFeet = Math.max(10, Math.round(Math.max(feetX, feetY)));
      estimatedWidthFeet = Math.max(8, Math.round(Math.min(feetX, feetY)));
    } else {
      estimatedWidthFeet = Math.max(10, Math.round(Math.sqrt(areaSqFt / 1.35)));
      estimatedLengthFeet = Math.round(areaSqFt / estimatedWidthFeet);
    }

    segments.push({
      segmentIndex: idx,
      pitchDegrees: Math.round(pitch * 100) / 100,
      pitchRatio: degreesToPitchRatio(pitch),
      azimuthDegrees: Math.round(azimuth * 10) / 10,
      azimuthDirection: azimuthToCompass(azimuth),
      areaMeters2: Math.round(areaM2 * 10) / 10,
      areaSqFt: Math.round(areaSqFt),
      groundAreaMeters2: Math.round(groundM2 * 10) / 10,
      groundAreaSqFt: Math.round(groundM2 * 10.7639),
      planeHeightMeters: Math.round(heightM * 10) / 10,
      planeHeightFeet: Math.round(heightM * 3.28084 * 10) / 10,
      center: {
        latitude: seg.center?.latitude ?? latitude,
        longitude: seg.center?.longitude ?? longitude,
      },
      boundingBox: {
        sw: {
          latitude: seg.boundingBox?.sw?.latitude ?? latitude - 0.0001,
          longitude: seg.boundingBox?.sw?.longitude ?? longitude - 0.0001,
        },
        ne: {
          latitude: seg.boundingBox?.ne?.latitude ?? latitude + 0.0001,
          longitude: seg.boundingBox?.ne?.longitude ?? longitude + 0.0001,
        },
      },
      estimatedLengthFeet,
      estimatedWidthFeet,
      source: 'DIRECT_SOLAR_API',
    });
  });

  // Calculate dominant pitch & azimuth from real weighted distributions
  let dominantPitch = rawSegments[0]?.pitchDegrees ?? 18.0;
  let maxPitchWeight = -1;
  pitchFreq.forEach((weight, p) => {
    if (weight > maxPitchWeight) {
      maxPitchWeight = weight;
      dominantPitch = p;
    }
  });

  let dominantAzimuth = rawSegments[0]?.azimuthDegrees ?? 180;
  let maxAzimuthWeight = -1;
  azimuthFreq.forEach((weight, az) => {
    if (weight > maxAzimuthWeight) {
      maxAzimuthWeight = weight;
      dominantAzimuth = az;
    }
  });

  const wholeStats = rawInsights.solarPotential?.wholeRoofStats;
  const finalAreaM2 = wholeStats?.areaMeters2 || totalMeters2;
  const finalAreaSqFt = Math.round(finalAreaM2 * 10.7639);
  const finalGroundSqFt = Math.round((wholeStats?.groundAreaMeters2 || totalGroundMeters2 || finalAreaM2 * 0.9) * 10.7639);
  const totalSquares = Math.round((finalAreaSqFt / 100) * 10) / 10;

  const solarPot = rawInsights.solarPotential || {};
  const maxPanels = solarPot.maxArrayPanelsCount || 0;
  const panelWattage = solarPot.panelCapacityWatts || 400;
  const capacityKw = Math.round(((maxPanels * panelWattage) / 1000) * 10) / 10;
  const sunshineHours = Math.round(solarPot.maxSunshineHoursPerYear || 0);
  const carbonOffsetFactor = solarPot.carbonOffsetFactorKgPerMwh || 450;
  const annualKwhEst = capacityKw * sunshineHours * 0.78;
  const carbonOffsetKg = Math.round((annualKwhEst / 1000) * carbonOffsetFactor);

  // CRITICAL (PRIORITY 2): Do not fabricate ridge, hip, valley, rake, or eave footages!
  // Google Solar API does not provide edge vector classifications.
  // Set linear edges as unavailable unless manually delineated or CAD verified.
  const takeoff: TakeoffSummary = {
    totalRoofAreaMeters2: Math.round(finalAreaM2 * 10) / 10,
    totalRoofAreaSqFt: finalAreaSqFt,
    totalRoofSquares: totalSquares,
    groundFootprintSqFt: finalGroundSqFt,
    dominantPitchDegrees: Math.round(dominantPitch * 10) / 10,
    dominantPitchRatio: degreesToPitchRatio(dominantPitch),
    minPitchDegrees: minPitch < 999 ? Math.round(minPitch * 10) / 10 : 0,
    maxPitchDegrees: Math.round(maxPitch * 10) / 10,
    weightedPitchDegrees: totalMeters2 > 0 ? Math.round((weightedPitchSum / totalMeters2) * 10) / 10 : dominantPitch,
    dominantAzimuthDegrees: Math.round(dominantAzimuth * 10) / 10,
    dominantAzimuthDirection: azimuthToCompass(dominantAzimuth),
    totalSegments: segments.length,
    // Explicitly marked unavailable
    linearEdgesAvailable: false,
    estimatedEavesFeet: null,
    estimatedRidgesFeet: null,
    estimatedHipsFeet: null,
    estimatedValleysFeet: null,
    estimatedRakesFeet: null,
    estimatedTotalLinearEdgeFeet: null,
    maxPanelsCount: maxPanels,
    panelCapacityWatts: panelWattage,
    maxCapacityKw: capacityKw,
    maxSunshineHoursPerYear: sunshineHours,
    carbonOffsetKgPerYear: carbonOffsetKg,
    dataProvenance: {
      totalRoofAreaSqFt: 'DIRECT_SOLAR_API',
      totalRoofAreaMeters2: 'DIRECT_SOLAR_API',
      dominantPitchDegrees: 'DIRECT_SOLAR_API',
      dominantPitchRatio: 'CALCULATED_GEOMETRY',
      dominantAzimuthDegrees: 'DIRECT_SOLAR_API',
      dominantAzimuthDirection: 'CALCULATED_GEOMETRY',
      totalRoofSquares: 'CALCULATED_GEOMETRY',
      groundFootprintSqFt: 'CALCULATED_GEOMETRY',
      maxPanelsCount: 'DIRECT_SOLAR_API',
      maxCapacityKw: 'DIRECT_SOLAR_API',
      maxSunshineHoursPerYear: 'DIRECT_SOLAR_API',
      carbonOffsetKgPerYear: 'DIRECT_SOLAR_API',
      estimatedEavesFeet: 'UNAVAILABLE',
      estimatedRidgesFeet: 'UNAVAILABLE',
      estimatedHipsFeet: 'UNAVAILABLE',
      estimatedValleysFeet: 'UNAVAILABLE',
      estimatedRakesFeet: 'UNAVAILABLE',
      estimatedTotalLinearEdgeFeet: 'UNAVAILABLE',
    },
  };

  return {
    buildingInsights: rawInsights,
    dataLayers,
    takeoff,
    segments,
    qualityUsed,
    diagnostics,
  };
}
