export type ImageryQuality = 'HIGH' | 'MEDIUM' | 'BASE' | 'UNKNOWN';

export type PipelineStatus = 
  | 'INTAKE_VALIDATED'
  | 'PARCEL_GEOCODED'
  | 'ROOF_GEOMETRY_EXTRACTED'
  | 'TAKEOFF_VERIFIED'
  | 'PROPOSAL_GENERATED'
  | 'NEEDS_ANALYSIS'
  | 'DEMO_SAMPLE';

export type SolarCoverageStatus =
  | 'AVAILABLE'
  | 'NO_COVERAGE_404'
  | 'SERVICE_DISABLED_403'
  | 'RATE_LIMITED_429'
  | 'NOT_AVAILABLE'
  | 'UNRESOLVED';

export type MeasurementSource =
  | 'DIRECT_SOLAR_API'
  | 'CALCULATED_GEOMETRY'
  | 'UNAVAILABLE'
  | 'MANUAL_EDIT';

export interface RoofSegment {
  segmentIndex: number;
  pitchDegrees: number;
  pitchRatio: string; // e.g. "5.5:12"
  azimuthDegrees: number;
  azimuthDirection: string; // e.g. "SSW"
  areaMeters2: number;
  areaSqFt: number;
  groundAreaMeters2: number;
  groundAreaSqFt: number;
  planeHeightMeters: number;
  planeHeightFeet: number;
  center: {
    latitude: number;
    longitude: number;
  };
  boundingBox: {
    sw: { latitude: number; longitude: number };
    ne: { latitude: number; longitude: number };
  };
  polygonPath?: { lat: number; lng: number }[];
  estimatedLengthFeet: number;
  estimatedWidthFeet: number;
  // Provenance flag
  source?: MeasurementSource;
  // Existing solar on this specific roof facet
  hasExistingPanels?: boolean;
  existingPanelCount?: number;
  name?: string;
}

export interface ExistingSolarSystem {
  hasExistingSolar: boolean;
  panelCount: number;
  capacityKw: number;
  installedYear?: number;
  condition: 'GOOD' | 'FAIR' | 'NEEDS_REROOF_DETACH_RESET' | 'OBSOLETE_DECOMMISSION';
  inverterType: 'STRING' | 'MICROINVERTER' | 'OPTIMIZER' | 'UNKNOWN';
  notes?: string;
}

export interface TakeoffSummary {
  totalRoofAreaMeters2: number;
  totalRoofAreaSqFt: number;
  totalRoofSquares: number; // 1 square = 100 sq ft
  groundFootprintSqFt: number;
  dominantPitchDegrees: number;
  dominantPitchRatio: string;
  minPitchDegrees: number;
  maxPitchDegrees: number;
  weightedPitchDegrees: number;
  dominantAzimuthDegrees: number;
  dominantAzimuthDirection: string;
  totalSegments: number;
  // Linear feet takeoff estimations (nullable if Google Solar does not provide raw edge delineation)
  linearEdgesAvailable?: boolean;
  estimatedEavesFeet?: number | null;
  estimatedRidgesFeet?: number | null;
  estimatedHipsFeet?: number | null;
  estimatedValleysFeet?: number | null;
  estimatedRakesFeet?: number | null;
  estimatedTotalLinearEdgeFeet?: number | null;
  // Solar potential from Google Solar API
  maxPanelsCount: number;
  panelCapacityWatts: number;
  maxCapacityKw: number;
  maxSunshineHoursPerYear: number;
  carbonOffsetKgPerYear: number;
  // Field provenance mapping
  dataProvenance?: Record<string, MeasurementSource>;
  // Existing solar installation info
  existingSolar?: ExistingSolarSystem;
}

export interface AddressValidationVerdict {
  inputGranularity?: string;
  validationGranularity?: string;
  geocodeGranularity?: string;
  addressComplete?: boolean;
  hasUnconfirmedComponents?: boolean;
  hasInferredComponents?: boolean;
  hasReplacedComponents?: boolean;
  uspsCassProcessed?: boolean;
  dpvConfirmation?: string; // Y, S, D, N
  carrierRoute?: string;
  isResidential?: boolean;
  isBusiness?: boolean;
}

export interface GeoTIFFLayers {
  imageryDate?: { year: number; month: number; day: number };
  imageryQuality?: string;
  dsmUrl?: string;
  rgbUrl?: string;
  maskUrl?: string;
  annualFluxUrl?: string;
  monthlyFluxUrl?: string;
  hourlyShadeUrlsCount?: number;
}

export interface DiagnosticLog {
  timestamp: string;
  service: 'ADDRESS_VALIDATION' | 'GEOCODING' | 'SOLAR_API' | 'DATA_LAYERS';
  status: 'SUCCESS' | 'WARNING' | 'ERROR' | 'INFO';
  statusCode?: number;
  message: string;
  details?: string;
}

export interface PropertyRecord {
  id: string;
  tenantId: string;
  tenantName: string;
  inputAddress: string;
  standardizedAddress: string;
  googlePlaceId: string; // Tier 1: Stored indefinitely
  // Demo mode distinction
  isDemoMode?: boolean;
  // Solar API availability and error diagnostics
  solarDataAvailable: boolean;
  solarCoverageStatus: SolarCoverageStatus;
  solarErrorMessage?: string;
  geocodingStatus?: 'SUCCESS' | 'SIMULATED' | 'FAILED';
  diagnostics?: DiagnosticLog[];
  // Tier 2: 30-day TTL coordinate storage
  coordinates: {
    latitude: number;
    longitude: number;
    cachedAt: string;
    expiresAt: string; // max 30-day TTL
    isExpired: boolean;
  };
  bounds?: {
    sw: { latitude: number; longitude: number };
    ne: { latitude: number; longitude: number };
  };
  status: PipelineStatus;
  verdict: AddressValidationVerdict;
  takeoff: TakeoffSummary;
  segments: RoofSegment[];
  customEdges?: StructuralLine[];
  // Tier 3: 0-day retention raster links (ephemeral)
  dataLayers: GeoTIFFLayers;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface StructuralLine {
  id: string;
  type: 'ridge' | 'hip' | 'valley' | 'eave' | 'rake' | 'flashing';
  name: string;
  segmentIndex?: number;
  path: { lat: number; lng: number }[];
  lengthFeet: number;
}

export interface TenantInfo {
  id: string;
  name: string;
  slug: string;
  region: string;
  primaryContact: string;
}

