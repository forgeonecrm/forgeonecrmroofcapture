# Solar API: Retrieve Building Roof Geometry

This skill details how to use the Solar API's `buildingInsights:findClosest`
endpoint to extract detailed geometric properties of a building's roof, broken
down by individual roof segment.

## Prerequisites

To execute requests against the Solar API, ensure your environment is configured
with the necessary API key.

-   [ ] Set the environment variable `GOOGLE_API_KEY` with your valid Google
    Maps Platform API key.

## Available Tools

The Solar API uses a standard RESTful service accessible via HTTP GET requests.

| Tool                           | Capability                                  |
| :----------------------------- | :------------------------------------------ |
| `buildingInsights:findClosest` | Finds the nearest building to the specified |
:                                : latitude/longitude and returns detailed     :
:                                : structural and solar potential data,        :
:                                : including roof geometry segments.           :

## Implementation Guide

To obtain the geometry of a building's roof, you must make a request to the
`buildingInsights:findClosest` endpoint using the target location coordinates
and specifying the minimum acceptable imagery quality.

### 1. Request Construction

The `buildingInsights:findClosest` endpoint requires geographic coordinates
(`location.latitude`, `location.longitude`) and a quality constraint
(`requiredQuality`).

**Endpoint Structure (REST/GET):**

```text
https://solar.googleapis.com/v1/buildingInsights:findClosest?key=YOUR_API_KEY
```

**Required Query Parameters:**

| Parameter            | Type     | Description               |
| :------------------- | :------- | :------------------------ |
| `location.latitude`  | `number` | The latitude coordinate   |
:                      :          : of the target location.   :
| `location.longitude` | `number` | The longitude coordinate  |
:                      :          : of the target location.   :
| `requiredQuality`    | `enum`   | Minimum imagery quality   |
:                      :          : required (`HIGH`,         :
:                      :          : `MEDIUM`, or `BASE`).     :
| `key`                | `string` | Your API Key.             |
| `solution_id`        | `string` | Mandatory usage           |
:                      :          : attribution ID\:          :
:                      :          : `gmp_git_agentskills_v1`. :

**cURL Example:**

Use this example to request building insights for coordinates 37.4450,
-122.1390, enforcing a high imagery quality, and including the mandatory
solution ID:

```bash
curl -X GET "https://solar.googleapis.com/v1/buildingInsights:findClosest?location.latitude=37.4450&location.longitude=-122.1390&requiredQuality=HIGH&key=YOUR_API_KEY&solution_id=gmp_git_agentskills_v1"
```

### 2. Data Extraction for Roof Geometry

The detailed roof geometry is contained within the `solarPotential` object of
the `BuildingInsightsResponse`, specifically in the `roofSegmentStats` array.

-   [ ] Run the request using the target coordinates.
-   [ ] Parse the JSON response body.
-   [ ] Locate the `BuildingInsightsResponse.solarPotential.roofSegmentStats`
    array.
-   [ ] Iterate through the `RoofSegmentSizeAndSunshineStats` objects to extract
    geometric data points.

**Schema Definitions for Geometric Data:**

| Field (within               | Type        | Description                      |
: `roofSegmentStats` item)    :             :                                  :
| :-------------------------- | :---------- | :------------------------------- |
| `pitchDegrees`              | `number`    | Angle of the roof segment        |
:                             :             : relative to the horizontal       :
:                             :             : plane.                           :
| `azimuthDegrees`            | `number`    | Compass direction the roof       |
:                             :             : segment faces (0°=North,         :
:                             :             : 90°=East, 180°=South).           :
| `stats.areaMeters2`         | `number`    | Surface area of the roof segment |
:                             :             : in square meters.                :
| `center`                    | `LatLng`    | Center coordinate of the roof    |
:                             :             : segment.                         :
| `boundingBox`               | `LatLngBox` | Bounding box coordinates (`sw`,  |
:                             :             : `ne`) defining the segment       :
:                             :             : extent.                          :
| `planeHeightAtCenterMeters` | `number`    | Height of the roof segment plane |
:                             :             : center above ground level.       :

**Example of Segment Data Structure:**

```json
{
  "roofSegmentStats": [
    {
      "pitchDegrees": 11.350553,
      "azimuthDegrees": 269.6291,
      "stats": {
        "areaMeters2": 452.00052,
        "...": "..."
      },
      "center": {
        "latitude": 37.4449728,
        "longitude": -122.1393637
      },
      "boundingBox": {
        "sw": {
          "latitude": 37.4447321,
          "longitude": -122.1394224
        },
        "ne": {
          "latitude": 37.4451909,
          "longitude": -122.1392928
        }
      },
      "planeHeightAtCenterMeters": 10.7835045
    },
    // ... other segments
  ]
}
```

### 3. Filtering by Roof Segment Characteristics

Once `roofSegmentStats` are retrieved, users can filter potential solar panel
placements (`solarPanels` or `solarPanelConfigs`) based on geometric
requirements (e.g., maximizing south-facing surfaces).

-   [ ] Identify desired geometric characteristic (e.g., `azimuthDegrees`
    between 90 and 270 for south-facing segments).
-   [ ] Note the corresponding `segmentIndex` for the matched segments.
-   [ ] Filter the `solarPanelConfigs` or `solarPanels` array using the required
    `segmentIndex` to determine placement only on selected roof parts.

## Gotchas

-   **Imagery Quality Failure**: If the location does not possess imagery data
    that meets the specified `requiredQuality` parameter, the Solar API will
    return a `NOT_FOUND` error with a 404 status code (see Imagery quality
    table). When diagnosing 404 errors, explicitly check if the issue is related
    to insufficient imagery quality.
-   **Ambiguous Location Selection**: If the requested latitude/longitude is
    equidistant to two or more buildings, the Solar API arbitrarily selects and
    returns data for one building. Always verify which building was processed by
    examining the returned `boundingBox` value.
-   **EEA Content Restriction**: Be aware that for billing addresses located in
    the European Economic Area (EEA), certain content from the Solar API will
    cease to be returned after July 8, 2025. This may impact the availability of
    certain building insight metrics.

### References

*   [buildingInsights:findClosest Reference](https://developers.google.com/maps/documentation/solar/reference/rest/v1/buildingInsights/findClosest?utm_campaign=gmp_git_agentskills_v1)
*   [Solar API Concepts](https://developers.google.com/maps/documentation/solar/concepts?utm_campaign=gmp_git_agentskills_v1)
*   [Google Maps Platform EEA Terms of Service](https://cloud.google.com/terms/maps-platform/eea?utm_campaign=gmp_git_agentskills_v1)
*   [European Economic Area (EEA) developers communication](https://developers.google.com/maps/comms/eea/solar?utm_campaign=gmp_git_agentskills_v1)

## See Also

> Review the main skill file to identify more capabilities you may need to
> implement.

### Error & Exception Handling

When invoking the `buildingInsights:findClosest` endpoint via a REST client,
production applications must include a wrapper to correctly interpret non-200
HTTP status codes and provide actionable feedback, particularly distinguishing
between API failures and data availability issues (such as insufficient imagery
quality).

The API returns a structured JSON error object (`RequestError`) containing
`code`, `message`, and `status` when the request fails (e.g., network error,
authentication failure, or data not found).

#### 1. Fetch Wrapper for Structured Error Handling

Use a standard Promise-based wrapper to ensure non-200 responses throw the
structured error body for consistent application-level error handling:

```typescript
import { BuildingInsightsResponse, RequestError } from './solar';

/**
 * Fetches the building insights information from the Solar API.
 * @throws {RequestError} if the response status is not 200.
 */
export async function findClosestBuilding(
  location: google.maps.LatLng,
  apiKey: string,
): Promise<BuildingInsightsResponse> {
  // ... URL construction logic ...

  const response = await fetch(`https://solar.googleapis.com/v1/buildingInsights:findClosest?${params}`);
  const content = await response.json();

  if (response.status !== 200) {
    // Throw the structured error object containing code, status, and message
    console.error('findClosestBuilding failed:', content);
    throw content;
  }
  return content as BuildingInsightsResponse;
}
```

#### 2. Consuming the Error and Implementing Gotcha Checks

In the calling application code, intercept the thrown error object (`e`) and
inspect its properties to determine the cause of failure. Always verify if the
error is due to an [Imagery Quality Failure] issue when diagnosing 404 errors.

```typescript
import { findClosestBuilding, RequestError } from './solar';

async function getBuildingData(location, apiKey) {
  try {
    const data = await findClosestBuilding(location, apiKey);
    // Handle successful data processing
  } catch (e) {
    const error = e as RequestError;

    // Verify specific status codes, such as NOT_FOUND (404)
    if (error.error?.status === 'NOT_FOUND') {
      // This often corresponds to Imagery Quality Failure (Gotchas)
      console.error(
        `Error ${error.error.code}: Location data not found or requiredQuality insufficient. Status: ${error.error.status}`
      );
      // Implement fallback logic or inform the user
    } else {
      // Handle authentication, rate limit, or other API errors
      console.error(`API Error ${error.error.code}: ${error.error.message}`);
    }

    // Provide a retry mechanism
    // showRetryButton();
  }
}
```
